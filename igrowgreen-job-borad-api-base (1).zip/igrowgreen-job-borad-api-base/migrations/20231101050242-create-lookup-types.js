'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
	async up(queryInterface, Sequelize) {
		await queryInterface.createTable('LookupTypes', {
			lookupTypeID: {
				allowNull: false,
				autoIncrement: true,
				primaryKey: true,
				type: Sequelize.INTEGER
			},
			parentLookupTypeID: {
				type: Sequelize.INTEGER,
			},
			lookupTypeID: {
				type: Sequelize.INTEGER,
				required: true,
			},
			lookupTypeName: {
				type: Sequelize.STRING,
				required: true,
			},
			sortOrderID: {
				type: Sequelize.INTEGER,
				//required: true,
			},
			isDeleted: {
				type: Sequelize.BOOLEAN
			},
			isActive: {
				type: Sequelize.BOOLEAN
			},
			createdAt: {
				allowNull: false,
				type: Sequelize.DATE,
				defaultValue: Sequelize.fn("NOW"),
			},
			updatedAt: {
				allowNull: true,
				type: Sequelize.DATE
			}
		});
	},
	async down(queryInterface, Sequelize) {
		await queryInterface.dropTable('LookupTypes');
	}
};