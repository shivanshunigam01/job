'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable('Lookups', {
            id: {
                allowNull: false,
                autoIncrement: true,
                primaryKey: true,
                type: Sequelize.INTEGER
            },
            lookupID: {
                type: Sequelize.INTEGER,
                required: true,
            },
            parentLookupID: {
                type: Sequelize.INTEGER,
            },
            lookupTypeID: {
                type: Sequelize.INTEGER,
                required: true,
            },
            code: {
                type: Sequelize.STRING,
                required: true,
            },
            name: {
                type: Sequelize.STRING,
                required: true,
            },
            value: {
                type: Sequelize.INTEGER,
                required: true,
            },
            description: {
                type: Sequelize.STRING,
            },
            sortOrderID: {
                type: Sequelize.INTEGER,
            },
            isDeleted: {
                type: Sequelize.BOOLEAN
            },
            isActive: {
                type: Sequelize.BOOLEAN
            },
            createdAt: {
                allowNull: false,
                type: Sequelize.DATE,
                defaultValue: Sequelize.fn("NOW"),
            },
            updatedAt: {
                allowNull: true,
                type: Sequelize.DATE
            }
        });
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Lookups');
    }
};