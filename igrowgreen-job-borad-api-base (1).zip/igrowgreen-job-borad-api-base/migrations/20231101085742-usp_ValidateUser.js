'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
	async up(queryInterface, Sequelize) {
		return queryInterface.sequelize.query(`
    -- Create a stored procedure
    CREATE PROCEDURE usp_ValidateUser(
      IN emailID VARCHAR(250)
    )
    BEGIN
      Select	* 
        From 	Users
        Where 	email = emailID;
    END
    `);
	},

	async down(queryInterface, Sequelize) {
		/**
		 * Add reverting commands here.
		 *
		 * Example:
		 * await queryInterface.dropTable('users');
		 */
		return queryInterface.sequelize.query(`
      DROP PROCEDURE IF EXISTS usp_ValidateUser;
    `);
	}
};
