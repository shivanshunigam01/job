'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
	async up(queryInterface, Sequelize) {
		/**
		 * Add altering commands here.
		 * 
		 * Example:
		 * await queryInterface.createTable('users', { id: Sequelize.INTEGER });
		 */
		return queryInterface.sequelize.query(`
    CREATE PROCEDURE usp_Registration(
      IN firstName nvarchar(250),
      IN lastName nvarchar(250),
      IN email nvarchar(250),
        IN password nvarchar(250),
        IN mobileNumber nvarchar(15),
        IN confirmOTP int
    )
    BEGIN
      Declare userID Int; 
      Insert Into Users(firstName, lastName, email, password, mobileNumber, isActive, isConfirm, confirmOtp, otpGenerateAt, createdAt)
        Values(firstName, lastName, email, password, mobileNumber, 0, 0, confirmOtp, current_date(), current_date()); 
        
        Set userID = (select LAST_INSERT_ID());
       
      If(userID > 0) THEN
        Select firstName, lastName, email, mobileNumber From users
        Where userID = userID;
      end if;
    END
    `);
	},

	async down(queryInterface, Sequelize) {
		/**
		 * Add reverting commands here.
		 *
		 * Example:
		 * await queryInterface.dropTable('users');
		 */
		return queryInterface.sequelize.query(`
      DROP PROCEDURE IF EXISTS usp_Registration;
    `);
	}
};
