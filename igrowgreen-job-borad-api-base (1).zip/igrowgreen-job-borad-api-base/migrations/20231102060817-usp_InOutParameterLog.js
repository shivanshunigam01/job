'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
	async up(queryInterface, Sequelize) {
		/**
		 * Add altering commands here.
		 *
		 * Example:
		 * await queryInterface.createTable('users', { id: Sequelize.INTEGER });
		 */
		return queryInterface.sequelize.query(`
    		CREATE PROCEDURE usp_InOutParameterLog(
    		  	IN controllerName nvarchar(255),
    		  	IN routeName nvarchar(255),
    		  	IN inputParameters text,
    		  	IN outputParameters text,
    		  	IN requestFrom int,
    		  	IN message text,
    		    IN hasError bit)
    		BEGIN
    		  	Insert Into inoutparameterslogs(controllerName, routeName, inputParameters, outputParameters, requestFrom, message, hasError, createdAt)
    		  	Values(controllerName, routeName, inputParameters, outputParameters, requestFrom, message, hasError, current_date()); 
				Select LAST_INSERT_ID() as logID;
			END
    	`);
	},

	async down(queryInterface, Sequelize) {
		/**
		 * Add reverting commands here.
		 *
		 * Example:
		 * await queryInterface.dropTable('users');
		 */
		return queryInterface.sequelize.query(`DROP PROCEDURE IF EXISTS usp_InOutParameterLog;`);
	}
};
