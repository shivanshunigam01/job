/**
* Lookup model which containts the table attributes.
*/

'use strict';
const {
	Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
	class Lookups extends Model {
		/**
		 * Helper method for defining associations.
		 * This method is not a part of Sequelize lifecycle.
		 * The `models/index` file will call this method automatically.
		 */
		static associate(models) {
			// define association here
		}
	}
	Lookups.init({
		id: {
			allowNull: false,
			autoIncrement: true,
			primaryKey: true,
			type: DataTypes.INTEGER
		},
		lookupID: {
			type: DataTypes.INTEGER,
			required: true,
		},
		parentLookupID: {
			type: DataTypes.INTEGER,
		},
		lookupTypeID: {
			type: DataTypes.INTEGER,
			required: true,
		},
		code: {
			type: DataTypes.STRING,
			required: true,
		},
		name: {
			type: DataTypes.STRING,
			required: true,
		},
		value: {
			type: DataTypes.INTEGER,
			required: true,
		},
		description: {
			type: DataTypes.STRING,
		},
		sortOrderID: {
			type: DataTypes.INTEGER,
		},
		isDeleted: {
			type: DataTypes.BOOLEAN
		},
		isActive: {
			type: DataTypes.BOOLEAN
		},
		createdAt: {
			allowNull: false,
			type: DataTypes.DATE,
			defaultValue: new Date()
		},
		updatedAt: {
			allowNull: true,
			type: DataTypes.DATE
		}
	},
		{
			sequelize,
			modelName: 'Lookups',
		});
	return Lookups;
};