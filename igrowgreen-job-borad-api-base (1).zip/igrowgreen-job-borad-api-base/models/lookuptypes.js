/**
* LookupType model which containts the table attributes.
*/

'use strict';
const {
	Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
	class LookupTypes extends Model {
		/**
		 * Helper method for defining associations.
		 * This method is not a part of Sequelize lifecycle.
		 * The `models/index` file will call this method automatically.
		 */
		static associate(models) {
			// define association here
		}
	}
	LookupTypes.init({
		lookupTypeID: {
			allowNull: false,
			autoIncrement: true,
			primaryKey: true,
			type: DataTypes.INTEGER
		},
		parentLookupTypeID: {
			type: DataTypes.INTEGER,
		},
		lookupTypeID: {
			type: DataTypes.INTEGER,
			required: true,
		},
		lookupTypeName: {
			type: DataTypes.STRING,
			required: true,
		},
		sortOrderID: {
			type: DataTypes.INTEGER,
			//required: true,
		},
		isDeleted: {
			type: DataTypes.BOOLEAN
		},
		isActive: {
			type: DataTypes.BOOLEAN
		},
		createdAt: {
			allowNull: false,
			type: DataTypes.DATE,
			defaultValue: new Date()
		},
		updatedAt: {
			allowNull: true,
			type: DataTypes.DATE
		}
	},
		{
			sequelize,
			modelName: 'LookupTypes',
		});
	return LookupTypes;
};