// User Model
var crypto = require('crypto');

module.exports = (sequelize, DataTypes) => {
    var Member = sequelize.define('member', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        branch_id: {
            type: DataTypes.INTEGER,
            defaultValue: null
        },
        area: {
            type: DataTypes.INTEGER,
            defaultValue: null
        },
        circle: {
            type: DataTypes.INTEGER,
            defaultValue: null
        },
        division: {
            type: DataTypes.INTEGER,
            defaultValue: null
        },
        subdivision: {
            type: DataTypes.INTEGER,
            defaultValue: null
        },
        section: {
            type: DataTypes.INTEGER,
            defaultValue: null
        },
        member_type: {
            type: DataTypes.INTEGER,
            defaultValue: null
        },
       
        name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        designation: {
            type: DataTypes.STRING
        },
        password: {
            type: DataTypes.STRING
        },
        address1: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        address2: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        address3: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        city: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        state: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        zip: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        email: {
            type: DataTypes.STRING,
            unique: true
        },
        member_email: {
            type: DataTypes.STRING
        },
        mobile: {
            type: DataTypes.STRING
        },
        landline: {
            type: DataTypes.STRING
        },
        activation_code: {
            type: DataTypes.INTEGER
        },
        usertype: {
            type: DataTypes.INTEGER
        },
        last_login_date: {
            type: DataTypes.DATE,
            
        },
        notes: {
            type: DataTypes.STRING
        },
        ref_emp_id: {
            type: DataTypes.INTEGER
        },
        password_otp: {
            type: DataTypes.INTEGER
        },
        status: {
            type: DataTypes.INTEGER
        },
       
        role_category_type: {
            type: DataTypes.STRING
        },
        created: {
            type: DataTypes.DATE,
            defaultValue: Date.now
        },
        modified: {
            type: DataTypes.DATE,
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: Date.now
        },
        updatedAt: {
            type: DataTypes.DATE,
        },
       
        
    });



    // User.associate = function (models) {
    //     User.belongsTo(models.role, {
    //         as: 'roles',
    //         foreignKey: 'role_id'
    //     });

    //     User.belongsTo(models.userType, {
    //         as: 'user_type',
    //         foreignKey: 'user_type_id'
    //     });

    //     User.belongsTo(models.country, {
    //         foreignKey: 'country_id'
    //     });
    // };

    Member.authenticate = function (plainText, userPassword) {
        return this.setPassword(plainText) === userPassword;
    };

    Member.hashPassword = function (password) {
        if (!password) return '';
        return crypto.createHash('sha1').update(password).toString("hex");
    };

    Member.setPassword = function (password) {
        if (!password) return '';
        return crypto.createHash('sha1').update(password).digest("hex");
    };

    return Member;
};