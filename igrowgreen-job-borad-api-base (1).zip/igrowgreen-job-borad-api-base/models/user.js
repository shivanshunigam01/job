// User Model
var crypto = require('crypto');

module.exports = (sequelize, DataTypes) => {
    var User = sequelize.define('user', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        customer_parent_id: {
            type: DataTypes.INTEGER,
            defaultValue: null
        },
        installer_id: {
            type: DataTypes.INTEGER,
            defaultValue: null
        },
        customer_type: {
            type: DataTypes.ENUM,
            values: ['customer', 'installer', 'installer_user'],
            defaultValue: null
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        password: {
            type: DataTypes.STRING
        },
        address1: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        address2: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        address3: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        city: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        state: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        zip: {
            type: DataTypes.STRING,
            defaultValue: null
        },
        email: {
            type: DataTypes.STRING,
            unique: true
        },
        mobile: {
            type: DataTypes.STRING
        },
        landline: {
            type: DataTypes.STRING
        },
        activation_code: {
            type: DataTypes.INTEGER
        },
        usertype: {
            type: DataTypes.INTEGER
        },
        last_login_date: {
            type: DataTypes.DATE,
            
        },
        notes: {
            type: DataTypes.STRING
        },
        user_role: {
            type: DataTypes.STRING
        },
        default_admin: {
            type: DataTypes.INTEGER
        },
        status: {
            type: DataTypes.INTEGER
        },
        start_date: {
            type: DataTypes.DATE
        },
        expire_date: {
            type: DataTypes.DATE
        },
        update_profile: {
            type: DataTypes.INTEGER
        },
        update_profile_otp: {
            type: DataTypes.STRING
        },
        update_profile_otp_date: {
            type: DataTypes.DATE
        },
        created: {
            type: DataTypes.DATE,
            defaultValue: Date.now
        },
        modified: {
            type: DataTypes.DATE,
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: Date.now
        },
        updatedAt: {
            type: DataTypes.DATE,
        },
       
        
    });



    // User.associate = function (models) {
    //     User.belongsTo(models.role, {
    //         as: 'roles',
    //         foreignKey: 'role_id'
    //     });

    //     User.belongsTo(models.userType, {
    //         as: 'user_type',
    //         foreignKey: 'user_type_id'
    //     });

    //     User.belongsTo(models.country, {
    //         foreignKey: 'country_id'
    //     });
    // };

    User.authenticate = function (plainText, userPassword) {
        return this.setPassword(plainText) === userPassword;
    };

    User.hashPassword = function (password) {
        if (!password) return '';
        return crypto.createHash('sha1').update(password).toString("hex");
    };

    User.setPassword = function (password) {
        if (!password) return '';
        return crypto.createHash('sha1').update(password).digest("hex");
    };

    return User;
};