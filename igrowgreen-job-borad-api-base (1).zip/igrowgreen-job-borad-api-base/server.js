require("dotenv").config();
const express = require("express");
const cors = require("cors");
var cookieParser = require("cookie-parser");
const multer = require("multer");
var upload = multer();
var apiRouter = require("./src/routes/api.routes");
// import for the cron jobs
const {deleteFileCron,registrationDocumentCron} = require('./src/cron/commonCron');
//const {getApplicationFromPMS} = require('./src/cron/PMSCron');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const verifyToken = require("./src/middlewares/auth");
const verifyTokenIfApplicable = require("./src/middlewares/authApplicableOrNot");

const app = express();
global.__basedir = __dirname;
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
//To allow cross-origin requests
app.use(cors());
// Use Helmet!
app.use(helmet());

// Use Helmet to set X-Frame-Options to DENY // this is for the click jacking
app.use(helmet.frameguard({ action: 'deny' }));

// Define the rate limiting rule
const limiter = rateLimit({
	windowMs: 1 * 60 * 1000, // 1 minute window
	max: 100, // Limit each IP to 100 requests per windowMs
	message: 'Too many requests from this IP, please try again after a minute',
	statusCode: 429 // Status code to return when rate limit is exceeded
});

// Apply the rate limiting middleware to all requests.
app.use(limiter);

// Enable HSTS with Helmet
app.use(helmet.hsts({
    maxAge: 31536000, // 1 year in seconds
    includeSubDomains: true, // Apply to all subdomains
    preload: true // Add to preload list
}));

// Host Header injection logic
const allowedHosts = ['localhost:4010', 'localhost:5010' ,'api.guvnl.staging.ahasolar.co.in','www.api.guvnl.staging.ahasolar.co.in','rts.bsesdelhi.com','www.rts.bsesdelhi.com'];

const checkHostHeader = (req, res, next) => {
    const hostHeader = req.get('Host');
    if (allowedHosts.includes(hostHeader)) {
        next();
    } else {
        res.status(400).send('Invalid Host header');
    }
};

// Apply the Host header check middleware
app.use(checkHostHeader);

// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));
app.use('/api/documents',verifyTokenIfApplicable, function (req, res, next) {
	//console.log(__dirname  + process.env.FILE_LOCATION );
	next();
}, express.static(__dirname + process.env.FILE_LOCATION));

app.use('/api/installer_documents',verifyToken, function (req, res, next) {
	//console.log(__dirname  + process.env.FILE_LOCATION );
	next();
}, express.static(__dirname + process.env.INSTALLER_FILE_LOCATION));
 var allowedOrigins = [
	'http://localhost:4010', 'http://localhost:5010', 'https://localhost:3000','https://staging.bses.ahasolar.co.in','https://rts.bsesdelhi.com'
 ];


// if (env != 'production') {
// 	allowedOrigins.push('*');
// }
app.use(function (req, res, next) {

	var origin = req.headers.origin;
	//res.setHeader('Access-Control-Allow-Origin', '*');
	//res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
	 if (allowedOrigins.indexOf(origin) > -1) {
	 	res.setHeader('Access-Control-Allow-Origin', origin);
		res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
		next();
	} else if (allowedOrigins.indexOf('*') > -1) {
	 	res.setHeader('Access-Control-Allow-Origin', '*');
		res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
		next();
	 }else{
		res.status(400).send('Invalid Host header');
	 }
	//next();
	// res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
	// res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type, x-access-token, x-time-zone');
	// res.setHeader('Access-Control-Allow-Credentials', true);
	// if (req.method == 'OPTIONS') {
	// 	return res.status(200).end();
	// } else {
	// 	next();
	// }
});
app.use("/api/", apiRouter);

// for parsing multipart/form-data
app.use(upload.array());
app.use(express.static('public'));

// Disable the "X-Powered-By" header
app.disable('x-powered-by');

// Start the cron job
// registrationDocumentCron.start();
// deleteFileCron.start();

// set port, listen for requests

const PORT = process.env.PORT || 8080;
app.listen(PORT,() => {
	console.log(`Server is running on port ${PORT}.`);
});


  

