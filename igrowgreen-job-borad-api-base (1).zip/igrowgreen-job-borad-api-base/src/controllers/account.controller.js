const apiResponse = require("../helpers/apiResponse");
const AccountManager = require('../manager/account.manager.js')
const utility = require("../helpers/utility");

const accountManager = new AccountManager();
/**
 * Account Controller.
 */
class AccountController {
    /**
     * Get Dropdown List.
     *
     * @returns {Array}
     */
    async userProfile(req, res) {
        try {
            // let deviceType = req.headers["device-type"];
            // req.body.deviceType = deviceType;
            //if(req.user.type=="consumer"){
            //    return  apiResponse.successResponseWithData(res, "Login Successfully.", req.user);
            //}
            var result = await accountManager.userProfile(req);
     
            if (result != null) {
                // if (result.userID > 0 && result.isConfirm && result.isActive) {
                // 	return apiResponse.successResponseWithData(res, "Login Successfully.", result);
                // }
                // else if (result.userID > 0 && !result.isConfirm) {
                // 	return apiResponse.unauthorizedResponse(res, "Account is not confirmed. Please confirmed your account.");
                // }
                // else if (result.userID > 0 && !result.isActive) {
                // 	return apiResponse.unauthorizedResponse(res, "Account is not active. Please contact admin.");
                // }
                if (result.company_details || result) {
                    return apiResponse.successResponseWithData(res, "Login Successfully.", result);
                }
                // else if (result.userID > 0 && !result.isConfirm) {
                // 	return apiResponse.unauthorizedResponse(res, "Account is not confirmed. Please confirmed your account.");
                // }
                else  {
                    return apiResponse.unauthorizedResponse(res, "Account is not active. Please contact admin.");
                }
            }
            
            else {
                return apiResponse.unauthorizedResponse(res, "Account is wrong.");
            }
        }
        catch (error) {
            return apiResponse.expectationFailedResponse(res, error);
        }

    }

}

module.exports = { AccountController };
