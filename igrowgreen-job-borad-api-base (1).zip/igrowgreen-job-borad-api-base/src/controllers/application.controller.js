const apiResponse = require('../helpers/apiResponse')
const helper = require('../helpers/helper.js')
const { decryptData, encryptData, encryptID } = require('../helpers/utility.js')
const ApplicationManager = require('../manager/application.manager.js')
const applicationManager = new ApplicationManager()
/**
 * Application Controller.
 */
class ApplicationController {
	/**
	 * Get Dropdown List.
	 *
	 * @returns {Array}
	 */

	async categorieslist(req, res, next) {
		try {
			const result = await applicationManager.categorieslist(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'No record found.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record fetched successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async getCategoryAndJobCountFromJob(req, res, next) {
		try {
			const result = await applicationManager.getCategoryAndJobCountFromJob(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'No record found.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record fetched successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async createJobList(req, res, next) {
		try {
			const result = await applicationManager.createJobList(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Job Created Succesfully',
					result
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Job.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async createUserSkill(req, res, next) {
		try {
			const result = await applicationManager.createUserSkill(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Skill Created Succesfully',
					result
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Skill.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async getUserSkill(req, res, next) {
		try {
			const result = await applicationManager.getUserSkill(req, res)

			if (result) {
				return apiResponse.successResponseWithData(
					res,
					'Skill fetched Succesfully',
					result
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while fetching Skill.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

  async getUserEmployement (req, res, next) {
    try {
      const result =await applicationManager.getUserEmployement(req, res)
      if (result) {
        if (result.length == 0) {
            return apiResponse.successResponseWithData(res, 'No record found.', [])
        } else {
            return apiResponse.successResponseWithData(
                res,
                'Record fetched successfully',
                result
            )
        }

      } else {
        return apiResponse.forbiddenRequest(res, 'Error while fetching Skill.')
      }
    } catch (error) {
      return apiResponse.expectationFailedResponse(res, error)
    }
  }

	async getResumeHeadline(req, res, next) {
		try {
			const result = await applicationManager.getResumeHeadline(req, res)

			if (result) {
				return apiResponse.successResponseWithData(
					res,
					'Record fetched Succesfully',
					result
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while fetching Record.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async createUserEmployement(req, res, next) {
		try {
			const result = await applicationManager.createUserEmployement(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Record Created Succesfully',
					result
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Record.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async createUserEducation(req, res, next) {
		try {
			const result = await applicationManager.createUserEducation(req, res)

			if (result && result.length > 0) {
				if(result[0]?.result === 0){
                    return apiResponse.forbiddenRequest(res, 'This course already exists.')
                }else{
                    return apiResponse.successResponseWithData(
                        res,
                        'Record Created Succesfully',
                        result
                    )
                }
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Record.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async getUserEducation(req, res, next) {
		try {
			const result = await applicationManager.getUserEducation(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Record Fatch Succesfully',
					result
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Fatching Record.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async getJobList(req, res, next) {
		try {
			// let deviceType = req.headers["device-type"];
			// req.body.deviceType = deviceType;
			var resultCount = await applicationManager.getJobListCount(req)
			var resultList = await applicationManager.getJobListData(req)

			if (resultList && resultCount) {
				resultCount[0].pageSize = Math.round(
					resultCount[0].totalRecords / req.body.size || 10
				)
				resultCount[0].currentPage = req.body.page || 1
				resultCount[0].job_category_name =
					resultList[0]?.job_category_name || ''
				if (resultCount[0].totalRecords == 0) {
					resultCount[0].pageSize = 0
				}

				const newList = resultList.map(item => {
					// Convert comma-separated skills into an array of objects
					item.skills = item.skills
						? item.skills.split(',').map(skill => ({ skill: skill.trim() }))
						: []

					// Uncomment and modify if you need to encrypt IDs or perform other transformations
					// item.id = encryptID(item.id);

					return item
				})

				return apiResponse.successResponseWithData(
					res,
					'Job List Fetched Successfully.',
					{ count: resultCount, list: newList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Job List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async locationslist(req, res, next) {
		try {
			const result = await applicationManager.locationslist(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'No record found.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record fetched successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async departmentlist(req, res, next) {
		try {
			const result = await applicationManager.departmentlist(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'No record found.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record fetched successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async educationslist(req, res, next) {
		try {
			const result = await applicationManager.educationslist(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'No record found.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record fetched successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async industryTypeslist(req, res, next) {
		try {
			const result = await applicationManager.industryTypeslist(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'No record found.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record fetched successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async skillslist(req, res, next) {
		try {
			const result = await applicationManager.skillslist(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'No record found.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record fetched successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	// Get paramaters Details
	async getParameters(req, res) {
		try {
			var result = await applicationManager.getParameters(req)

			if (result) {
				return apiResponse.successResponseWithData(
					res,
					'Parameters Details Successfully Fetched.',
					{ list: result }
				)
			} else {
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async ResumeUpload(req, res, next) {
		try {
			const result = await applicationManager.ResumeUpload(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'Resume Upload Failed.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Resume Uploaded successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async ResumeHeadline(req, res, next) {
		try {
			const result = await applicationManager.ResumeHeadline(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'Record Update Failed.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record Updated Successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async jobApply(req, res, next) {
		try {
			const result = await applicationManager.jobApply(req)

			if (result) {
				if (result) {
					return apiResponse.successResponseWithData(
						res,
						'Job Application Updated Successfully',
						result
					)
				} else {
					return apiResponse.notFoundResponse(
						res,
						'Job Application Failed.',
						[]
					)
				}
			} else {
				return apiResponse.notFoundResponse(res, 'No action was taken.', [])
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async getJobDatabyID(req, res, next) {
		try {
			const result = await applicationManager.getJobDatabyID(req)
			if (result && result.length > 0) {
				const jobDetails = result[0]

				// Convert skills from a comma-separated string to an array of objects
				const skills = jobDetails.skills
					? jobDetails.skills.split(',').map(skill => ({ skill: skill.trim() }))
					: []

				// Prepare company details as an object
				const companyDetails = {
					name: jobDetails.name || '',
					phone: jobDetails.phone || '',
					email: jobDetails.email || '',
					designation: jobDetails.contact_person_designation || '',
					about_company: jobDetails.company_type || '',
					company_id: jobDetails.company_id || '',
                    profile_picture:jobDetails.profile_picture || ''
				}

				// Prepare job details as an object
				const jobDetailsObject = {
					job_title: jobDetails.job_title || '',
					about_job: jobDetails.about_job || '',
					company_name: jobDetails.company_name || '',
					posted_at: jobDetails.posted_at,
					salary_range_type: jobDetails.salary_range_type,
					experience_years: jobDetails.total_experience || '',
					location: jobDetails.on_location_job || '',
					package: jobDetails.salary_range_between || '',
					job_qualification: jobDetails.job_qualification || '',
					applicant_count: jobDetails.applicant_count || ''
				}

				// Create the final response object
				const response = {
					job_description: jobDetails.job_description || '',
					no_of_people_hiring: jobDetails.no_of_people_hiring || '',
					role: jobDetails.role || '',
					department: jobDetails.department || '',
					employment_type: jobDetails.employment_type || '',
					role_category: jobDetails.role_category || '',
					skills: skills,
					company_details: companyDetails,
					job_details: jobDetailsObject
				}

				return apiResponse.successResponseWithData(
					res,
					'You have successfully applied for this job',
					response
				)
			} else {
				return apiResponse.successResponseWithData(res, 'No Jobs found.', [])
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	//API to get common status data
	async getCommonStatus(req, res, next) {
		try {
			const result = await applicationManager.getCommonStatus(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.successResponseWithData(res, '', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record Updated Successfully',
						result
					)
				}
			}
			else {
				return apiResponse.successResponseWithData(
					res,
					'Record Not Found',

				)
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	//API to get Job Matches
	async getJobMatches(req, res, next) {
		try {
			const result = await applicationManager.getJobMatches(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'Get Same Job Failed.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Same Job Fetched Successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async getJobPostList(req, res, next) {
		try {
			// let deviceType = req.headers["device-type"];
			// req.body.deviceType = deviceType;
			var resultCount = await applicationManager.getJobPostListCount(req)
			var resultList = await applicationManager.getJobPostListData(req)

			if (resultList && resultCount) {
				resultCount[0].pageSize = Math.round(
					resultCount[0].totalRecords / req.body.size || 10
				)
				resultCount[0].currentPage = req.body.page || 1
				resultCount[0].job_category_name =
					resultList[0]?.job_category_name || ''
				if (resultCount[0].totalRecords == 0) {
					resultCount[0].pageSize = 0
				}

				const newList = resultList.map(item => {
					// Convert comma-separated skills into an array of objects
					item.skills = item.skills
						? item.skills.split(',').map(skill => ({ skill: skill.trim() }))
						: []

					// Uncomment and modify if you need to encrypt IDs or perform other transformations
					// item.id = encryptID(item.id);

					return item
				})

				return apiResponse.successResponseWithData(
					res,
					'Job List Fetched Successfully.',
					{ count: resultCount, list: newList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(res, 'No Record Found', {
						count: resultCount,
						list: resultList
					})
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async updateJobStatus(req, res, next) {
		try {
			const result = await applicationManager.updateJobStatus(req)
			if (result[0].job_id != 0) {
				return apiResponse.successResponse(
					res,
					'Job status updated Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(
					res,
					'Error while updating Job Status'
				)
			}
			return result
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async getJobAppliedUserList(req, res, next) {
		try {
			var resultCount = await applicationManager.getJobAppliedUserListCount(req)
			var resultList = await applicationManager.getJobAppliedUserListData(req)

			if (resultList && resultCount) {
				resultCount[0].pageSize = Math.round(
					resultCount[0].totalRecords / req.body.size || 10
				)
				resultCount[0].currentPage = req.body.page || 1
				if (resultCount[0].totalRecords == 0) {
					resultCount[0].pageSize = 0
				}

				return apiResponse.successResponseWithData(
					res,
					'Job Applied user List Fetched Successfully.',
					{
						count: resultCount,
						list: Object.values(resultList[1]),
						jobDetails: resultList[0][0]
					}
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(res, 'No Record Found.', {
						count: resultCount,
						list: Object.values(resultList[1]),
						jobDetails: resultList[0][0]
					})
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async getJobSeekersJobAppliedList(req, res, next) {
		try {
			var resultCount =
				await applicationManager.getJobSeekersJobAppliedListCount(req)
			var resultList = await applicationManager.getJobSeekersJobAppliedListData(
				req
			)

			if (resultList && resultCount) {
				resultCount[0].pageSize =
					Math.round(resultCount[0].totalRecords / req.body.size || 10) + 1
				resultCount[0].currentPage = req.body.page || 1
				if (resultCount[0].totalRecords == 0) {
					resultCount[0].pageSize = 0
				}

				return apiResponse.successResponseWithData(
					res,
					'Job Applied user List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(res, 'No Record Found.', {
						count: resultCount,
						list: resultList
					})
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async saveUnsaveJob(req, res, next) {
		try {
			const result = await applicationManager.saveUnsaveJob(req)

			if (result.length > 0) {
				const isSaved = result[0].is_saved
				const message =
					isSaved === 1 ? 'Job Saved Successfully' : 'Job Unsaved Successfully'

				return apiResponse.successResponseWithData(
					res,
					{ is_saved: isSaved },
					message
				)
			}

			return apiResponse.forbiddenRequest(res, 'Error while saving Job')
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async savedUnsavedJobList(req, res, next) {
		try {
			const result = await applicationManager.savedUnsavedJobList(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'Get Same Job Failed.', [])
				} else {
					// Modify the result structure as required
					const formattedData = result.map(job => ({
						is_saved: job.is_saved,
						job_id: job.job_id,
						company_name: job.company_name,
						contact_user_name: job.contact_user_name,
						contact_user_mobile: job.contact_user_mobile,
						contact_user_email: job.contact_user_email,
						job_title_name: job.job_title_name,
						no_of_people_hiring: job.no_of_people_hiring,
						on_location_job: job.on_location_job,
						department: job.department,
						total_experience: job.total_experience,
						job_type: job.job_type,
						job_address: job.job_address,
						salary_type: job.salary_type,
						job_category: job.job_category,
						job_category_name: job.job_category_name,
						salary_range_between: job.salary_range_between,
						salary_range_type: job.salary_range_type,
						shift_time: job.shift_time,
						job_description: job.job_description,
						created_at: job.created_at,
                        created_by: job.created_by,
                        profile_picture:job.profile_picture,
						// Split skills string into an array of individual skills
						skills: job.skills
							? job.skills.split(',').map(skill => skill.trim())
							: []
					}))

					return apiResponse.successResponseWithData(
						res,
						'Same Job Fetched Successfully',
						formattedData
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	// async getJobPostList(req, res, next) {
	// 	try {
	// 		// let deviceType = req.headers["device-type"];
	// 		// req.body.deviceType = deviceType;
	// 		var resultCount = await applicationManager.getJobPostListCount(req)
	// 		var resultList = await applicationManager.getJobPostListData(req)

	// 		if (resultList && resultCount) {
	// 			resultCount[0].pageSize = Math.round(
	// 				resultCount[0].totalRecords / req.body.size || 10
	// 			)
	// 			resultCount[0].currentPage = req.body.page || 1
	// 			resultCount[0].job_category_name =
	// 				resultList[0]?.job_category_name || ''

	// 			const newList = resultList.map(item => {
	// 				// Convert comma-separated skills into an array of objects
	// 				item.skills = item.skills
	// 					? item.skills.split(',').map(skill => ({ skill: skill.trim() }))
	// 					: []

	// 				// Uncomment and modify if you need to encrypt IDs or perform other transformations
	// 				// item.id = encryptID(item.id);

	// 				return item
	// 			})

	// 			return apiResponse.successResponseWithData(
	// 				res,
	// 				'Job List Fetched Successfully.',
	// 				{ count: resultCount, list: newList }
	// 			)
	// 		} else {
	// 			if (resultCount == 0) {
	// 				return apiResponse.successResponseWithData(
	// 					res,
	// 					'Job List Fetched Successfully.',
	// 					{ count: resultCount, list: resultList }
	// 				)
	// 			}
	// 			return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
	// 		}
	// 	} catch (error) {
	// 		return apiResponse.expectationFailedResponse(res, error)
	// 	}
	// }

	async updateJobStatus(req, res, next) {
		try {
			const result = await applicationManager.updateJobStatus(req)
			if (result[0].job_id != 0) {
				return apiResponse.successResponse(
					res,
					'Job status updated Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(
					res,
					'Error while updating Job Status'
				)
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async updateUserITSkills(req, res, next) {
		try {
			const result = await applicationManager.updateUserITSkills(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Skills Upated Succesfully',
					result
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Record.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async deleteUserITSkills(req, res, next) {
		try {
			const result = await applicationManager.deleteUserITSkills(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Skills deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Record.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async getUserITSkillsList(req, res, next) {
		try {
			const result = await applicationManager.getUserITSkillsList(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'No record found.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record fetched successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	// Create or Update User Profile Summary
	async createProfileSummary(req, res, next) {
		try {
			const result = await applicationManager.createProfileSummary(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Record Created Succesfully',
					result
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Record.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	// Fetch User Profile Summary
	async getProfileSummary(req, res, next) {
		try {
			const result = await applicationManager.getProfileSummary(req)
			if (result) {
				if (result.length == 0) {
					return apiResponse.notFoundResponse(res, 'No record found.', [])
				} else {
					return apiResponse.successResponseWithData(
						res,
						'Record fetched successfully',
						result
					)
				}
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	// Delete User Profile Summary
	async deleteUserProfileSummary(req, res, next) {
		try {
			const result = await applicationManager.deleteUserProfileSummary(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Record deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Record.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async updateUserPersonalDetails(req, res, next) {
		try {
			const result = await applicationManager.updateUserPersonalDetails(req, res);

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Personal Details Upated Succesfully',
					result
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Updating Record.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	// Fetch User Personal Detail
	async getPersonalDetails(req, res, next) {
		try {
			const result = await applicationManager.getPersonalDetails(req)
			if (result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Record fetched successfully',
					result
				)
			} else {
				return apiResponse.successResponseWithData(res, '', [])
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async createCareerProfile(req, res, next) {
		try {
			const result = await applicationManager.createCareerProfile(req, res);

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					"Record Created Succesfully",
					result
				);
			} else {
				return apiResponse.forbiddenRequest(
					res,
					"Error while Creating Record."
				);
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error);
		}
	}

	async getCareerProfile(req, res, next) {
		try {
			const result = await applicationManager.getCareerProfile(req, res);
			if (result && result.length > 0) {
				const employementDetails = result[0];
				employementDetails.locations = employementDetails.locations
					? employementDetails.locations.split(',').map(location => ({ location: location.trim() }))
					: [];
				return apiResponse.successResponseWithData(
					res,
					"Record fetched Successfully",
					employementDetails
				);
			} else {
				return apiResponse.successResponseWithData(res, "", []);
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error);
		}
	}


	async updateCompanyDetails(req, res, next) {
		try {
			const result = await applicationManager.updateCompanyDetails(req)
			if (result) {
				return apiResponse.successResponseWithData(
					res,
					'Company Profile Updated Sucessfully',
					result
				)
			} else {
				return apiResponse.notFoundResponse(res, 'Failed to update company profile.', [])
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async updateCompanyInfo(req, res, next) {
		try {
			const result = await applicationManager.updateCompanyInfo(req)
			if (result) {
				return apiResponse.successResponseWithData(
					res,
					'Company Profile Updated Sucessfully',
					result
				)
			} else {
				return apiResponse.notFoundResponse(res, 'Failed to update company profile.', [])
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async updateUserDetails(req, res, next) {
		try {
			const result = await applicationManager.updateUserDetails(req)
			if (result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Record fetched successfully',
					result
				)
			} else {
				return apiResponse.notFoundResponse(res, 'No record found.', [])
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
}

module.exports = { ApplicationController }
