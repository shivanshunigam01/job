const apiResponse = require('../helpers/apiResponse')
const AuthManager = require('../manager/auth.manager.js')
const authManager = new AuthManager()
const utility = require('../helpers/utility')
const db = require('../../config/database.js')
const ApplicationData = require('../dataLayer/application.data.js')
const applicationData = new ApplicationData()
/**
 * Auth Controller.
 */
class AuthController {
  /**
   * User Login.
   * @param {model} login.validators
   * @returns {Object}
   */

  async userLogin (req, res) {
    try {
      let deviceType = req.headers['device-type']
      req.body.deviceType = deviceType
      var result = await authManager.userLogin(req)

      if (result != null && Object.keys(result).length !== 0) {
        // if (result.userID > 0 && result.isConfirm && result.isActive) {
        // 	return apiResponse.successResponseWithData(res, "Login Successfully.", result);
        // }
        // else if (result.userID > 0 && !result.isConfirm) {
        // 	return apiResponse.unauthorizedResponse(res, "Account is not confirmed. Please confirmed your account.");
        // }
        // else if (result.userID > 0 && !result.isActive) {
        // 	return apiResponse.unauthorizedResponse(res, "Account is not active. Please contact admin.");
        // }
        if (result.id > 0 && result.status === 1) {
          return apiResponse.successResponseWithData(
            res,
            'Login Successfully.',
            result
          )
        }
        // else if (result.userID > 0 && !result.isConfirm) {
        // 	return apiResponse.unauthorizedResponse(res, "Account is not confirmed. Please confirmed your account.");
        // }
        else if (result.id > 0 && result.status === 0) {
          return apiResponse.unauthorizedResponse(
            res,
            'Account is not active. Please contact admin.'
          )
        }
      } else {
        return apiResponse.unauthorizedResponse(res, 'Email or Password wrong.')
      }
    } catch (error) {
      return apiResponse.expectationFailedResponse(res, error)
    }
  }

  /**
   * User Registration.
   * @param {model} user.validators
   * @returns {Object}
   */

  async userRegistration (req, res) {
    try {
      let deviceType = req.headers['device-type']
      req.body.deviceType = deviceType
      var result = await authManager.userRegistration(req)

      if (result) {
        // Check if both email and mobile already exist
        if (result.email_flag === 2 && result.mobile_flag === 2) {
          return apiResponse.conflictRequest(
            res,
            'Both Email and Mobile Already Exist.'
          )
        }
        // Check if email already exists
        else if (result.email_flag === 2) {
          return apiResponse.conflictRequest(res, 'Email Already Exists.')
        }
        // Check if mobile already exists
        else if (result.mobile_flag === 2) {
          return apiResponse.conflictRequest(res, 'Mobile Already Exists.')
        }
        // Check for successful registration
        else if (result.flag === 1) {
          return apiResponse.successResponseWithData(
            res,
            'Registration Success.',
            result
          )
        }
        // Handle any other unexpected scenarios
        else {
          return apiResponse.forbiddenRequest(
            res,
            'Error while registering user.'
          )
        }
      } else {
        return apiResponse.forbiddenRequest(
          res,
          'Error while registering user.'
        )
      }
    } catch (error) {
      return apiResponse.expectationFailedResponse(res, error)
    }
  }

  // Forgot password
  async forgotPassword (req, res, next) {
    try {
      const result = await authManager.forgotPassword(req)
      if (result) {
        return apiResponse.successResponseWithData(
          res,
          'OTP sent to your registered email address.',
          result
        )
      } else {
        return apiResponse.unauthorizedResponse(res, 'Email not found.')
      }
    } catch (error) {
      return apiResponse.expectationFailedResponse(res, error)
    }
  }

  // Reset Password
  async otpVerifyResetPassword (req, res, next) {
    try {
      const result = await authManager.otpVerifyResetPassword(req)
      if (result) {
        return apiResponse.successResponse(
          res,
          'Your password has been reset successfully.'
        )
      } else {
        return apiResponse.unauthorizedResponse(res, 'User not found.')
      }
    } catch (error) {
      return apiResponse.expectationFailedResponse(res, error)
    }
  }

  // Change Password
  async changePassword (req, res, next) {
    try {
      const result = await authManager.changePassword(req)
      if (result) {
        if (result[0].flag === 1) {
          // New password is the same as the old password
          return apiResponse.validationErrorWithData(
            res,
            'The new password cannot be the same as the old password.'
          )
        } else if (result[0].flag === 2) {
          // The current password provided is incorrect
          return apiResponse.unauthorizedResponse(
            res,
            'The current password is incorrect.'
          )
        } else {
          // Password has been successfully changed
          return apiResponse.successResponse(
            res,
            'Your password has been changed successfully.'
          )
        }
      } else {
        return apiResponse.unauthorizedResponse(res, 'User not found.')
      }
    } catch (error) {
      return apiResponse.expectationFailedResponse(res, error)
    }
  }
}

module.exports = { AuthController }
