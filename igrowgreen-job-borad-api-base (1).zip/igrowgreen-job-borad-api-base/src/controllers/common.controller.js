const { mode } = require("crypto-js");
const apiResponse = require("../helpers/apiResponse");
const CommonManager = require("../manager/common.manager.js");
const commonManager = new CommonManager();

/**
 * Get Details API
 *
 * @returns {Array}
 */


const getDetails = async (req, res, next) => {
    try {
        const result = await commonManager.getDetails(req, res);
        if (result) {
            return apiResponse.successResponseWithData(res, `Data fatch successfully.`, result);
        }
        else {
            return apiResponse.forbiddenRequest(res, 'Error while storing captcha.');
        }
    } catch (error) {
        return apiResponse.expectationFailedResponse(res, error);
    }
}

const applyFilter = async (req, res, next) => {
    try {
        const result = await commonManager.applyFilter(req, res);
        if (result) {
            return apiResponse.successResponseWithData(res, `Data fatch successfully.`, result);
        }
        else {
            return apiResponse.forbiddenRequest(res, 'Error while fetching filter data.');
        }
    } catch (error) {
        return apiResponse.expectationFailedResponse(res, error);
    }
}


const mainFilter = async (req, res, next) => {
    try {
        const result = await commonManager.mainFilter(req, res);
        if (result) {
            return apiResponse.successResponseWithData(res, `Data fatch successfully.`, result);
        }
        else {
            return apiResponse.forbiddenRequest(res, 'Error while fetching filter data.');
        }
    } catch (error) {
        return apiResponse.expectationFailedResponse(res, error);
    }
}


module.exports = { getDetails,applyFilter,mainFilter };
