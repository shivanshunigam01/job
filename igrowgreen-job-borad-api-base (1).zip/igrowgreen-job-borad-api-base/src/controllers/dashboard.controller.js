const apiResponse = require("../helpers/apiResponse");
const DashboardManager = require('../manager/dashboard.manager.js')
const dashboardManager = new DashboardManager();

class DashboardController {

    async getDashboardList(req, res) {
        try {
            const result = await dashboardManager.getDashboardList(req, res);
    
            // Check if the result is not null or undefined
            if (result) {
                return apiResponse.successResponseWithData(
                    res,
                    "Dashboard Details Successfully Fetched!",
                    result
                );
            } else {
                return apiResponse.forbiddenRequest(
                    res,
                    "Dashboard Details Not Fetched SuccessfullyDetails"
                );
            }
        } catch (error) {
            return apiResponse.expectationFailedResponse(res, error);
        }
    }
}

module.exports = { DashboardController };
