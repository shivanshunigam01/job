const apiResponse = require("../helpers/apiResponse");
const MasterManager = require('../manager/master.manager.js')
const masterManager = new MasterManager();
/**
 * Master Controller.
 */
class MasterController {
	/**
	 * Get Dropdown List.
	 *
	 * @returns {Array}
	 */

	async getStateList(req, res) {
		try {

			var result = await masterManager.getStateList(req);


			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(res, "getStateList Successfully.", { count: result.length, list: result });

			}
			else {
				if (result.length == 0) {
					return apiResponse.successResponseWithData(res, "GetDiscomMasterList List Successfully.", { count: 0, list: [] });
				}
				return apiResponse.unauthorizedResponse(res, "Account is wrong.");
			}
		}
		catch (error) {
			return apiResponse.expectationFailedResponse(res, error);
		}

	}
	async addCategories(req, res) {
		try {
			const result = await masterManager.createCategories(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Categories Created or Updated Succesfully',
					result
				)

			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Category title already exists',
					[]
				)
			}
			else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Categories.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getCategories(req, res) {
		try {
			let resultCount = await masterManager.getCategoriesCount(req)
			let resultList = await masterManager.getCategoriesData(req)
			if (resultList && resultCount) {
				if (resultCount[0].total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				}
				else {
					resultCount[0].pageSize = req.body?.size || 10
					resultCount[0].currentPage = req.body?.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}


				return apiResponse.successResponseWithData(
					res,
					'Categories List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Categories List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}


	async deleteCategories(req, res) {
		try {
			const result = await masterManager.deleteCategories(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Categories deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Categories.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async addDepartments(req, res) {
		try {
			const result = await masterManager.createDepartments(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Departments Created or Updated Succesfully',
					result
				)
			}
			else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Departments title already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Departments.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getDepartments(req, res) {
		try {
			let resultCount = await masterManager.getDepartmentsCount(req)
			let resultList = await masterManager.getDepartmentsData(req)
			if (resultList && resultCount) {
				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				} else {
					resultCount[0].pageSize = req.body?.size || 10
					resultCount[0].currentPage = req.body?.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Departments List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Departments List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteDepartments(req, res) {
		try {
			const result = await masterManager.deleteDepartments(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Departments deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Departments.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async addModules(req, res) {
		try {
			const result = await masterManager.createModules(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Modules Created Or Updated Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Modules title already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Modules.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getModules(req, res) {
		try {
			let resultCount = await masterManager.getModulesCount(req)
			let resultList = await masterManager.getModulesData(req)
			if (resultList && resultCount) {


				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				}
				else {
					resultCount[0].pageSize = req.body?.size || 10
					resultCount[0].currentPage = req.body?.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Modules List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Modules List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteModules(req, res) {
		try {
			const result = await masterManager.deleteModules(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Modules deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Modules.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addLocations(req, res) {
		try {
			const result = await masterManager.createLocations(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Locations Created Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Locations title already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Locations.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getLocations(req, res) {
		try {
			let resultCount = await masterManager.getlocationsCount(req)
			let resultList = await masterManager.getLocationsData(req)
			if (resultList && resultCount) {
				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				}
				else {
					resultCount[0].pageSize = req.body.size || 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Locations List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Locations List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteLocations(req, res) {
		try {
			const result = await masterManager.deleteLocations(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Locations deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Locations.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addEducations(req, res) {
		try {
			const result = await masterManager.createEducations(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Educations Created Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Educations title already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Educations.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getEducations(req, res) {
		try {
			let resultCount = await masterManager.getEducationsCount(req)
			let resultList = await masterManager.getEducationsData(req)
			if (resultList && resultCount) {
				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				}
				else {
					resultCount[0].pageSize = req.body.size || 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Educations List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Educations List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteEducations(req, res) {
		try {
			const result = await masterManager.deleteEducations(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Educations deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Educations.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addIndustryTypes(req, res) {
		try {
			const result = await masterManager.createIndustryTypes(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Industry Types Created Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Industry Types title already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Industry Types.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getIndustryTypes(req, res) {
		try {
			let resultCount = await masterManager.getIndustryTypesCount(req)
			let resultList = await masterManager.getIndustryTypesData(req)
			if (resultList && resultCount) {
				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				} else {
					resultCount[0].pageSize = req.body.size || 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Industry types List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Industry types List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteIndustryTypes(req, res) {
		try {
			const result = await masterManager.deleteIndustryTypes(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Industry Types deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Industry Types.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addSkills(req, res) {
		try {
			const result = await masterManager.createSkills(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Skills Created Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Skills title already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Skills.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getSkills(req, res) {
		try {
			let resultCount = await masterManager.getSkillsCount(req)
			let resultList = await masterManager.getSkillsData(req)
			if (resultList && resultCount) {
				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				} else {
					resultCount[0].pageSize = req.body.size || 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Skills List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Skills List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteSkills(req, res) {
		try {
			const result = await masterManager.deleteSkills(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Skills deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Skills.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addJobTypes(req, res) {
		try {
			const result = await masterManager.createJobTypes(req, res)
			if (result && result.length && result[0]?.flag == 1) {
				return apiResponse.validationErrorWithData(
					res,
					'Job Types title already exists',
					[]
				)
			}
			else if (result && result.length && result[0]?.flag == 2) {
				return apiResponse.successResponseWithData(
					res,
					'Job Types updated Succesfully',
					result
				)
			}
			else if (result  && result.length && result[0]?.flag == 3) {
				return apiResponse.validationErrorWithData(
					res,
					'Job Types title already exists',
					[]
				)
			}
			else if (result && result.length && result[0]?.flag == 4) {
				return apiResponse.successResponseWithData(
					res,
					'Job Types Created Succesfully',
					result
				)
			}

			else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Job Types.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getJobTypes(req, res) {
		try {
			let resultCount = await masterManager.getJobTypesCount(req)
			let resultList = await masterManager.getJobTypesData(req)
			if (resultList && resultCount) {
				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				} else {
					resultCount[0].pageSize = req.body.size || 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Job Types List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Job Types List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteJobTypes(req, res) {
		try {
			const result = await masterManager.deleteJobTypes(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Job Types deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Job Types.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addWorkModes(req, res) {
		try {
			const result = await masterManager.createWorkModes(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Work Modes Created Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Work Modes title already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Work Modes.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getWorkModes(req, res) {
		try {
			let resultCount = await masterManager.getWorkModesCount(req)
			let resultList = await masterManager.getWorkModesData(req)
			if (resultList && resultCount) {

				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				} else {
					resultCount[0].pageSize = req.body.size || 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Work Modes List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Work Modes List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteWorkModes(req, res) {
		try {
			const result = await masterManager.deleteWorkModes(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Work Modes deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Work Modes.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addSalaryTypes(req, res) {
		try {
			const result = await masterManager.createSalaryTypes(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Salary Types Created Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Salary Types title already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Salary Types.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getSalaryTypes(req, res) {
		try {
			let resultCount = await masterManager.getSalaryTypesCount(req)
			let resultList = await masterManager.getSalaryTypesData(req)
			if (resultList && resultCount) {

				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				} else {
					resultCount[0].pageSize = req.body.size || 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Salary Types List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Salary Types List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteSalaryTypes(req, res) {
		try {
			const result = await masterManager.deleteSalaryTypes(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Salary Types deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Salary Types.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addShiftTimes(req, res) {
		try {
			const result = await masterManager.createShiftTimes(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Shift Times Created Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Shift Times title already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Shift Times.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getShiftTimes(req, res) {
		try {
			let resultCount = await masterManager.getShiftTimesCount(req)
			let resultList = await masterManager.getShiftTimesData(req)
			if (resultList && resultCount) {
				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				}
				else {
					resultCount[0].currentPage = req.body?.page ?? 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
					resultCount[0].pageSize = req.body.size ?? 10
				}

				return apiResponse.successResponseWithData(
					res,
					'Shift Times List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Shift Times List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteShiftTimes(req, res) {
		try {
			const result = await masterManager.deleteShiftTimes(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Shift Times deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Shift Times.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addTotalExperiences(req, res) {
		try {
			const result = await masterManager.createTotalExperiences(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Total Experiences Created Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'Total Experiences Years already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating Total Experiences.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getTotalExperiences(req, res) {
		try {
			let resultCount = await masterManager.getTotalExperiencesCount(req)
			let resultList = await masterManager.getTotalExperiencesData(req)
			if (resultList && resultCount) {

				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				} else {
					resultCount[0].pageSize = req.body.size ?? 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Total Experiences List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Total Experiences List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteTotalExperiences(req, res) {
		try {
			const result = await masterManager.deleteTotalExperiences(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Total Experiences deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Total Experiences.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async addSalaries(req, res) {
		try {
			const result = await masterManager.createSalaries(req, res)
			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'salaries Created Succesfully',
					result
				)
			} else if (result === null) {
				return apiResponse.validationErrorWithData(
					res,
					'salaries  already exists',
					[]
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while Creating salaries.')
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)

		}
	}
	async getSalaries(req, res) {
		try {
			let resultCount = await masterManager.getSalariesCount(req)
			let resultList = await masterManager.getSalariesData(req)
			if (resultList && resultCount) {

				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0

				} else {
					resultCount[0].pageSize = req.body.size ?? 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Salaries List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Salaries List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async deleteSalaries(req, res) {
		try {
			const result = await masterManager.deleteSalaries(req, res)

			if (result && result.length > 0) {
				return apiResponse.successResponseWithData(
					res,
					'Salaries deleted Succesfully'
				)
			} else {
				return apiResponse.forbiddenRequest(res, 'Error while deleting Salaries.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async getCompanies(req, res) {
		try {
			let resultCount = await masterManager.getCompaniesCount(req)
			let resultList = await masterManager.getCompaniesData(req)
			if (resultList && resultCount) {
				if (resultCount[0]?.total_count == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				} else {
					resultCount[0].pageSize = req.body.size ?? 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.total_count / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Companies List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Companies List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	async getCompaniesJobPostList(req, res) {
		try {
			let resultCount = await masterManager.getCompaniesJobPostListCount(req)
			let resultList = await masterManager.getCompaniesJobPostListData(req)
			if (resultList && resultCount) {

				// const newList = resultList.map(item => {
				// 	// Convert comma-separated skills into an array of objects
				// 	item.skills = item.skills
				// 		? item.skills.split(',').map(skill => ({ skill: skill.trim() }))
				// 		: []

				// 	// Uncomment and modify if you need to encrypt IDs or perform other transformations
				// 	// item.id = encryptID(item.id);

				// 	return item
				// })
				if (resultCount[0]?.totalRecords == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].total_page = 0
					resultCount[0].pageSize = 0
				} else {
					resultCount[0].pageSize = req.body.size ?? 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.totalRecords / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Companies Job Post List Fetched Successfully.',
					{ count: resultCount, list: resultList }
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Companies Job Post List Fetched Successfully.',
						{ count: resultCount, list: resultList }
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async getCompaniesJobAppliedUserList(req, res) {
		try {
			let resultCount = await masterManager.getCompaniesJobAppliedUserListCount(req)
			let resultList = await masterManager.getCompaniesJobAppliedUserListData(req)
			if (resultList && resultCount) {

				if (resultCount[0]?.totalRecords == 0) {
					resultCount[0].currentPage = 0
					resultCount[0].pageSize = 0
					resultCount[0].total_page = 0
				} else {
					resultCount[0].pageSize = req.body?.size ?? 10
					resultCount[0].currentPage = req.body.page || 1
					resultCount[0].total_page = Math.ceil(resultCount[0]?.totalRecords / req.body?.size)
				}

				return apiResponse.successResponseWithData(
					res,
					'Companies Job Post List Fetched Successfully.',
					{
						count: resultCount,
						list: Object.values(resultList[1]),
						jobDetails: resultList[0][0]
					}
				)
			} else {
				if (resultCount == 0) {
					return apiResponse.successResponseWithData(
						res,
						'Companies Job Post List Fetched Successfully.',
						{
							count: resultCount,
							list: Object.values(resultList[1]),
							jobDetails: resultList[0][0]
						}
					)
				}
				return apiResponse.unauthorizedResponse(res, 'Account is wrong.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}
	async updateStatus(req, res) {
		try {
			const result = await masterManager.updateStatus(req)
			if (result.length) {
				return apiResponse.successResponseWithData(
					res,
					'status updated successfully',
					result
				)
			}
			else {
				const key = Object.keys(req?.body)[0]?.split('_')[0] ?? 'user'
				return apiResponse.unauthorizedResponse(res, `${key} not found.`)
			}

		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	// Forgot password
	async forgotPassword(req, res) {
		try {
			const result = await masterManager.forgotPassword(req)
			if (result) {
				return apiResponse.successResponseWithData(
					res,
					'OTP sent to your registered email address.',
					result
				)
			} else {
				return apiResponse.unauthorizedResponse(res, 'Email not found.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	// Reset Password
	async otpVerifyResetPassword(req, res) {
		try {
			const result = await masterManager.otpVerifyResetPassword(req)
			if (result) {
				return apiResponse.successResponse(
					res,
					'Your password has been reset successfully.'
				)
			} else {
				return apiResponse.unauthorizedResponse(res, 'User not found.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

	// Change Password
	async changePassword(req, res, next) {
		try {
			const result = await masterManager.changePassword(req)
			if (result) {
				if (result[0].flag === 1) {
					// New password is the same as the old password
					return apiResponse.validationErrorWithData(
						res,
						'The new password cannot be the same as the old password.'
					)
				} else if (result[0].flag === 2) {
					// The current password provided is incorrect
					return apiResponse.unauthorizedResponse(
						res,
						'The current password is incorrect.'
					)
				} else {
					// Password has been successfully changed
					return apiResponse.successResponse(
						res,
						'Your password has been changed successfully.'
					)
				}
			} else {
				return apiResponse.unauthorizedResponse(res, 'User not found.')
			}
		} catch (error) {
			return apiResponse.expectationFailedResponse(res, error)
		}
	}

}

module.exports = { MasterController };