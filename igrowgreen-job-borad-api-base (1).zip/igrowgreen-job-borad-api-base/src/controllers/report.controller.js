const apiResponse = require("../helpers/apiResponse");
const ReportManager = require('../manager/report.manager.js')
const reportManager = new ReportManager();
/**
 * Report Controller.
 */
class ReportController {
    /**
     * Get Dropdown List.
     *
     * @returns {Array}
     */
    async SendLeadotp(req, res) {
      try {
        var result = await reportManager.SendLeadotp(req);
        if (result) {
          return apiResponse.successResponseWithData(
            res,
            "OTP is sent to the registered email and mobile number of the Consumer. Kindly take the OTP from the Consumer and Verify it. ",
           // { list: result }
          );
        } else {
          return apiResponse.unauthorizedResponse(res, "Error");
        }
      } catch (error) {
        return apiResponse.expectationFailedResponse(res, error);
      }
    }
}


module.exports = { ReportController };