const apiResponse = require("../helpers/apiResponse");
const TicketManager = require('../manager/ticket.manager.js')
const ticketManager = new TicketManager();
/**
 * Ticket Controller.
 */
class TicketController {
/**
 * Get Dropdown List.
 *
 * @returns {Array}
 */
    async ticketList(req, res) {
        try {
            // let deviceType = req.headers["device-type"];
            // req.body.deviceType = deviceType;
            var resultCount = await ticketManager.ticketCount(req);
            var resultList = await ticketManager.ticketList(req);
           
            if (resultList && resultCount) {
                return apiResponse.successResponseWithData(res, "Ticket List Successfully.", {count: resultCount, list: resultList});
                // if (result.userID > 0 && result.isConfirm && result.isActive) {
                // 	return apiResponse.successResponseWithData(res, "Login Successfully.", result);
                // }
                // else if (result.userID > 0 && !result.isConfirm) {
                // 	return apiResponse.unauthorizedResponse(res, "Account is not confirmed. Please confirmed your account.");
                // }
                // else if (result.userID > 0 && !result.isActive) {
                // 	return apiResponse.unauthorizedResponse(res, "Account is not active. Please contact admin.");
                // }
                // if (result.id > 0 && result.status===1 ) {
                //     return apiResponse.successResponseWithData(res, "Login Successfully.", result);
                // }
                // else if (result.userID > 0 && !result.isConfirm) {
                // 	return apiResponse.unauthorizedResponse(res, "Account is not confirmed. Please confirmed your account.");
                // }
                // else if (result.id > 0 && result.status===0) {
                //     return apiResponse.unauthorizedResponse(res, "Account is not active. Please contact admin.");
                // }
            }
            else {
                if(resultCount==0){
                    return apiResponse.successResponseWithData(res, "Ticket List Successfully.", {count: resultCount, list: resultList});
                }
                return apiResponse.unauthorizedResponse(res, "Account is wrong.");
            }
        }
        catch (error) {
            return apiResponse.expectationFailedResponse(res, error);
        }
    }

 
    async getTicketSubcategoryList(req, res) {
        try {
          
            // var resultCount = await ticketManager.getTicketSubcategoryList(req);
            var resultList = await ticketManager.getTicketSubcategoryList(req);
           

            if (resultList) {

                return apiResponse.successResponseWithData(res, "Ticket List Successfully.", {list: resultList});
                
            }
            else {
                if(resultCount==0){
                    return apiResponse.successResponseWithData(res, "Ticket List Successfully.", { list: resultList});
                }
                return apiResponse.unauthorizedResponse(res, "Account is wrong.");
            }
        }
        catch (error) {
            return apiResponse.expectationFailedResponse(res, error);
        }

    }


    //Ticket List API
    async getTicketList(req, res) {
        try {
          
            // var resultCount = await ticketManager.getTicketSubcategoryList(req);
            var resultList = await ticketManager.getTicketList(req);
           

            if (resultList) {

                return apiResponse.successResponseWithData(res, "Ticket List Successfully.", {list: resultList});
                
            }
            else {
                if(resultCount==0){
                    return apiResponse.successResponseWithData(res, "Ticket List Successfully.", { list: resultList});
                }
                return apiResponse.unauthorizedResponse(res, "Account is wrong.");
            }
        }
        catch (error) {
            return apiResponse.expectationFailedResponse(res, error);
        }

    }






    async ticketCreate(req, res) {
        try {
            // let deviceType = req.headers["device-type"];
            // req.body.deviceType = deviceType;
            var result = await ticketManager.ticketCreate(req,res);
        
            
    
            if (result) {
                return apiResponse.successResponseWithData(res, "Ticket Created Successfully.", {application_id: result });
                
            }
            else {
                if(resultCount==0){
                    return apiResponse.successResponseWithData(res, "Ticket Created Successfully.", {application_id: result });
                }
                return apiResponse.unauthorizedResponse(res, "Account is wrong.");
            }
        }
        catch (error) {
            return apiResponse.expectationFailedResponse(res, error);
        }

    }

    //Update and Get Task
    async updateTask(req, res, next) {
        try {
          const result = await ticketManager.updateTask(
            req,
            res
          );
    
          if (result && result.applicationID !== null) {
            return apiResponse.successResponseWithData(
              res,
              `Task updated successfully.`,
              result.data
            );
          } else {
            return apiResponse.forbiddenRequest(
              res,
              "Error while updating task."
            );
          }
        } catch (error) {
          return apiResponse.expectationFailedResponse(res, error);
        }
      }

      async getTaskDetails(req, res, next) {
        try {
          const result = await ticketManager.getTaskDetails(
            req,
            res
          );
    
          if (result && result.applicationID !== null) {
            return apiResponse.successResponseWithData(
              res,
              `Task fetched successfully.`,
              result
            );
          } else {
            return apiResponse.forbiddenRequest(
              res,
              "Error while fetching task."
            );
          }
        } catch (error) {
          return apiResponse.expectationFailedResponse(res, error);
        }
      }

}

module.exports = { TicketController };