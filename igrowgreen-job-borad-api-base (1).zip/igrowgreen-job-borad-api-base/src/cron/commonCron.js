// var cron = require('node-cron');


// // Periodic reminder for submission of Registration documents (every 10 days)
// const registrationDocumentCron = cron.schedule('* * * * *', () => {
// 	console.log('running every minute 1');
// });

// const deleteFileCron = cron.schedule('* * * * *', () => {
// 	console.log('running every minute 2');
// });

// module.exports = {deleteFileCron,registrationDocumentCron};
