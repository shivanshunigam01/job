const { error } = require("winston");
const db = require("../../config/database.js");
const models = require('../../models')
const securePassword = require("../utils/securePassword");
const { hash } = require("bcryptjs");
var crypto = require('crypto');
const utility=require('../helpers/utility.js')

/**
 * Auth Data.
 */
class AccountData {

    /**
     * User Login.
     * @param {model} login.validators
     * @returns {Object}
     */
    async userProfile(req) {
      
        const userID = req.user.userID;
        const procedureName = "usp_getUserData";
        try {
            const user = await db.query(`CALL ${procedureName}(:userID)`, {
                replacements: { userID },
                type: db.QueryTypes.RAW,
            });

            // if(user){
            //     user[0].type=utility.encryptData(user[0].type);
            // }

            return user;
        } catch (error) {
            throw error;
        }
    }

}

module.exports = AccountData;
