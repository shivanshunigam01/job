const db = require('../../config/database.js')
const helper = require('../helpers/helper.js')
const requestIp = require('request-ip')
const uaParser = require('ua-parser-js')
const axios = require('axios')
const moment = require('moment')
const {
    applicationStage,
    smsTypeVerifyOtp,
    smsTypeSendOtp,
    smsTypeDocumentsSubmission,
    smsTypeDocumentsVerification,
    smsTypeDocumentsRejection
} = require('../helpers/constants.js')
const fs = require('fs')
const path = require('path')
const ejs = require('ejs')
const mailer = require('../helpers/mailer')
const utility = require('../helpers/utility')
const { emailConst, meterTypeDropDown } = require('../helpers/constants')
const { log } = require('console')
const { encryptData, decryptData } = require('../helpers/utility.js')
const CommonData = require('../dataLayer/common.data.js')
const models = require('../../models')
const commonData = new CommonData()

require('dotenv').config()

const Remote = require('../helpers/remote.js')

/**
 * Auth Data.
 */
class ApplicationData {
    /**
     * User Login.
     * @param {model} login.validators
     * @returns {Object}
     */

    async categorieslist(req) {
        const procedureName = 'usp_getCategorieslist'
        try {
            const applicationResponse = await db.query(`CALL ${procedureName}`, {
                replacements: {},
                type: db.QueryTypes.RAW
            })
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async getCategoryAndJobCountFromJob(req) {
        const procedureName = 'usp_getCategoryAndJobCountFromJob'
        try {
            const applicationResponse = await db.query(`CALL ${procedureName}`, {
                replacements: {},
                type: db.QueryTypes.SELECT
            })
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async locationslist(req) {
        const procedureName = 'usp_getLocationlist'
        try {
            const applicationResponse = await db.query(`CALL ${procedureName}`, {
                replacements: {},
                type: db.QueryTypes.RAW
            })
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async departmentlist(req) {
        const procedureName = 'usp_getDepartmentlist'
        try {
            const applicationResponse = await db.query(`CALL ${procedureName}`, {
                replacements: {},
                type: db.QueryTypes.RAW
            })
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async educationslist(req) {
        const procedureName = 'usp_getEducationslist'
        try {
            const applicationResponse = await db.query(`CALL ${procedureName}`, {
                replacements: {},
                type: db.QueryTypes.RAW
            })
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async industryTypeslist(req) {
        const procedureName = 'usp_getIndustryTypeslist'
        try {
            const applicationResponse = await db.query(`CALL ${procedureName}`, {
                replacements: {},
                type: db.QueryTypes.RAW
            })
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async skillslist(req) {
        const procedureName = 'usp_getSkillslist'
        try {
            const applicationResponse = await db.query(`CALL ${procedureName}`, {
                replacements: {},
                type: db.QueryTypes.RAW
            })
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    //// Get paramaters Details
    async getParameters(req) {
        const parameterId = req.body.parameterId || ''
        const procedureName = 'usp_getParameters'
        try {
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:parameterId )`,
                {
                    replacements: { parameterId },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    /**
     * User Login.
     * @param {model} login.validators
     * @returns {Object}
     */

    async createJobList(req, skill_XML) {
        const procedureName = 'usp_createJobList';
    
        try {
            const company_name = req.body.company_name || '';
            const contact_user_name = req.body.contact_user_name || '';
            const contact_user_mobile = req.body.contact_user_mobile || '';
            const contact_user_email = req.body.contact_user_email || '';
            const job_title_name = req.body.job_title_name || '';
            const on_location_job = req.body.on_location_job || '';
            const department = req.body.department || '';
            const job_type = req.body.job_type || '';
            const job_address = req.body.job_address || '';
            const salary_type = req.body.salary_type || '';
            const salary_range_between = req.body.salary_range_between || '';
            const salary_range_type = req.body.salary_range_type || '';
            const job_description = req.body.job_description || '';
            const work_mode = req.body.work_mode || '';
            const shift_time = req.body.shift_time || '';
            const job_qualification = req.body.job_qualification || '';
            const total_experience = req.body.total_experience || '';
            const job_category = req.body.job_category || 0;
            const no_of_people_hiring = req.body.no_of_people_hiring || 0;
            const userId= req.user.userID;
            let job_id = req.body.job_id || 0;
                    // if(job_id==''){
                    //     job_id=0;
                    // }
    
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:company_name, :contact_user_name, :contact_user_mobile,
                :contact_user_email, :job_title_name, :no_of_people_hiring, :on_location_job, :department, 
                :total_experience, :job_type, :job_address, :salary_type, :salary_range_between, :salary_range_type,
                :job_description, :skill_XML, :job_category, :work_mode, :shift_time, :job_qualification, :userId, :job_id)`,
                {
                    replacements: {
                        company_name,
                        contact_user_name,
                        contact_user_mobile,
                        contact_user_email,
                        job_title_name,
                        no_of_people_hiring,
                        on_location_job,
                        department,
                        total_experience,
                        job_type,
                        job_address,
                        salary_type,
                        salary_range_between,
                        salary_range_type,
                        job_description,
                        skill_XML,
                        job_category,
                        work_mode,
                        shift_time,
                        job_qualification,
                        userId,
                        job_id
                    },
                    type: db.QueryTypes.RAW
                }
            );
    
            return applicationResponse;
        } catch (error) {
            console.error('Error in while creating Job List:', error);
            throw error;
        }
    }
    

    async createUserSkill(req, skill_XML) {
        const procedureName = 'usp_user_skill'
        try {
            const userId = req?.user?.userID || 0
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId,:skill_XML)`,
                {
                    replacements: {
                        userId,
                        skill_XML
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Skills List:', error)
            throw error
        }
    }

    async getResumeHeadline(req, res) {
        try {
            const userId = req?.user?.userID || 0
            const procedureName = 'usp_getResumeHeadline'
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId)`,
                {
                    replacements: {
                        userId
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            console.error('Error in while fetching', error)
            throw error
        }
    }

    async getUserSkill(req, res) {
        try {
            const userId = req?.user?.userID || 0
            const procedureName = 'usp_getUser_skill'
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId)`,
                {
                    replacements: {
                        userId
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Job List:', error)
            throw error
        }
    }

    async getUserEmployement(req, res) {
        try {
            const userId = req?.user?.userID || 0;
            const procedureName = 'usp_getUser_employment';
            
            const results = await db.query(
                `CALL ${procedureName}(:userId)`,
                {
                    replacements: { userId },
                    type: db.QueryTypes.RAW
                }
            );
    
            const userEmploymentData = results || [];

            const fixedData = userEmploymentData.map(row => {
                let skillsString = row.skills || "[]";
                let skillsObject = [];
    
                try {
                    if (typeof skillsString === 'string') {
                    //     skillsString = skillsString.replace(/'/g, '"');
                        // skillsString = skillsString.replace(/([{,]\s*)\w+:/g, '$1"$2":');
                        skillsString = JSON.parse(skillsString);
                    }

                    if (Array.isArray(skillsString)) {
                        skillsString.forEach((skill, index) => {
                            skillsObject[index] = skill;
                        });
                    } else {
                        console.warn('skillsString is not an array', skillsString);
                    }
    
                } catch (error) {
                    console.error('Error parsing skillsString:', error);
                    skillsObject = [];
                }
                
                return { ...row, skills: skillsObject };
            });
            return fixedData
    
        } catch (error) {
            console.error('Error in while fetching:', error)
            throw error
        }
    }
    

    async createUserEmployement(req) {
        const procedureName = 'usp_createEmployement'
        const skillInsertProcedureName = 'usp_createSkillsEmployement'
        const deleteSkillsProcedureName = 'usp_deleteSkillsByEmployementId'
        try {
            const userId = req?.user?.userID || null;
            const empDetailsId = req.body.empDetailsId || null;
            const current_employement = req.body.current_employement || ''
            const type = req.body.type || ''
            const experience_year = req.body.experience_year || ''
            const experience_month = req.body.experience_month || ''
            const company_name = req.body.company_name || ''
            const job_title = req.body.job_title || ''
            const joining_date = req.body.joining_date || ''
            const worked_till = req.body.worked_till || ''
            const salary = req.body.salary || ''
            const job_profile = req.body.job_profile || ''
            const notice_period = req.body.notice_period || ''
            const skills = req.body.skills ||''

            if(empDetailsId){
                const deleteSkills = await db.query(
                    `CALL ${deleteSkillsProcedureName}(:userId, :empDetailsId)`,
                    {
                        replacements: { userId, empDetailsId },
                        type: db.QueryTypes.RAW
                    }
                )
                console.log('deleted Skills',deleteSkills);
            }

            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId, :empDetailsId, :current_employement, :type, :experience_year, :experience_month, :company_name, :job_title, :joining_date, :worked_till, :salary, :job_profile, :notice_period)`,
                {
                    replacements: { userId, empDetailsId, current_employement,type,experience_year,experience_month,company_name,job_title,joining_date,worked_till,salary,job_profile,notice_period
                    },
                    type: db.QueryTypes.RAW
                }
            )
            const emp_Id = applicationResponse[0]?.result;

            if (emp_Id && skills.length > 0) {
                for (const item of skills) {
                    // const id = item.id || null;
                    const skill_id = item.skill_id || null;
    
                    await db.query(
                        `CALL ${skillInsertProcedureName}(:skill_id,:emp_Id,:userId)`,
                        {
                            replacements: { skill_id,emp_Id,userId },
                            type: db.QueryTypes.RAW
                        }
                    );
                }
            }

            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Skills List:', error)
            throw error
        }
    }

    async createUserEducation(req) {
        const procedureName = 'usp_createuserEducation'
        try {
            const userId = req?.user?.userID || 0
            // const userId = req.body.userID || "";
            const education = req.body.education || ''
            const university = req.body.university || ''
            const course = req.body.course || ''
            const speclialization = req.body.speclialization || ''
            const course_type = req.body.course_type || ''
            const course_start_year = req.body.course_start_year || ''
            const course_end_year = req.body.course_end_year || ''
            const grading_system = req.body.grading_system || ''
            const grades = req.body.grades || ''
            const eduID = req.body.edu_id || ''

            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId, :education, :university, :course, :speclialization, :course_type, :course_start_year, :course_end_year, :grading_system, :grades, :eduID)`,
                {
                    replacements: {
                        userId,
                        education,
                        university,
                        course,
                        speclialization,
                        course_type,
                        course_start_year,
                        course_end_year,
                        grading_system,
                        grades,
						eduID
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Record', error)
            throw error
        }
    }

    async getUserEducation(req) {
        const procedureName = 'usp_getUserEducation'
        try {
            const userId = req?.user?.userID || 0
            // const userId = req.body.userID || "";

            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId)`,
                {
                    replacements: {
                        userId,
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            console.error('Error in while Fetching Record', error)
            throw error
        }
    }

    async getJobListData(req, res) {
        try {
            const procedureName = 'usp_getJobListData';
    
            const page = req.body.page || 1;
            const size = req.body.size || 10;
            const search = req.body.search || '';
            const job_category = req.body.job_category || '';
            const work_mode = req.body.work_mode || '';  
            const exp = req.body.exp || 0;                
            const department = req.body.department || ''; 
            const location = req.body.location || '';     
            const salary = req.body.salary || 0;          
            const education = req.body.education || '';   
            const userId = req.user.userID || 0;
            const skill_dept_company = req.body.skill_dept_company || '';
            // Query the database with the updated procedure
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:page, :size, :search, :job_category, :work_mode, :exp, :department, :location, :salary, :education, :userId, :skill_dept_company)`, 
                {
                    replacements: {
                        page,
                        size,
                        search,
                        job_category,
                        work_mode,
                        exp,
                        department,
                        location,
                        salary,
                        education,
                        userId,
                        skill_dept_company // Add this to the replacements
                    },
                    type: db.QueryTypes.RAW
                }
            );
    
            return applicationResponse;
        } catch (error) {
            console.error('Error in while creating Job List:', error)
            throw error
        }
    }
    

    async getJobListCount(req, res) {
        try {
            const procedureName = 'usp_getJobListCount';
    
            // Get all necessary parameters from the request body or use defaults
            const search = req.body.search || '';
            const job_category = req.body.job_category || '';
            const work_mode = req.body.work_mode || '';
            const exp = req.body.exp || 0;
            const department = req.body.department || '';
            const location = req.body.location || '';
            const salary = req.body.salary || 0;
            const education = req.body.education || '';
            const user_id = req.body.user_id || null;
            const skill_dept_company = req.body.skill_dept_company || '';
    
            // Call the stored procedure with the updated parameters
            const applicationResponse = await db.query(
                `CALL ${procedureName}(
                    :search,
                    :job_category,
                    :work_mode,
                    :exp,
                    :department,
                    :location,
                    :salary,
                    :education,
                    :user_id,
                    :skill_dept_company
                )`,
                {
                    replacements: {
                        search,
                        job_category,
                        work_mode,
                        exp,
                        department,
                        location,
                        salary,
                        education,
                        user_id,
                        skill_dept_company
                    },
                    type: db.QueryTypes.RAW
                }
            );
    
            return applicationResponse;
        } catch (error) {
            console.error('Error while getting Job List Count:', error);
            throw error;
        }
    }
    

    async ResumeUpload(req) {
        // const userId = req.body.userID || "";
        const userId = req?.user?.userID || 0
        const fileName = req.files[0].filename
        const procedureName = 'usp_ResumeUpload'
        try {
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId, :fileName)`,
                {
                    replacements: {
                        userId,
                        fileName
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async ResumeHeadline(req) {
        const userId = req.user.userID || ''
        const resume_headline = req.body.resume_headline || ''
        const procedureName = 'usp_ResumeHeadline'
        try {
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId, :resume_headline)`,
                {
                    replacements: {
                        userId,
                        resume_headline
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async jobApply(req) {
        const jobId = req.body.jobId || ''
        const userId = req.user.userID
        const resume = req.body.resume || ''

        // const fileName = req.files[0].filename;
        const procedureName = 'usp_jobApply'
        try {
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:jobId, :userId, :resume)`,
                {
                    replacements: {
                        jobId,
                        userId,
                        resume
                    },
                    type: db.QueryTypes.RAW
                }
            )

            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async getJobDatabyID(req) {
        const jobId = req.body.jobId || ''

        // const fileName = req.files[0].filename;
        const procedureName = 'usp_jobDetails'
        try {
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:jobId)`,
                {
                    replacements: {
                        jobId
                    },
                    type: db.QueryTypes.RAW
                }
            )

            return applicationResponse
        } catch (error) {
            throw error
        }
    }
    //API to get common status data
    async getCommonStatus(req) {
        const userId = req.user.userID || ''
        const procedureName = 'usp_getCommonStatusRecord'
        try {
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId)`,
                {
                    replacements: {
                        userId
                    },
                    type: db.QueryTypes.RAW
                }
            )

            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async getJobMatches(req) {
        const company_name = req.body.company_name || ''
        const procedureName = 'usp_getJobMatches'
        try {
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:company_name)`,
                {
                    replacements: {
                        company_name
                    },
                    type: db.QueryTypes.RAW
                }
            )

            return applicationResponse
        } catch (error) {
            throw error
        }
    }

    async getJobPostListData(req, res) {
        try {
            const procedureName = 'usp_getJobPostListData'

            const page = req.body.page || 1
            const size = req.body.size || 10
            const search = req.body.search || ''
            const job_category = req.body.job_category || ''
            // const userId = req.body.userID || 0
            const userId = req.user.userID || 0 

            const applicationResponse = await db.query(
                `CALL ${procedureName}(:page,:size,:search,:job_category,:userId)`,
                {
                    replacements: {
                        page,
                        size,
                        search,
                        job_category,
                        userId
                    },
                    type: db.QueryTypes.RAW
                }
            )

            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Job List:', error)
            throw error
        }
    }

    async getJobPostListCount(req, res) {
        try {
            const procedureName = 'usp_getJobPostListCount'

            const page = req.body.page || 1
            const size = req.body.size || 10
            const search = req.body.search || ''
            const job_category = req.body.job_category || ''
            // console.log("user",req.user)
            const userId = req.user.userID || 0
            // con

            const applicationResponse = await db.query(
                `CALL ${procedureName}(:page,:size,:search,:job_category,:userId)`,
                {
                    replacements: { page, size, search, job_category, userId },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Job List:', error)
            throw error
        }
    }

    async updateJobStatus(req, res) {
        try {
            const procedureName = 'usp_updateJobStatus'

            // const status=req.body?.status;
            const job_id = req.body?.job_id
            const userId = req?.user?.userID || 0

            const applicationResponse = await db.query(
                `CALL ${procedureName}(:job_id,:userId)`,
                {
                    replacements: {
                        job_id,
                        userId
                    },
                    type: db.QueryTypes.RAW
                }
            )

            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Job List:', error)
            throw error
        }
    }

    async getJobAppliedUserListData(req, res) {
        try {
            const procedureName = 'usp_getJobAppliedUserListData'

            // const status=req.body?.status;
            const page = req.body.page || 1
            const size = req.body.size || 10
            const search = req.body.search || ''
            const job_id = req.body?.job_id
            const userId = req?.user?.userID || 0

            const applicationResponse = await db.query(
                `CALL ${procedureName}(:search,:size,:page,:job_id,:userId)`,
                {
                    replacements: {
                        search,
                        size,
                        page,
                        job_id,
                        userId
                    },
                    type: db.QueryTypes.SELECT
                }
            )

            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Job List:', error)
            throw error
        }
    }

    async getJobAppliedUserListCount(req, res) {
        try {
            const procedureName = 'usp_getJobAppliedUserListCount'

            const page = req.body.page || 1
            const size = req.body.size || 10
            const search = req.body.search || ''
            const job_category = req.body.job_category || ''
            // console.log("user",req.user)
            const userId = req.user.userID || 0
            // con

            const applicationResponse = await db.query(
                `CALL ${procedureName}(:page,:size,:search,:job_category,:userId)`,
                {
                    replacements: { page, size, search, job_category, userId },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Job List:', error)
            throw error
        }
    }

    async getJobSeekersJobAppliedListCount(req, res) {
        try {
            const procedureName = "usp_getJobSeekersJobAppliedListCount";

            const page = req.body.page || 1;
            const size = req.body.size || 10;
            const search = req.body.search || '';
            // const job_category = req.body.job_category || '';
            // console.log("user",req.user)
            const userId = req.user.userID || 0;
            // con

            const applicationResponse = await db.query(`CALL ${procedureName}(:page,:size,:search,:userId)`, {
                replacements: { page, size, search, userId },
                type: db.QueryTypes.RAW
            })
            return applicationResponse;
        } catch (error) {
            console.error("Error in while creating Job List:", error);
            throw error;
        }

    }


    async saveUnsaveJob(req, res) {
        try {
            const procedureName = "usp_saveJob";
            const job_id = req.body.job_id;
            const userId = req.user.userID || 0;
            const applicationResponse = await db.query(`CALL ${procedureName}(:job_id,:userId)`, {
                replacements: { job_id, userId },
                type: db.QueryTypes.RAW
            })
            return applicationResponse;
        } catch (error) {
            console.error("Error in while creating Job List:", error);
            throw error;
        }

    }


    async savedUnsavedJobList(req, res) {
        try {
            const procedureName = "usp_getSavedJobDetails";
            const userId = req.body.userID;
            const applicationResponse = await db.query(`CALL ${procedureName}(:userId)`, {
                replacements: { userId },
                type: db.QueryTypes.RAW
            })
            return applicationResponse;
        } catch (error) {
            console.error("Error in while creating Job List:", error);
            throw error;
        }

    }
    async getJobSeekersJobAppliedListData(req, res) {
        try {
            const procedureName = "usp_getJobSeekersJobAppliedListData";

            const page = req.body.page || 1;
            const size = req.body.size || 10;
            const search = req.body.search || '';
            // const job_category = req.body.job_category || '';
            // console.log("user",req.user)
            const userId = req.user.userID;


            const applicationResponse = await db.query(`CALL ${procedureName}(:page,:size,:search,:userId)`, {
                replacements: { page, size, search, userId },
                type: db.QueryTypes.RAW
            })
            return applicationResponse;
        } catch (error) {
            console.error("Error in while creating Job List:", error);
            throw error;
        }

    }



    async updateUserITSkills(req) {
        const procedureName = 'usp_updateUserITSkills'
        try {
            const userId = req?.user?.userID || 0;
            const skillId = req.body.skillId || 0
            const actionType = req.body.actionType
            const skillName = req.body.skillName || ''
            const softwareVersion = req.body.softwareVersion || ''
            const lastUsed = req.body.lastUsed || ''
            const experienceYear = req.body.experienceYear || ''
            const experienceMonth = req.body.experienceMonth || ''

            const result = await db.query(
                `CALL ${procedureName}(:userId,:skillId,:actionType, :skillName, :softwareVersion, :lastUsed, :experienceYear, :experienceMonth)`,
                {
                    replacements: {
                        userId,
                        skillId,
                        actionType,
                        skillName,
                        softwareVersion,
                        lastUsed,
                        experienceYear,
                        experienceMonth
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return result
        } catch (error) {
            console.error('Error in while creating Record', error)
            throw error
        }
    }

    async deleteUserITSkills(req) {
        const procedureName = 'usp_deleteUserITSkills'
        try {
            const userId = req?.user?.userID || 64
            const skillId = req.body.skillId || 0

            const result = await db.query(`CALL ${procedureName}(:userId,:skillId)`, {
                replacements: {
                    userId,
                    skillId
                },
                type: db.QueryTypes.RAW
            })
            return result
        } catch (error) {
            console.error('Error in while creating Record', error)
            throw error
        }
    }

    async getUserITSkillsList(req) {
        const userId = req?.user?.userID || 64
        const procedureName = 'usp_getITSkillslist'
        try {
            const result = await db.query(`CALL ${procedureName}(:userId)`, {
                replacements: { userId },
                type: db.QueryTypes.RAW
            })
            return result
        } catch (error) {
            throw error
        }
    }

    // Create or Update User Profile Summary
    async createProfileSummary(req) {
        const procedureName = 'usp_createOrUpdateProfileSummary'
        try {
            const userId = req?.user?.userID || 0;
            const profile_summary = req.body.profile_summary || ''
            const result = await db.query(
                `CALL ${procedureName}(:userId, :profile_summary)`,
                {
                    replacements: {
                        userId,
                        profile_summary
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return result
        } catch (error) {
            console.error('Error in while creating Record', error)
            throw error
        }
    }

    // Fetch User Profile Summary
    async getProfileSummary(req) {
        const userId = req?.user?.userID || 0
        const procedureName = 'usp_getProfileSummary'
        try {
            const result = await db.query(`CALL ${procedureName}(:userId)`, {
                replacements: { userId },
                type: db.QueryTypes.RAW
            })
            return result
        } catch (error) {
            throw error
        }
    }

    // Delete User Profile Summary
    async deleteUserProfileSummary(req) {
        const procedureName = 'usp_deleteUserProfileSummary'
        try {
            const userId = req?.user?.userID || 0
            const profile_id = req.body.profileId || 0
            const result = await db.query(`CALL ${procedureName}(:userId,:profile_id)`, {
                replacements: {
                    userId,
                    profile_id
                },
                type: db.QueryTypes.RAW
            })
            return result
        } catch (error) {
            console.error('Error in while creating Record', error)
            throw error
        }
    }


    async updateUserPersonalDetails(req) {
        const procedureName = 'usp_updateUserPersonalDetails'
        try {
            const userId = req?.user?.userID || 0;
            const personalDetailsId = req.body.personalDetailsId || 0;
            const actionType = req.body.actionType;
            const gender = req.body.gender || null;
            const maritalStatus = req.body.maritalStatus || null;
            const dateOfBirth = req.body.dateOfBirth || null;
            const careerBreak = req.body.careerBreak || null;
            const breakReason = req.body.breakReason || null;
            const permanentAddress = req.body.permanentAddress || null;
            const homeTown = req.body.homeTown || null;
            const pincode = req.body.pincode || null;

            const result = await db.query(
                `CALL ${procedureName}(:userId,:personalDetailsId,:actionType, :gender, :maritalStatus, :dateOfBirth, :careerBreak,:breakReason, :permanentAddress,:homeTown,:pincode)`,
                {
                    replacements: {
                        userId,
                        personalDetailsId,
                        actionType,
                        gender,
                        maritalStatus,
                        dateOfBirth,
                        careerBreak,
                        breakReason,
                        permanentAddress,
                        homeTown,
                        pincode
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return result
        } catch (error) {
            console.error('Error in while creating Record', error)
            throw error
        }
    }

    // Fetch User Profile Summary
    async getPersonalDetails(req) {
        const userId = req?.user?.userID || 0;
        const procedureName = 'usp_getPersonalDetails'
        try {
            const result = await db.query(`CALL ${procedureName}(:userId)`, {
                replacements: { userId },
                type: db.QueryTypes.RAW
            })
            return result
        } catch (error) {
            throw error
        }
    }



    async updateUserPersonalDetails(req) {
        const procedureName = 'usp_updateUserPersonalDetails'
        try {
            const userId = req?.user?.userID || 0;
            const personalDetailsId = req.body.personalDetailsId || 0;
            const actionType = req.body.actionType;
            const gender = req.body.gender || null;
            const maritalStatus = req.body.maritalStatus || null;
            const dateOfBirth = req.body.dateOfBirth || null;
            const careerBreak = req.body.careerBreak || null;
            const breakReason = req.body.breakReason || null;
            const permanentAddress = req.body.permanentAddress || null;
            const homeTown = req.body.homeTown || null;
            const pincode = req.body.pincode || null;

            const result = await db.query(
                `CALL ${procedureName}(:userId,:personalDetailsId,:actionType, :gender, :maritalStatus, :dateOfBirth, :careerBreak,:breakReason, :permanentAddress,:homeTown,:pincode)`,
                {
                    replacements: {
                        userId,
                        personalDetailsId,
                        actionType,
                        gender,
                        maritalStatus,
                        dateOfBirth,
                        careerBreak,
                        breakReason,
                        permanentAddress,
                        homeTown,
                        pincode
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return result
        } catch (error) {
            console.error('Error in while creating Record', error)
            throw error
        }
    }

    // Fetch User Profile Summary
    async getPersonalDetails(req) {
        const userId = req?.user?.userID || 0;
        const procedureName = 'usp_getPersonalDetails'
        try {
            const result = await db.query(`CALL ${procedureName}(:userId)`, {
                replacements: { userId },
                type: db.QueryTypes.RAW
            })
            return result
        } catch (error) {
            throw error
        }
    }

    async createCareerProfile(req, user_preferredLocation_XML) {
        const procedureName = 'usp_createOrUpdateCareerProfile'
        try {
            const userId = req?.user?.userID || 0
            // const userId = req.body.userID || "";  
            const current_industry = req.body.current_industry || ''
            const department = req.body.department || ''
            const job_role = req.body.job_role || ''
            const job_type = req.body.job_type || ''
            const employement_type = req.body.employement_type || ''
            const preferred_shift = req.body.preferred_shift || ''
            const expected_salary = req.body.expected_salary || ''

            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId,:user_preferredLocation_XML, :current_industry, :department, :job_role, :job_type, :employement_type, :preferred_shift, :expected_salary)`,
                {
                    replacements: {
                        userId,
                        user_preferredLocation_XML,
                        current_industry,
                        department,
                        job_role,
                        job_type,
                        employement_type,
                        preferred_shift,
                        expected_salary
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            console.error('Error in while creating Record', error)
            throw error
        }
    }

    async getCareerProfile(req, res) {
        try {
            const userId = req?.user?.userID || 0
            // const userId = req.body.userID || "";
            const procedureName = 'usp_getCareerProfile'
            const applicationResponse = await db.query(
                `CALL ${procedureName}(:userId)`,
                {
                    replacements: {
                        userId
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return applicationResponse
        } catch (error) {
            console.error('Error in while fetching:', error)
            throw error
        }
    }


    // Update Company Details API
    async updateCompanyInfo(req) {
        const procedureName = 'usp_insertOrUpdateUserDetails';
        try {
            const userId = req?.user?.userID || 0;
            const companyName = req.body.companyName || '';
            const mobileNo = req.body.mobileNo || '';
            const role = req.body.role || '';
            const companyPhoto = req.files[0].filename;

            // Call the stored procedure with all the necessary parameters
            const result = await db.query(`CALL ${procedureName}(:userId, :companyName, :mobileNo, :role, :companyPhoto)`, {
                replacements: {
                    userId,
                    companyName,
                    mobileNo,
                    role,
                    companyPhoto
                },
                type: db.QueryTypes.RAW
            });

            return result;
        } catch (error) {
            console.error('Error while updating company details:', error);
            throw error;
        }
    }


    async updateCompanyDetails(req) {
        const procedureName = 'usp_updateUserCompanyDetails'
        try {
            const userId = req?.user?.userID || 0;
            const id = req.body.id || 0;
            const companyType = req.body.companyType || null;
            const website = req.body.website || null;
            const faxNumber = req.body.faxNumber || null;
            const companyMobile2 = req.body.companyMobile2 || null;
            const contactPerson = req.body.contactPerson || null;
            const contactPersonDesignation = req.body.contactPersonDesignation || null;
            const email = req.body.email || null;
            const phoneNumber1 = req.body.phoneNumber1 || null;
            const phoneNumber2 = req.body.phoneNumber2 || null;


            const result = await db.query(
                `CALL ${procedureName}(:userId,:id, :companyType, :website, :faxNumber, :companyMobile2,:contactPerson, :contactPersonDesignation,:email,:phoneNumber1,:phoneNumber2)`,
                {
                    replacements: {
                        userId,
                        id,
                        companyType,
                        website,
                        faxNumber,
                        companyMobile2,
                        contactPerson,
                        contactPersonDesignation,
                        email,
                        phoneNumber1,
                        phoneNumber2
                    },
                    type: db.QueryTypes.RAW
                }
            )
            return result
        } catch (error) {
            console.error('Error in while creating Record', error)
            throw error
        }
    }


    // Update User basic Details API
    async updateUserDetails(req) {
        const procedureName = 'usp_updateUserDetails';
        try {
            const userId =req.user.userID || 0;
            const userName = req.body.userName || '';
            const mobileNo = req.body.mobileNo || '';
            const joinAvail = req.body.joinAvail || '';
            const userPhoto = req.files[0].filename|| '';
            const work_status= req.body.work_status || '';
            const location= req.body.location || '';
            const experienceMonth = req.body.experienceMonth || '';
            const experienceYear = req.body.experienceYear || '';
            const designation= req.body.designation || '';
            // const experience = `${experienceYear} years ${experienceMonth} months`;



            // Call the stored procedure with all the necessary parameters
            const result = await db.query(`CALL ${procedureName}(:userId, :userName, :mobileNo, :joinAvail, :userPhoto, :work_status, :experienceMonth, :experienceYear, :designation,
                 :location )`, {
                replacements: {
                    userId,
                    userName,
                    mobileNo,
                    joinAvail,
                    userPhoto,
                    work_status,
                    experienceMonth,
                    experienceYear,
                    designation,
                    location
                },
                type: db.QueryTypes.RAW
            });

            return result;
        } catch (error) {
            console.error('Error while updating company details:', error);
            throw error;
        }
    }
}
module.exports = ApplicationData
