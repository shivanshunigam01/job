const db = require("../../config/database.js");
const helper = require("../helpers/helper.js");
const utility = require("../helpers/utility");
const ApplicationData = require("../dataLayer/application.data.js");
const applicationData = new ApplicationData();
const models = require('../../models');
// const { applicationEmail ,decryptPasswordData} = require('../helpers/utility.js');

/**
 * Auth Data.
 */
class AuthData {

	/**
	 * User Login.
	 * @param {model} login.validators
	 * @returns {Object}
	 */
	async userLogin(req) {
		try {
			const email = req.body.email;
				

			const customertype = req.body.user_type;
			const procedureName = "ValidateUser";

			const user = await db.query(`CALL ${procedureName}(:email,:customertype)`, {
				replacements: { email, customertype },
				type: db.QueryTypes.RAW,
			});
			
			return user;
			 
		} catch (error) {
			throw error;
		}
	}

	/**
	 * Validate User.
	 * @param {model} login.validators
	 * @returns {Object}
	 */
	async validateUser(req) {
		const email = req.body.email;
		const user_type = req.body.user_type;
		const procedureName = "ValidateUser";
		try {
			const user = await db.query(`CALL ${procedureName}(:email, :user_type)`, {
				replacements: { email, user_type },
				type: db.QueryTypes.RAW,
			});
			return user;
		} catch (error) {
			throw error;
		}
	}

	/**
	 * Register User.
	 * @param {model} login.validators
	 * @returns {Object}
	 */
	async registerUser(req) {
		const name = req.body.name || "";
		const email = req.body.email || "";
		const mobile = req.body.mobile || "";
		const work_status = req.body.work_status || "";
		const user_type = req.body.user_type || "";
		const decodedPassword = await utility.decryptPasswordData(req.body.password);
		const password = models.customer.setPassword(decodedPassword);

		const procedureName = "usp_Registration";
		try {
			const user = await db.query(`CALL ${procedureName}(:name, :email, :password, :mobile, :work_status, :user_type)`, {
				replacements: { name, email, password, mobile, work_status, user_type },
				type: db.QueryTypes.RAW,
			});

			// Correctly reference applicationEmail
			 utility.applicationEmail({
				fileName: "WorkExecution.ejs",
				subject: "Installation of Meter",
			});
			
			return user;
		} catch (error) {
			throw error;
		}
	}

      /**
     * Find User by email.
     */
      async findUserByEmail(email) {
        const procedureName = "usp_FindUserByEmail";
        try {
            const user = await db.query(`CALL ${procedureName}(:email)`, {
                replacements: { email },
                type: db.QueryTypes.RAW,
            });
            return user[0];

        } catch (error) {
            throw error;
        }
    }

    // update forgot password token
    async updateForgotPasswordToken(userId, userReq) {
        const procedureName = "usp_UpdatePasswordToken";
        try {
            const result = await db.query(
                `CALL ${procedureName}(:userId, :resetPasswordToken, :otpExpiry)`, // Add `otpExpiry` if needed
                {
                    replacements: {
                        userId,
                        resetPasswordToken: userReq.resetPasswordToken, // Store the OTP
                        otpExpiry: userReq.otpExpiry || null // Add OTP expiry time if you need to store it
                    },
                    type: db.QueryTypes.RAW,
                }
            );
            return result;
        } catch (error) {
            throw error;
        }
    }
    

    async otpVerifyResetPassword(req) {
        const userId=req.body.userId;
        const otp=req.body.otp;
        const decodedPassword = await utility.decryptPasswordData(req.body.password);
		const password = models.customer.setPassword(decodedPassword);
        
        const procedureName = "usp_UpdateResetPassword";
        try {
            const result = await db.query(
                `CALL ${procedureName}(:userId,:otp,:password)`,
                {
                    replacements: {
                        userId,
                        otp,
                        password
                    },
                    type: db.QueryTypes.RAW,
                }
            );
            return result;
        } catch (error) {
            throw error;
        }
    }

    //change password
    async changePassword(req) {
        const userId=req.user.userID || 0;
        const decodedPassword = await utility.decryptPasswordData(req.body.password);
		const password = models.customer.setPassword(decodedPassword);
        const decodedNewPassword = await utility.decryptPasswordData(req.body.newPassword);
		const newPassword = models.customer.setPassword(decodedNewPassword);
        const procedureName = "usp_UpdateChangePassword";
        try {
            const result = await db.query(
                `CALL ${procedureName}(:userId,:password,:newPassword)`,
                {
                    replacements: {
                        userId,
                        password,
                        newPassword
                    },
                    type: db.QueryTypes.RAW,
                }
            );
            return result;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = AuthData;
