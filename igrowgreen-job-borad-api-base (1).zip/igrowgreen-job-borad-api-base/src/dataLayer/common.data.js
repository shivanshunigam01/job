const db = require("../../config/database.js");
const axios = require("axios");
const helper = require("../helpers/helper.js");
const constants = require("../helpers/constants.js")
const requestIp = require('request-ip');
var geoip = require('geoip-lite');
const securePassword = require("../utils/securePassword.js");
const models = require('../../models')
const fs = require("fs");
const path = require("path");
const ejs = require("ejs");
const mailer = require("../helpers/mailer");
const { emailConst } = require("../helpers/constants");
const { encryptData, decryptData } = require("../helpers/utility.js");



/**
 * Common Data.
 */
class CommonData {

	async generateLog(req, res, message, hasError) {
        let controllerName = req.baseUrl.replace("/api/", "");
        let routeName = req.originalUrl;
        let requestFrom = req.body.deviceType || 1;
        //let inputParameters = JSON.stringify(req.body);
        let inputParameters = "";
        let outputParameters = "";
        //  let outputParameters = res != "" ? JSON.stringify(res) : "";
        const procedureName = "usp_InOutParameterLog";

        const requestIp1 = requestIp.getClientIp(req);
        console.log("requestIp1==>", requestIp1);
        //const clientIp = req.socket.remoteAddress;
        var geo = geoip.lookup(requestIp1);

        try {
            const result = await db.query(`CALL ${procedureName}('${controllerName}', '${routeName}', '${inputParameters}', '${outputParameters}', '${requestFrom}', '${message}', '${hasError}')`, {
                // replacements: { },
                type: db.QueryTypes.RAW,
            });
            return result;
        } catch (error) {
            throw error;
        }
    }


    async getDetails(req) {
        try {
            const userId =req.user.userID || 0;
            const procedureName1 = 'usp_getDetails';
            const result = await db.query(`CALL ${procedureName1}(:userId)`, {
                replacements: {userId },
                type: db.QueryTypes.RAW
            });
            return result;
        } catch (error) {
            throw error;
        }
    }


    async applyFilter(req) {
        try {
            const page = req.body.page || 0;
            const size = req.body.size || 0;
            const work_mode = req.body.work_mode || '';
            const exp = req.body.exp || 0;
            const department = req.body.department || '';
            const location = req.body.location || '';
            const salary = req.body.salary || 0;
            const education = req.body.education || '';
            const user_id = 0;
    
            const procedureName1 = 'usp_applyJobFilters';
            const result = await db.query(
                `CALL ${procedureName1}(:page, :size, :work_mode, :exp, :department, :location, :salary, :education, :user_id)`, 
                {
                    replacements: {
                        page, 
                        size, 
                        work_mode, 
                        exp, 
                        department, 
                        location, 
                        salary, 
                        education, 
                        user_id
                    },
                    type: db.QueryTypes.RAW
                }
            );
            return result;
        } catch (error) {
            throw error;
        }
    }
    
    async mainFilter(req) {
        try {
            const page = req.body.page || 0;
            const size = req.body.size || 10; // Default to 10 if not provided
            const department = req.body.department || null; // Default to null if not provided
            const company_name = req.body.company_name || null; // Default to null if not provided
            const job_skills = req.body.job_skills || null; // Default to null if not provided
            const on_location_job = req.body.on_location_job || null; // Default to null if not provided
            const user_id = req.body.user_id || 0; // Assuming user ID is part of the request
    
            const start = page * size; // Calculate start index for pagination
    
            const procedureName = 'main_filter';
            const result = await db.query(
                `CALL ${procedureName}(:department, :company_name, :job_skills, :on_location_job, :user_id, :start, :size)`, 
                {
                    replacements: {
                        department, 
                        company_name, 
                        job_skills, 
                        on_location_job, 
                        user_id,
                        start,
                        size
                    },
                    type: db.QueryTypes.RAW
                }
            );
            return result;
        } catch (error) {
            throw error;
        }
    }
    
    

}


module.exports = CommonData;
