const db = require("../../config/database.js");
const helper = require("../helpers/helper.js");

class dashboardData{
 
    async getDashboardList(req) {
        const userID=req.user.userID;
        const customertype=req.user.type|| ''; //req.body.customertype||"";
        const areaId=req.body.areaId||"";
        const circleId=req.user.circleId||"";
        const divisionId=req.user.division||"";
        const subdivisionId=req.user.subdivision||"";
        
        const procedureName = "GetDashboardData";

        try {
            const applicationResponse = await db.query(`CALL ${procedureName}(
                :userID,
                :customertype,
                :areaId,
                :circleId,
                :divisionId,
                :subdivisionId
            )`, {
                replacements: {
                userID,
                customertype,
                areaId,
                circleId,
                divisionId,
                subdivisionId,
                },
                type: db.QueryTypes.RAW,
            });
            
            return applicationResponse;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = dashboardData;