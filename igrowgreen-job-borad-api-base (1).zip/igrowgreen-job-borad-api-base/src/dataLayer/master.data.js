const db = require("../../config/database.js");
const helper = require("../helpers/helper.js");
const { decryptID } = require("../helpers/utility.js");
const utility = require("../helpers/utility");
const models = require('../../models');
/**
 * SGLead Data.
 */
class MasterData {

	/**
	 * User Login.
	 * @param {model} login.validators
	 * @returns {Object}
	 */
	async getStateList(req) {


		// const userId = req.user.userID;	 
		// const applicationId = decryptID(req.body.applicationId) || '';

		const procedureName = "GetStateData";

		try {
			const response = await db.query(`CALL ${procedureName}( )`, {
				replacements: {},
				type: db.QueryTypes.RAW,
			});


			return response;
		} catch (error) {
			throw error;
		}
	}

	async addCategories(req) {
		try {
			const procedureName = "createCategories";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.categories_name
			const p_userId = req.user?.userID ?? null
			const category_id = req.body?.category_id ?? 0
			if (!category_id) {
				let procdName = "checkDuplicateTitleForCategories"
				let categories = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (categories?.length) {
					return null
				}
			}
			const categories = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:category_id)`, {
				replacements: { title, description, status, p_userId, category_id },
				type: db.QueryTypes.RAW,
			});
			return categories;
		} catch (error) {
			console.error('Error in while creating Categories:', error)
			throw error
		}
	}
	async getCategoriesData(req) {
		try {
			const procedureName = 'getCategoryList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const categoriesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return categoriesResponse
		} catch (error) {
			console.error('Error in while get Job List:', error)
			throw error
		}
	}
	async getCategoriesCount(req) {
		try {
			const procedureName = 'getCategoriesCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const categoriesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return categoriesResponse

		} catch (error) {
			console.error('Error in while get Job Count:', error)
			throw error
		}
	}

	async deleteCategories(req) {
		const procedureName = 'deleteCategories'
		try {
			const category_id = req.body?.category_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:category_id,:userId)`, {
				replacements: {
					category_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Record', error)
			throw error
		}
	}
	async addDepartments(req) {
		try {
			const procedureName = "createDepartments";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.department_name
			const p_userId = req.user?.userID ?? null
			const department_id = req.body?.department_id ?? 0
			if (!department_id) {
				let procdName = "checkDuplicateTitleForDepartments"
				let departments = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (departments?.length) {
					return null
				}
			}
			const departments = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:department_id)`, {
				replacements: { title, description, status, p_userId, department_id },
				type: db.QueryTypes.RAW,
			});
			return departments;
		} catch (error) {
			console.error('Error in while creating Departments:', error)
			throw error
		}
	}
	async getDepartmentsData(req) {
		try {
			const procedureName = 'getDeparmentsList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const departmentsResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return departmentsResponse
		} catch (error) {
			console.error('Error in while get departments List:', error)
			throw error
		}
	}
	async getDepartmentsCount(req) {
		try {
			const procedureName = 'getDepartmentsCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const DepartmentsResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return DepartmentsResponse

		} catch (error) {
			console.error('Error in while get Departments Count:', error)
			throw error
		}
	}
	async deleteDepartments(req) {
		const procedureName = 'deleteDepartments'
		try {
			const department_id = req.body?.department_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:department_id,:userId)`, {
				replacements: {
					department_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Departments', error)
			throw error
		}
	}
	async addModules(req) {
		try {
			const procedureName = "createModules";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.module_name
			const p_userId = req.user?.userID ?? null
			const module_id = req.body?.module_id ?? 0
			if (!module_id) {
				let procdName = "checkDuplicateTitleForModules"
				let modules = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (modules?.length) {
					return null
				}
			}

			const modules = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:module_id)`, {
				replacements: { title, description, status, p_userId, module_id },
				type: db.QueryTypes.RAW,
			});
			return modules;
		} catch (error) {
			console.error('Error in while creating Modules:', error)
			throw error
		}
	}
	async getModulesData(req) {
		try {
			const procedureName = 'getModulesList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const modulesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return modulesResponse
		} catch (error) {
			console.error('Error in while get Modules List:', error)
			throw error
		}
	}
	async getModulesCount(req) {
		try {
			const procedureName = 'getModulesCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const modulesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return modulesResponse

		} catch (error) {
			console.error('Error in while get Modules Count:', error)
			throw error
		}
	}
	async deleteModules(req) {
		const procedureName = 'deleteModules'
		try {
			const module_id = req.body?.module_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:module_id,:userId)`, {
				replacements: {
					module_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Modules', error)
			throw error
		}
	}
	async addLocations(req) {
		try {
			const procedureName = "createLocations";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.location_name
			const p_userId = req.user?.userID ?? null
			const location_id = req.body?.location_id ?? 0
			if (!location_id) {
				let procdName = "checkDuplicateTitleForLocations"
				let locations = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (locations?.length) {
					return null
				}
			}
			const location = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:location_id)`, {
				replacements: { title, description, status, p_userId, location_id },
				type: db.QueryTypes.RAW,
			});
			return location;
		} catch (error) {
			console.error('Error in while creating Locations:', error)
			throw error
		}
	}
	async getLocationsData(req) {
		try {
			const procedureName = 'getLocationsList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const locationsResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return locationsResponse
		} catch (error) {
			console.error('Error in while get Locations List:', error)
			throw error
		}
	}
	async getlocationsCount(req) {
		try {
			const procedureName = 'getlocationsCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const locationsResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return locationsResponse

		} catch (error) {
			console.error('Error in while get locations Count:', error)
			throw error
		}
	}
	async deleteLocations(req) {
		const procedureName = 'deleteLocations'
		try {
			const location_id = req.body?.location_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:location_id,:userId)`, {
				replacements: {
					location_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Locations', error)
			throw error
		}
	}
	async addEducations(req) {
		try {
			const procedureName = "createEducations";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.education_name
			const p_userId = req.user?.userID ?? null
			const education_id = req.body?.education_id ?? 0
			if (!education_id) {
				let procdName = "checkDuplicateTitleForEducations"
				let educations = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (educations?.length) {
					return null
				}
			}
			const education = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:education_id)`, {
				replacements: { title, description, status, p_userId, education_id },
				type: db.QueryTypes.RAW,
			});
			return education;
		} catch (error) {
			console.error('Error in while creating Educations:', error)
			throw error
		}
	}
	async getEducationsData(req) {
		try {
			const procedureName = 'getEducationsList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const educationsResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return educationsResponse
		} catch (error) {
			console.error('Error in while get Educations List:', error)
			throw error
		}
	}
	async getEducationsCount(req) {
		try {
			const procedureName = 'getEducationsCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const educationsResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return educationsResponse

		} catch (error) {
			console.error('Error in while get Educations Count:', error)
			throw error
		}
	}
	async deleteEducations(req) {
		const procedureName = 'deleteEducations'
		try {
			const education_id = req.body?.education_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:education_id,:userId)`, {
				replacements: {
					education_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Educations', error)
			throw error
		}
	}
	async addIndustryTypes(req) {
		try {
			const procedureName = "createIndustryTypes";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.industry_types_name
			const p_userId = req.user?.userID ?? null
			const industry_types_id = req.body?.industry_types_id ?? 0
			if (!industry_types_id) {
				let procdName = "checkDuplicateTitleForIndustryTypes"
				let industryTypes = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (industryTypes?.length) {
					return null
				}
			}
			const industry_type = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:industry_types_id)`, {
				replacements: { title, description, status, p_userId, industry_types_id },
				type: db.QueryTypes.RAW,
			});
			return industry_type;
		} catch (error) {
			console.error('Error in while creating IndustryTypes:', error)
			throw error
		}
	}
	async getIndustryTypesData(req) {
		try {
			const procedureName = 'getIndustryTypesList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const industryTypesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return industryTypesResponse
		} catch (error) {
			console.error('Error in while get Industry types List:', error)
			throw error
		}
	}
	async getIndustryTypesCount(req) {
		try {
			const procedureName = 'getIndustryTypesCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const industryTypesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return industryTypesResponse

		} catch (error) {
			console.error('Error in while get Industry types Count:', error)
			throw error
		}
	}
	async deleteIndustryTypes(req) {
		const procedureName = 'deleteIndustryTypes'
		try {
			const industry_types_id = req.body?.industry_types_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:industry_types_id,:userId)`, {
				replacements: {
					industry_types_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Industry types', error)
			throw error
		}
	}
	async addSkills(req) {
		try {
			const procedureName = "createSkills";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.skill_name
			const p_userId = req.user?.userID ?? null
			const skill_id = req.body?.skill_id ?? 0
			if (!skill_id) {
				let procdName = "checkDuplicateTitleForSkills"
				let Skills = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (Skills?.length) {
					return null
				}
			}
			const skill = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:skill_id)`, {
				replacements: { title, description, status, p_userId, skill_id },
				type: db.QueryTypes.RAW,
			});
			return skill;
		} catch (error) {
			console.error('Error in while creating Skills:', error)
			throw error
		}
	}
	async getSkillsData(req) {
		try {
			const procedureName = 'getSkillsList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const skillsResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return skillsResponse
		} catch (error) {
			console.error('Error in while get Skills List:', error)
			throw error
		}
	}
	async getSkillsCount(req) {
		try {
			const procedureName = 'getSkillsCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const SkillsResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return SkillsResponse

		} catch (error) {
			console.error('Error in while get Skills Count:', error)
			throw error
		}
	}
	async deleteSkills(req) {
		const procedureName = 'deleteSkills'
		try {
			const skill_id = req.body?.skill_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:skill_id,:userId)`, {
				replacements: {
					skill_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Skills', error)
			throw error
		}
	}
	async addJobTypes(req) {
		try {
			const procedureName = "createJobTypes";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.job_types_name
			const p_userId = req.user?.userID ?? null
			const job_types_id = req.body?.job_types_id ?? 0
			if (!job_types_id) {
				let procdName = "checkDuplicateTitleForJobTypes"
				let jobTypes = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (jobTypes?.length) {

					return [{ flag: 3 }]
				}
			}
			const job_types = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:job_types_id)`, {
				replacements: { title, description, status, p_userId, job_types_id },
				type: db.QueryTypes.RAW,
			});
			if (job_types?.length) {
				if (Object.keys(job_types[0]).includes('flag') !== true) {
					job_types[0].flag = 4
				}
				return job_types
			}
		} catch (error) {
			console.error('Error in while creating Job Types:', error)
			throw error
		}
	}
	async getJobTypesData(req) {
		try {
			const procedureName = 'getJobTypesList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const jobTypesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return jobTypesResponse
		} catch (error) {
			console.error('Error in while get Job Types List:', error)
			throw error
		}
	}
	async getJobTypesCount(req) {
		try {
			const procedureName = 'getJobTypesCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const jobTypesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return jobTypesResponse

		} catch (error) {
			console.error('Error in while get Job Types Count:', error)
			throw error
		}
	}
	async deleteJobTypes(req) {
		const procedureName = 'deleteJobTypes'
		try {
			const job_types_id = req.body?.job_types_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:job_types_id,:userId)`, {
				replacements: {
					job_types_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Job Types', error)
			throw error
		}
	}
	async addWorkModes(req) {
		try {
			const procedureName = "createWorkModes";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.work_modes_name
			const p_userId = req.user?.userID ?? null
			const work_modes_id = req.body?.work_modes_id ?? 0
			if (!work_modes_id) {
				let procdName = "checkDuplicateTitleForWorkModes"
				let workModes = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (workModes?.length) {
					return null
				}
			}
			const work_modes = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:work_modes_id)`, {
				replacements: { title, description, status, p_userId, work_modes_id },
				type: db.QueryTypes.RAW,
			});
			return work_modes;
		} catch (error) {
			console.error('Error in while creating Work Modes:', error)
			throw error
		}
	}
	async getWorkModesData(req) {
		try {
			const procedureName = 'getWorkModesList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const workModesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return workModesResponse
		} catch (error) {
			console.error('Error in while get Work Modes List:', error)
			throw error
		}
	}
	async getWorkModesCount(req) {
		try {
			const procedureName = 'getWorkModesCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const WorkModesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return WorkModesResponse

		} catch (error) {
			console.error('Error in while get Work Modes Count:', error)
			throw error
		}
	}
	async deleteWorkModes(req) {
		const procedureName = 'deleteWorkModes'
		try {
			const work_modes_id = req.body?.work_modes_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:work_modes_id,:userId)`, {
				replacements: {
					work_modes_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Work Modess', error)
			throw error
		}
	}
	async addSalaryTypes(req) {
		try {
			const procedureName = "createSalaryTypes";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.salary_types_name
			const p_userId = req.user?.userID ?? null
			const salary_types_id = req.body?.salary_types_id ?? 0
			if (!salary_types_id) {
				let procdName = "checkDuplicateTitleForSalaryTypes"
				let salaryTypes = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (salaryTypes?.length) {
					return null
				}
			}
			const salaryTypes = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:salary_types_id)`, {
				replacements: { title, description, status, p_userId, salary_types_id },
				type: db.QueryTypes.RAW,
			});
			return salaryTypes;
		} catch (error) {
			console.error('Error in while creating Salary Types:', error)
			throw error
		}
	}
	async getSalaryTypesData(req) {
		try {
			const procedureName = 'getSalaryTypesList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const salaryTypesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return salaryTypesResponse
		} catch (error) {
			console.error('Error in while get Salary Types List:', error)
			throw error
		}
	}
	async getSalaryTypesCount(req) {
		try {
			const procedureName = 'getSalaryTypesCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const salaryTypesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return salaryTypesResponse

		} catch (error) {
			console.error('Error in while get Salary Types Count:', error)
			throw error
		}
	}
	async deleteSalaryTypes(req) {
		const procedureName = 'deleteSalaryTypes'
		try {
			const salary_types_id = req.body?.salary_types_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:salary_types_id,:userId)`, {
				replacements: {
					salary_types_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Salary Types', error)
			throw error
		}
	}
	async addShiftTimes(req) {
		try {
			const procedureName = "createShiftTimes";
			const {
				description,
				status
			} = req.body || ''
			const title = req.body?.shift_times_name
			const p_userId = req.user?.userID ?? null
			const shift_times_id = req.body?.shift_times_id ?? 0
			if (!shift_times_id) {
				let procdName = "checkDuplicateTitleForShiftTimes"
				let shiftTimes = await db.query(`CALL ${procdName}(:title)`, {
					replacements: { title },
					type: db.QueryTypes.RAW,
				});
				if (shiftTimes?.length) {
					return null
				}
			}
			const shiftTimes = await db.query(`CALL ${procedureName}(:title,:description,:status,:p_userId,:shift_times_id)`, {
				replacements: { title, description, status, p_userId, shift_times_id },
				type: db.QueryTypes.RAW,
			});
			return shiftTimes;
		} catch (error) {
			console.error('Error in while creating shift times:', error)
			throw error
		}
	}
	async getShiftTimesData(req) {
		try {
			const procedureName = 'getShiftTimesList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const ShiftTimesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return ShiftTimesResponse
		} catch (error) {
			console.error('Error in while get Shift Times List:', error)
			throw error
		}
	}
	async getShiftTimesCount(req) {
		try {
			const procedureName = 'getShiftTimesCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const ShiftTimesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return ShiftTimesResponse

		} catch (error) {
			console.error('Error in while get Shift Times Count:', error)
			throw error
		}
	}
	async deleteShiftTimes(req) {
		const procedureName = 'deleteShiftTimes'
		try {
			const shift_times_id = req.body?.shift_times_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:shift_times_id,:userId)`, {
				replacements: {
					shift_times_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting Shift Times', error)
			throw error
		}
	}
	async addTotalExperiences(req) {
		try {
			const procedureName = "createTotalExperiences";
			const {
				min_year,
				max_year,
				description,
				status
			} = req.body || ''

			const p_userId = req.user?.userID ?? null
			const total_experiences_id = req.body?.total_experiences_id ?? 0
			if (!total_experiences_id) {
				let procdName = "checkDuplicateTitleForTotalExperiences"
				let TotalExperiences = await db.query(`CALL ${procdName}(:min_year,:max_year)`, {
					replacements: { min_year, max_year },
					type: db.QueryTypes.RAW,
				});
				if (TotalExperiences?.length) {
					return null
				}
			}
			const TotalExperiences = await db.query(`CALL ${procedureName}(:min_year,:max_year,:description,:status,:p_userId,:total_experiences_id)`, {
				replacements: { min_year, max_year, description, status, p_userId, total_experiences_id },
				type: db.QueryTypes.RAW,
			});
			return TotalExperiences;
		} catch (error) {
			console.error('Error in while creating total experiences:', error)
			throw error
		}
	}
	async deleteTotalExperiences(req) {
		const procedureName = 'deleteTotalExperiences'
		try {
			const total_experiences_id = req.body?.total_experiences_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:total_experiences_id,:userId)`, {
				replacements: {
					total_experiences_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting total experiences', error)
			throw error
		}
	}
	async getTotalExperiencesData(req) {
		try {
			const procedureName = 'getTotalExperiencesList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const totalExperiencesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return totalExperiencesResponse
		} catch (error) {
			console.error('Error in while get Total Experiences List:', error)
			throw error
		}
	}
	async getTotalExperiencesCount(req) {
		try {
			const procedureName = 'getTotalExperiencesCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const totalExperiencesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return totalExperiencesResponse

		} catch (error) {
			console.error('Error in while get Total Experiences Count:', error)
			throw error
		}
	}
	async addSalaries(req) {
		try {
			const procedureName = "createSalaries";
			const {
				min_salary,
				max_salary,
				description,
				status
			} = req.body || ''

			const p_userId = req.user?.userID ?? null
			const salary_id = req.body?.salary_id ?? 0
			if (!salary_id) {
				let procdName = "checkDuplicateTitleForSalaries"
				let salaries = await db.query(`CALL ${procdName}(:min_salary,:max_salary)`, {
					replacements: { min_salary, max_salary },
					type: db.QueryTypes.RAW,
				});
				if (salaries?.length) {
					return null
				}
			}
			const salaries = await db.query(`CALL ${procedureName}(:min_salary,:max_salary,:description,:status,:p_userId,:salary_id)`, {
				replacements: { min_salary, max_salary, description, status, p_userId, salary_id },
				type: db.QueryTypes.RAW,
			});
			return salaries;
		} catch (error) {
			console.error('Error in while creating Salaries', error)
			throw error
		}
	}
	async getSalariesData(req) {
		try {
			const procedureName = 'getSalariesList'

			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const salariesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: {
						page,
						size
					},
					type: db.QueryTypes.RAW
				}
			)

			return salariesResponse
		} catch (error) {
			console.error('Error in while get Salary List:', error)
			throw error
		}
	}
	async getSalariesCount(req) {
		try {
			const procedureName = 'getSalariesCount'
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10

			const SalariesResponse = await db.query(
				`CALL ${procedureName}(:page,:size)`,
				{
					replacements: { page, size },
					type: db.QueryTypes.RAW
				}
			)
			return SalariesResponse

		} catch (error) {
			console.error('Error in while get Salary Count:', error)
			throw error
		}
	}
	async deleteSalaries(req) {
		const procedureName = 'deleteSalaries'
		try {
			const salary_id = req.body?.salary_id || 0
			const userId = req.user?.userID ?? null
			const result = await db.query(`CALL ${procedureName}(:salary_id,:userId)`, {
				replacements: {
					salary_id,
					userId
				},
				type: db.QueryTypes.RAW
			})
			return result
		} catch (error) {
			console.error('Error in while deleting salary', error)
			throw error
		}
	}
	async getCompaniesData(req) {
		const procedureName = "getCompaniesData"
		try {
			const page = req.body.page ?? 1
			const size = req.body.size ?? 10
			const search = req.body.search ?? ''
			const location = req.body?.location ?? ''

			const result = await db.query(
				`CALL ${procedureName}(:search,:location,:page,:size)`,
				{
					replacements: {
						search,
						location,
						page,
						size,
					},
					type: db.QueryTypes.RAW
				}
			)
			return result
		} catch (error) {
			console.error('Error in while getting Companies Data', error)
			throw error
		}
	}
	async getCompaniesCount(req) {
		const procedureName = "getCompaniesCount"
		try {
			const page = req.body.page ?? 1
			const size = req.body.size ?? 10
			const search = req.body.search ?? ''
			const location = req.body?.location ?? ''

			const result = await db.query(
				`CALL ${procedureName}(:search,:location,:page,:size)`,
				{
					replacements: {
						search,
						location,
						page,
						size,
					},
					type: db.QueryTypes.RAW
				}
			)
			return result
		} catch (error) {
			console.error('Error in while getting Companies Count', error)
			throw error
		}
	}

	async getCompaniesJobPostListData(req) {
		const procedureName = "getCompaniesJobPostListData"
		try {
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10
			const search = req.body?.search ?? ''
			const on_location_job = req.body?.on_location_job ?? ''
			const job_category = req.body?.job_category ?? ''
			const total_experience = req.body?.total_experience ?? ''
			const userId = req.body?.userID ?? 0

			const result = await db.query(
				`CALL ${procedureName}(:page,:size,:search,:job_category,:total_experience,:on_location_job,:userId)`,
				{
					replacements: {
						page,
						size,
						search,
						job_category,
						total_experience,
						on_location_job,
						userId
					},
					type: db.QueryTypes.RAW
				}
			)
			return result
		} catch (error) {
			console.error('Error in while getting Companies Data', error)
			throw error
		}
	}
	async getCompaniesJobPostListCount(req) {
		const procedureName = "getCompaniesJobPostListCount"
		try {
			const page = req.body?.page ?? 1
			const size = req.body?.size ?? 10
			const search = req.body?.search ?? ''
			const on_location_job = req.body?.on_location_job ?? ''
			const job_category = req.body?.job_category ?? ''
			const total_experience = req.body?.total_experience ?? ''
			const userId = req.body?.userID ?? 0

			const result = await db.query(
				`CALL ${procedureName}(:page,:size,:search,:job_category,:total_experience,:on_location_job,:userId)`,
				{
					replacements: {
						page,
						size,
						search,
						job_category,
						total_experience,
						on_location_job,
						userId
					},
					type: db.QueryTypes.RAW
				}
			)
			return result
		} catch (error) {
			console.error('Error in while getting Companies Job Post List Data', error)
			throw error
		}
	}

	async getCompaniesJobAppliedUserListData(req) {
		try {
			const procedureName = 'getCompaniesJobAppliedUserListData'

			const page = req.body.page ?? 1
			const size = req.body.size ?? 10
			const search = req.body.search ?? ''
			const job_id = req.body?.job_id

			const result = await db.query(
				`CALL ${procedureName}(:page,:size,:search,:job_id)`,
				{
					replacements: {
						page,
						size,
						search,
						job_id
					},
					type: db.QueryTypes.SELECT
				}
			)

			return result
		} catch (error) {
			console.error('Error in while fetching get companies Job Applied User list data:', error)
			throw error
		}
	}

	async getCompaniesJobAppliedUserListCount(req) {
		try {
			const procedureName = 'getCompaniesJobAppliedUserListCount'

			const page = req.body.page ?? 1
			const size = req.body.size ?? 10
			const search = req.body.search ?? ''
			const job_id = req.body?.job_id ?? ''


			const result = await db.query(
				`CALL ${procedureName}(:page,:size,:search,:job_id)`,
				{
					replacements: {
						page,
						size,
						search,
						job_id
					},
					type: db.QueryTypes.RAW
				}
			)
			return result
		} catch (error) {
			console.error('Error in while fetching get companies Job Applied User list Count:', error)
			throw error
		}
	}

	async updateStatus(req) {
		try {
			const procedureName = 'updateStatus'
			const p_userId = req.user?.userID ?? 0
			const category_id = req.body?.category_id ?? ''
			const department_id = req.body?.department_id ?? ''
			const education_id = req.body?.education_id ?? ''
			const industry_type_id = req.body?.industry_type_id ?? ''
			const job_types_id = req.body?.job_types_id ?? ''
			const location_id = req.body?.location_id ?? ''
			const module_id = req.body?.module_id ?? ''
			const salary_id = req.body?.salary_id ?? ''
			const salary_types_id = req.body?.salary_types_id ?? ''
			const shift_times_id = req.body?.shift_times_id ?? ''
			const total_experiences_id = req.body?.total_experiences_id ?? ''
			const work_modes_id = req.body?.work_modes_id ?? ''
			const skill_id = req.body?.skill_id ?? ''




			const result = await db.query(
				`CALL ${procedureName}(:category_id,:department_id,:education_id,:industry_type_id,:job_types_id,:location_id,
				:module_id,:salary_id,:salary_types_id,:shift_times_id,:total_experiences_id,:skill_id,:work_modes_id,:p_userId)`,
				{
					replacements: {
						category_id,
						department_id,
						education_id,
						industry_type_id,
						job_types_id,
						location_id,
						module_id,
						salary_id,
						salary_types_id,
						shift_times_id,
						total_experiences_id,
						skill_id,
						work_modes_id,
						p_userId
					},
					type: db.QueryTypes.RAW
				}
			)
			return result
		} catch (error) {
			console.error('Error in while fetching get companies Job Applied User list Count:', error)
			throw error
		}
	}

	async findUserByEmail(email) {
		const procedureName = "usp_FindUserByEmail";
		try {
			const user = await db.query(`CALL ${procedureName}(:email)`, {
				replacements: { email },
				type: db.QueryTypes.RAW,
			});
			return user[0];

		} catch (error) {
			throw error;
		}
	}

	// update forgot password token
	async updateForgotPasswordToken(userId, userReq) {
		const procedureName = "usp_UpdatePasswordToken";
		try {
			const result = await db.query(
				`CALL ${procedureName}(:userId, :resetPasswordToken, :otpExpiry)`, // Add `otpExpiry` if needed
				{
					replacements: {
						userId,
						resetPasswordToken: userReq.resetPasswordToken, // Store the OTP
						otpExpiry: userReq.otpExpiry || null // Add OTP expiry time if you need to store it
					},
					type: db.QueryTypes.RAW,
				}
			);
			return result;
		} catch (error) {
			throw error;
		}
	}

	async otpVerifyResetPassword(req) {
		const userId = req.body.userId;
		const otp = req.body.otp;
		const decodedPassword = await utility.decryptPasswordData(req.body.password);
		const password = models.customer.setPassword(decodedPassword);

		const procedureName = "usp_UpdateResetPassword";
		try {
			const result = await db.query(
				`CALL ${procedureName}(:userId,:otp,:password)`,
				{
					replacements: {
						userId,
						otp,
						password
					},
					type: db.QueryTypes.RAW,
				}
			);
			return result;
		} catch (error) {
			throw error;
		}
	}

	//change password
	async changePassword(req) {
		const userId = req.user?.userID ?? 1244;
		const decodedPassword = await utility.decryptPasswordData(req.body?.password);
		const password = models.customer.setPassword(decodedPassword);
		const decodedNewPassword = await utility.decryptPasswordData(req.body?.newPassword);
		const newPassword = models.customer.setPassword(decodedNewPassword);
		const procedureName = "usp_UpdateChangePassword";
		try {
			const result = await db.query(
				`CALL ${procedureName}(:userId,:password,:newPassword)`,
				{
					replacements: {
						userId,
						password,
						newPassword
					},
					type: db.QueryTypes.RAW,
				}
			);
			return result;
		} catch (error) {
			throw error;
		}
	}

}



module.exports = MasterData;
