const db = require("../../config/database.js");
const helper = require("../helpers/helper.js");
const requestIp = require("request-ip");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const ejs = require("ejs");
const mailer = require("../helpers/mailer");
const { emailConst } = require("../helpers/constants");
const ApplicationData = require("./application.data.js");
const { applicationStage } = require("../helpers/constants.js");
const { log, Console } = require("console");
const { decryptData, decryptID } = require("../helpers/utility.js");

/**
 * Report Data.
 */
class ReportData {

    /**
     * User Login.
     * @param {model} login.validators
     * @returns {Object}
     */
    async SendLeadotp(req) {

        const lead_id = req.body.lead_id;
        const otp = this.createOtp();
        const procedureName = "convertLead";
        try {
            const result = await db.query(
                `CALL ${procedureName}(
                    :lead_id,
                    :otp    
                )`,
                {
                    replacements: {
                        lead_id,
                        otp
                    },
                    type: db.QueryTypes.RAW,
                }
            );

            //for mail
            if (result) {

                const data = {
                    nameOfConsumer: result[0].full_name,
                    applicationNo: "123",
                    consumerNo: result[0].consumer_no,
                    pvCapacity: result[0].pv_capacity,
                    installerName: "MauleshBhatt",
                    shortNameOfDiscom: "bses",
                    registrationNo: result[0].lead_id,
                    estimateAmount: "5000",
                    pdiRequestNo: "",
                    nameOfEmpanelledAgency: "",
                    otp: otp,
                };


                const ejsFilePath = path.join(process.cwd(), "src", "Template", "OTPforApplicationSubmission.ejs");
                const ejsContent = fs.readFileSync(ejsFilePath, "utf8");
                const html = ejs.render(ejsContent, data);
                mailer.send(
                    emailConst.confirmEmails.from,
                    "netmetering.brpl@gmail.com",
                    "OTP for Application submission",
                    html
                );

                const mobileNos = "321654978"
                this.sendOTPMessage(mobileNos, otp);
                console.log("SMS and Mail sent succesfully")


                //  this.sendOTPMessage(result[0].mobile, otp);
            }


            return result;
        } catch (error) {
            throw error;
        }
    }


}

module.exports = ReportData;
