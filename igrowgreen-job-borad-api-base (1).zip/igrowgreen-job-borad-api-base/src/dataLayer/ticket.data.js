const db = require("../../config/database.js");
const helper = require("../helpers/helper.js");

/**
 * Ticket Data.
 */
class TicketData {

	/**
	 * User Login.
	 * @param {model} login.validators
	 * @returns {Object}
	 */
	async ticketCount(req) {
		
		 
		const userId = req.user.userID;
		const ticketNo = req.body.ticketNo || '';
		const category = req.body.category || '';
		const subCategory = req.body.subCategory || '';
		const status = req.body.status || '';
	
		const type = req.body.type || '';
		const typeNumberId = req.body.typeNumberId || '';
		const discom = req.body.discom || '';
		const circle = req.body.circle || '';
		const division = req.body.division || '';
		const subDivision = req.body.subDivision || '';
		const toDate = new Date(req.body.toDate);
		const fromDate = new Date(req.body.fromDate);
	 
		const procedureName = "GetTicketDataCount";
		 
		try {
			const ticketCount = await db.query(`CALL ${procedureName}(:userId,   :ticketNo, :category, :subCategory, :status, :type, :typeNumberId, :discom, :circle, :division, :subDivision, :fromDate, :toDate )`, {
				replacements: { userId,   ticketNo, category, subCategory, status, type, typeNumberId, discom, circle, division , subDivision, fromDate, toDate},
				type: db.QueryTypes.RAW,
			});
		
			 
			return ticketCount[0].count;
		} catch (error) {
			throw error;
		}
	}
	async ticketList(req) {
		
		var limit = parseInt(req.body.limit) || 10,
        skip = parseInt(req.body.skip) || 0;
		const userId = req.user.userID;
		const ticketNo = req.body.ticketNo || '';
		const category = req.body.category || '';
		const subCategory = req.body.subCategory || '';
		const status = req.body.status || '';
	
		const type = req.body.type || '';
		const typeNumberId = req.body.typeNumberId || '';
		const discom = req.body.discom || '';
		const circle = req.body.circle || '';
		const division = req.body.division || '';
		const subDivision = req.body.subDivision || '';
		const toDate = new Date(req.body.toDate);
		const fromDate = new Date(req.body.fromDate);
		 
		const procedureName = "GetTicketData";
		try {
			const ticketData = await db.query(`CALL ${procedureName}(:limit, :skip, :userId,   :ticketNo, :category, :subCategory, :status, :type, :typeNumberId, :discom, :circle, :division, :subDivision, :toDate, :fromDate )`, {
				replacements: {limit, skip, userId,   ticketNo, category, subCategory, status, type, typeNumberId, discom, circle, division , subDivision, toDate, fromDate},
				type: db.QueryTypes.RAW,
			});

			return ticketData
		 
		} catch (error) {
			throw error;
		}
	}



    async getTicketSubcategoryList(req) {
		

        // const user_Id=5;

        const user_Id=req.body.user_Id || '';
        const sub_category_type=req.body.sub_category_type || '';
		
		 
		const procedureName = "GetTicketSubcategory";
		try {
			const ticketData = await db.query(`CALL ${procedureName}(:user_Id,:sub_category_type)`, {
				replacements: {user_Id,sub_category_type},
				type: db.QueryTypes.RAW,
			});

       

			return ticketData;
		 
		} catch (error) {
			throw error;
		}
	}


    async getTicketList(req) {
        // const user_Id=5;

        const user_Id=req.user.userID;
		 const type = req.body.type;
		const procedureName = "getTicketList";
		try {
			const ticketData = await db.query(`CALL ${procedureName}(:user_Id,:type)`, {
				replacements: {user_Id, type},
				type: db.QueryTypes.RAW,
			});

       

			return ticketData;
		 
		} catch (error) {
			throw error;
		}
	}





	async ticketCreate(req,fileName) {
		
		const userId = req.user.userID;
		// const ticketNo = req.body.ticketNo || '';
		const category = req.body.category || '';
		// const subCategory = req.body.subCategory || '';
		// const status = req.body.status || '';
		// const type = req.body.typeText || '';
		const typeNumber = req.body.typeNumber || '';
		const discom = req.body.discom || '';
		const installerId = req.user.type =='installer' ? req.user.userID : 0;
		const contactNo = req.body.contactNo || '';
		// const subDivision = req.body.subDivision || '';
		const message = req.body.message || '';
        const screenShotImage = fileName

		 const procedureName = "CreateTicket";
		 
		 try {
            const result = await db.query(
              `CALL ${procedureName}(:userId,:category,:typeNumber,:discom,:installerId,:contactNo, :message, :screenShotImage)`,
              {
                replacements: { userId, category, typeNumber, discom, installerId, contactNo, message, screenShotImage },
                type: db.QueryTypes.RAW,
              }
              
            );
           
            return result;
          } catch (error) {
            throw error;
          }
        }

    async updateTask(req) {
     
        const id=req.body.id|| "";
        const title= req.body.sub_category_name|| "";
        const type= req.body.subcategory_type|| "";
        const installer_hint= req.body.message|| "";
        const discom_hint= req.body.discom_message|| "";
        const userId=req.user.userID;
       
        const procedureName = "updateTicketSubCategory";
    
        try {
          const result = await db.query(
            `CALL ${procedureName}(:id,:title,:type,:installer_hint,:discom_hint,:userId )`,
            {
              replacements: { id, title, type, installer_hint, discom_hint, userId },
              type: db.QueryTypes.RAW,
            }
            
          );
         
          return result;
        } catch (error) {
          throw error;
        }
      }

      async getTaskDetails(req) {
        const id=req.body.id|| "";

        const procedureName = "getTaskDetails";
    
        try {
          const result = await db.query(
            `CALL ${procedureName}(:id)`,
            {
              replacements: {id},
              type: db.QueryTypes.RAW,
            }
            
          );
          
          return result;
        } catch (error) {
          throw error;
        }
      }



	 
}

module.exports = TicketData;
