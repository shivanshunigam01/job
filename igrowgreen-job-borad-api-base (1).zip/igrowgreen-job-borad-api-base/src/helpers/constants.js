
/* Mail Constants for mail sending Process */
exports.emailConst = {
    admin: {
        name: "Admin",
        email: "nodeaha@gmail.com"
    },
    confirmEmails: {
        from: "nodeaha@gmail.com"
    }
};

// Device Type Constant 
exports.deviceType = {
    Web: 1,
    Android: 2,
    iOs: 3,
}

exports.smsTypeVerifyOtp={
   APPLICATION_SUBMITTED_VERIFIED:1,
   REGISTRATION_LETTER_OTP_VERIFIED:2,
   SLD_OTP_VERIFIED:3

}

exports.smsTypeSendOtp={
    APPLICATION_SUBMITTED_OTP_SEND:100,
    REGISTRATION_LETTER_OTP_SEND:101,
    SLD_OTP_SEND:102
    
}

exports.smsTypeDocumentsSubmission={
   SIGNED_DOCUMENTS_SUBMITTED:200,
   STAGE2_DOCUMENTS_SUBMITTED:201,
   WORK_EXECUTED_SUCCESFULLY:202,
   SITE_VISIT_DATE_CONFIRMED:203,
   SITE_VISIT_APPROVED:204
}

exports.smsTypeDocumentsRejection={  
    STAGE2_DOCUMENTS_REJECTED:300,
    FEASIBILITY_REJECTED:301
   
 }

exports.meterTypeDropDown={
    1:"1-Phase Whole Current meter",
    2:"3-Phase Whole Current meter",
    3:"LTCT meter",
    4:"HTCT meter"
}

exports.smsTypeDocumentsVerification={
   SIGNED_DOCUMENTS_VERIFIED:300,
   TECHNICAL_FEASIBILITY_VERIFIED:301,
   STAGE2_DOCUMENTS_VERIFIED:302
}

exports.userType = {
		Admin: 0,
		User : 1
}

