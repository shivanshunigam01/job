const db = require("../../config/database.js");
const config = process.env;
const axios = require('axios');
const fs = require("fs");
const path = require('path');
const { Base64 } = require('js-base64');
var moment = require('moment');

// const { createCanvas } = require('canvas');
const puppeteer = require('puppeteer');

module.exports = {
    getUploadFile: getUploadFile,
    getApplicationById: getApplicationById,
    getLocationByLatLong:getLocationByLatLong,
    calculatePvInMeter:calculatePvInMeter,
    calculatePvInFoot: calculatePvInFoot,
    getSolarRediation: getSolarRediation,
    calculateMonthChartData: calculateMonthChartData,
    calculatecapitalcost: calculatecapitalcost,
    calculatecapitalcostwithsubsidy: calculatecapitalcostwithsubsidy,
    getBillingChart: getBillingChart,
    getTarifCalculation: getTarifCalculation,
    genrateApiChartData: genrateApiChartData,
    GetPaybackChartData: GetPaybackChartData,
    GenerateApplicationNo: GenerateApplicationNo,
    updateSolarCalcCapacity: updateSolarCalcCapacity,
    updateDataAfterReduceCapacity: updateDataAfterReduceCapacity,
    // generate lead id dynamic
    GenerateLeadIDNo: GenerateLeadIDNo,

    // application create and update function 
    createApplication3rd: createApplication3rd,
    updateApplication3rd: updateApplication3rd,
    convertDateFormat: convertDateFormat,
    extractRegistrationCode: extractRegistrationCode,

    // common function for the masking data
    maskSensitiveData: maskSensitiveData,

	// common captcha functions
	generateCaptcha:generateCaptcha,
	textToDataURL:textToDataURL

};

function degrees_to_radians(degrees) {
    var pi = Math.PI;
    return degrees * (pi / 180);
}
async function calculatePvInMeter(area = '') {
    if (area == '')
        return false;
    var pvArea = 0;
    if (area <= 80) {
        pvArea = (area * 30 / 100);
    } else if (area <= 300) {
        pvArea = (area * 50 / 100);
    } else {
        pvArea = (area * 80 / 100);
    }
    return pvArea;
}
async function calculatePvInFoot(area = '') {
    if (area == '')
        return false;
    var pvArea = 0;
    if (area <= 861.11) {
        pvArea = (area * 30 / 100);
    } else if (area == 3229.1) {
        // echo "xc";
        pvArea = (area * 50 / 100);
    } else {
        pvArea = (area * 80 / 100);
    }
    return pvArea;
}
async function getInterestOnLoan(years, capitalCost) {
    var MORATORIUM_PERIOD = 1;
    var CAPITAL_SUBSIDY = 0;
    var LOAN_TENURE = 10;
    var INTEREST_RATE_ON_LOAN = 12;
    var DEBT_FRATION = 70;
    var arrResult = [];
    for (let i = 1; i <= years; i++) {
        var openinig_amount = 0;
        var annual_principal_paid = 0;
        var closing_balance = 0;
        var annual_interest = 0;
        var interest_on_loan = 0;

        if (i == 1) {
            openinig_amount = ((capitalCost * (1 - (CAPITAL_SUBSIDY / 100))) * (DEBT_FRATION / 100) * 100000);
            annual_principal_paid = (i > MORATORIUM_PERIOD ? (i <= (LOAN_TENURE + MORATORIUM_PERIOD) ? openinig_amount / (LOAN_TENURE) : 0) : 0)

            closing_balance = openinig_amount - annual_principal_paid;

            annual_interest = (((openinig_amount + closing_balance) / 2) * (INTEREST_RATE_ON_LOAN / 100));

            interest_on_loan = (annual_interest / 100000);
            // arrResult[i] ={
            //     openinig_amount:((capitalCost * (1-(CAPITAL_SUBSIDY/100))) * (DEBT_FRATION/100) * 100000),
            // };
            //	arrResult[i]['openinig_amount'] 		= ((capitalCost * (1-(CAPITAL_SUBSIDY/100))) * (DEBT_FRATION/100) * 100000);

            // arrResult[i] ={
            //     annual_principal_paid: (i>MORATORIUM_PERIOD?(i<=(LOAN_TENURE+MORATORIUM_PERIOD)?arrResult[i].openinig_amount/(LOAN_TENURE):0):0),
            // };
            // //arrResult[i]['annual_principal_paid'] = (i>MORATORIUM_PERIOD?(i<=(LOAN_TENURE+MORATORIUM_PERIOD)?arrResult[i]['openinig_amount']/(LOAN_TENURE):0):0);
            // arrResult[i] ={
            //     closing_balance:  arrResult[i].openinig_amount - arrResult[i].annual_principal_paid,
            // };
            // //arrResult[i]['closing_balance'] 		= arrResult[i]['openinig_amount'] - arrResult[i]['annual_principal_paid'];
            // arrResult[i] ={
            //     annual_interest:  (((arrResult[i].openinig_amount+arrResult[i].closing_balance)/2) * (INTEREST_RATE_ON_LOAN/100)),
            // };
            // //arrResult[i]['annual_interest']	 	= (((arrResult[i]['openinig_amount']+arrResult[i]['closing_balance'])/2) * (INTEREST_RATE_ON_LOAN/100)); 
            // arrResult[i] ={
            //     interest_on_loan: (arrResult[i].annual_interest/100000),
            // };
            // arrResult[i]['interest_on_loan'] 		= (arrResult[i]['annual_interest']/100000);
        } else {
            openinig_amount = arrResult[i - 1].closing_balance;
            annual_principal_paid = ((i > MORATORIUM_PERIOD) ? ((i <= (LOAN_TENURE + MORATORIUM_PERIOD)) ? (openinig_amount / (LOAN_TENURE)) : 0) : 0)

            closing_balance = openinig_amount - annual_principal_paid;

            annual_interest = (((openinig_amount + closing_balance) / 2) * (INTEREST_RATE_ON_LOAN / 100));

            interest_on_loan = (annual_interest / 100000);

            // arrResult[i] ={
            //     openinig_amount:arrResult[i-1].closing_balance,
            // };

            // arrResult[i] ={
            //     annual_principal_paid:  ((i>MORATORIUM_PERIOD)?((i<=(LOAN_TENURE+MORATORIUM_PERIOD))?(arrResult[i].openinig_amount/(LOAN_TENURE)):0):0),
            // };

            // arrResult[i] ={
            //     closing_balance:  arrResult[i].openinig_amount - arrResult[i].annual_principal_paid
            // };

            // arrResult[i] ={
            //     annual_interest:  (((arrResult[i].openinig_amount+arrResult[i].closing_balance)/2) * (INTEREST_RATE_ON_LOAN/100)),
            // };

            // arrResult[i] ={
            //     interest_on_loan: (arrResult[i].annual_interest/100000),
            // };

            //arrResult[i]['openinig_amount'] 		= arrResult[i-1]['closing_balance'];
            //	arrResult[i]['annual_principal_paid'] = ((i>MORATORIUM_PERIOD)?(($i<=(LOAN_TENURE+MORATORIUM_PERIOD))?(arrResult[i]['openinig_amount']/(LOAN_TENURE)):0):0);
            //	arrResult[i]['closing_balance'] 		= arrResult[i]['openinig_amount'] - arrResult[i]['annual_principal_paid'];
            //	arrResult[i]['annual_interest']	 	= (((arrResult[i]['openinig_amount']+arrResult[i]['closing_balance'])/2) * (INTEREST_RATE_ON_LOAN/100)); 
            //arrResult[i]['interest_on_loan'] 		= (arrResult[i]['annual_interest']/100000);
        }
        arrResult[i] = {
            openinig_amount: openinig_amount,
            annual_principal_paid: annual_principal_paid,
            closing_balance: closing_balance,
            annual_interest: annual_interest,
            interest_on_loan: interest_on_loan
        };
    }
    return arrResult;
}
async function GenerateApplicationNo() {
    var StateCode = await GetStateCode("", "");
    var appendStr = "RES";

    var financialyear = await GetGenerateFinancialYear();
    var strConnection = '';
    var application_id = 0;
    var selectQuery = "SELECT id FROM apply_onlines ORDER BY id DESC LIMIT 1";
    var rsltSingle = await db.query(selectQuery, {
        replacements: {},
        type: db.QueryTypes.SELECT
    });
    if (rsltSingle && rsltSingle.length > 0) {
        application_id = rsltSingle[0].id + 1;
    } else {
        application_id = 1;
    }
    // $ApplyOnlinesOthers = TableRegistry::get('ApplyOnlinesOthers');
    // $ApplyOthersDetails = $ApplyOnlinesOthers->find('all',array('conditions'=>array('application_id'=>$id)))->first();
    // if(!empty($ApplyOthersDetails->consumer_connection)) {
    // 	$strConnection 	= substr($ApplyOthersDetails->consumer_connection, -1);
    // }
    // if(empty($StateCode)) {
    // 	$StateCode 		= 'GUJ';
    // }
    var application_id_str = await generateApplicationString(application_id + "", 7);
    var id = StateCode + "/" + financialyear + "/" + appendStr + "/1" + application_id_str;
    return id;
}
async function generateApplicationString(application_id, len = 7) {
    var applicationIdStr = ""

    for (let i = 0; i < (len - application_id.length); i++) {
        applicationIdStr += "0";
    }
    var appStr = applicationIdStr + application_id;

    return appStr.toString();
}
async function GetGenerateFinancialYear(date = '') {
    var Year = parseInt(moment().format('YY'));
    var Month = parseInt(moment().format('MM'));
    // var Month   = new Date().getMonth();
    // var Year   = new Date().getYear();
    var ChallanNo = "";
    if (parseInt(Month) >= 1 && parseInt(Month) <= 3) {
        ChallanNo = ChallanNo + (Year - 1) + "-" + Year;
    } else {
        ChallanNo = ChallanNo + (Year) + "-" + (Year + 1);

    }
    //$ChallanNo .= str_pad($recipt_no,4,"0",STR_PAD_LEFT);
    return ChallanNo;
}
async function GetStateCode(state, state_name = "") {
    // $STATENAME  = "";
    // $Code       = "";
    // $States     = TableRegistry::get('States');
    // $arrState   = $States->find("all",['conditions'=>['OR'=>['States.id'=>$state,'States.statename'=>$state]]])->first();
    // if(!empty($arrState)) {
    // 	$STATENAME = $arrState->state_code;
    // 	$Code = $STATENAME;
    // } else {
    // 	$arrState   = $States->find("all",['conditions'=>['OR'=>['LOWER(States.statename)'=>strtolower($state_name)]]])->first();
    // 	if(!empty($arrState)) {
    // 		$STATENAME  = $arrState->state_code;
    // 		$Code       = $STATENAME;
    // 	}
    // 	else
    // 	{
    // 		$STATENAME  = $state_name;
    // 		$Code       = strtoupper(substr($STATENAME,0,2));
    // 	}

    // }
    var stateCode = config.stateCode;
    return stateCode;
}
async function getTarifCalculation(year, curYearEnergyGenerated, avg_monthly_bill, capitalCost) {
    var years = year;
    var curYearEnergyGenerated = curYearEnergyGenerated;
    var capitalCost = capitalCost;
    var tariff_value = [];
    var cog_value = [];
    var levelized_cog_value = {};
    var result = [];

    var suminsuranceval = 0;
    var cog_o_and_m_total = 0;
    var discount_factor_total = 0;
    var cog_depreciation_total = 0;
    var cog_insurance_cost_total = 0;
    var cog_return_on_equity_total = 0;
    var cog_tax_total = 0;
    var cog_gross_cost_total = 0;
    var cog_ad_tax_benifit_total = 0;
    var cog_net_cost_total = 0;
    var O_AND_M_COST = 0.75;
    var RATE_OF_ACCELERATED_DEPRE = 40;
    var CORPORATE_TAX_RATE = 34.64;
    var RATE_DEPRECATION_FOR_10 = 6;
    var RATE_DEPRECATION_NEXT_15 = 2;
    var DEBT_FRATION = 70;
    var ANNUAL_DEGREDATION = 1;
    var O_AND_M_ESCLATION = 5.72;
    var MIN_ALTERNATE_TAX_RATE = 20.01;
    var ALTERNATE_TAX_RATE = 10;
    var ROE = 15;
    var DISCOUNT_FACTOR = 10.81;

    // var RATE_OF_ACCELERATED_DEPRE=40;
    //########### Get interest loan ###############	
    var loanDataRes = await getInterestOnLoan(years, capitalCost);

    for (let i = 1; i <= years; i++) {
        var net_generation = 0;
        var o_and_m_expense = 0;
        var insurance_cost = 0;
        var accelerated_opening_balance = 0;
        var accelerated_depreciation_rate = 0;
        var accelerated_depreciation_amount = 0;
        var accelerated_closing_balance = 0;
        var AD_Benefit = 0;
        var depreciation = 0;
        var interest_on_loan = 0;
        var return_on_equity = 0;
        var tax = 0;
        var gross_cost = 0;
        var ad_tax_benifit = 0;
        var net_cost = 0;
        var gross_cost = 0;
        var discount_factor = 0;
        // ######################################### TARIFF CALCULATION ######################################		
        if (i == 1) {
            net_generation = curYearEnergyGenerated;
            o_and_m_expense = capitalCost * (O_AND_M_COST / 100);
            insurance_cost = capitalCost * (O_AND_M_COST / 100);
            accelerated_opening_balance = capitalCost * 100000;
            accelerated_depreciation_rate = (RATE_OF_ACCELERATED_DEPRE / 100);
            accelerated_depreciation_amount = accelerated_opening_balance * accelerated_depreciation_rate;
            accelerated_closing_balance = accelerated_opening_balance - accelerated_depreciation_amount;
            AD_Benefit = accelerated_depreciation_amount * (CORPORATE_TAX_RATE / 100);

            // tariff_value[i]['net_generation'] 	= curYearEnergyGenerated;
            //     tariff_value[i] ={
            //         net_generation:curYearEnergyGenerated
            //     };
            //    // tariff_value[i]['o_and_m_expense'] 	= capitalCost * (O_AND_M_COST/100);
            //     tariff_value[i] ={
            //         o_and_m_expense:capitalCost * (O_AND_M_COST/100)
            //     };
            //    // tariff_value[i]['insurance_cost']	= capitalCost * (O_AND_M_COST/100);
            //     tariff_value[i] ={
            //         insurance_cost:capitalCost * (O_AND_M_COST/100)
            //     };
            //     /* used this for calculate advanced tax benefit */
            //    // tariff_value[i]['accelerated_opening_balance']   		= capitalCost * 100000;
            //     tariff_value[i] ={
            //         accelerated_opening_balance:capitalCost * 100000
            //     };
            //     //tariff_value[i]['accelerated_depreciation_rate']  	= (RATE_OF_ACCELERATED_DEPRE/100); 
            //     tariff_value[i] ={
            //         accelerated_depreciation_rate:(RATE_OF_ACCELERATED_DEPRE/100)
            //     };
            //    // tariff_value[i]['accelerated_depreciation_amount']	= tariff_value[i]['accelerated_opening_balance'] * tariff_value[i]['accelerated_depreciation_rate'];
            //     tariff_value[i] ={
            //         accelerated_depreciation_amount:tariff_value[i].accelerated_opening_balance * tariff_value[i].accelerated_depreciation_rate
            //     };
            //   //  tariff_value[i]['accelerated_closing_balance'] 		= tariff_value[i]['accelerated_opening_balance'] - tariff_value[i]['accelerated_depreciation_amount'];
            //     tariff_value[i] ={
            //         accelerated_closing_balance:tariff_value[i].accelerated_opening_balance - tariff_value[i].accelerated_depreciation_amount
            //     };
            //    // tariff_value[i]['AD Benefit'] 						= tariff_value[i]['accelerated_depreciation_amount'] * (CORPORATE_TAX_RATE/100);
            //     tariff_value[i] ={
            //         AD_Benefit:tariff_value[i].accelerated_depreciation_amount * (CORPORATE_TAX_RATE/100)
            //     };
            /* used this for calculate advanced tax benefit */
        } else {

            net_generation = tariff_value[i - 1].net_generation * (1 - (ANNUAL_DEGREDATION / 100));
            o_and_m_expense = tariff_value[i - 1].o_and_m_expense * (1 + (O_AND_M_ESCLATION / 100));

            suminsuranceval += tariff_value[i - 1].insurance_cost;

            insurance_cost = (capitalCost - (suminsuranceval)) * (O_AND_M_COST / 100);
            accelerated_opening_balance = tariff_value[i - 1].accelerated_closing_balance;
            accelerated_depreciation_rate = (RATE_OF_ACCELERATED_DEPRE / 100);
            accelerated_depreciation_amount = accelerated_opening_balance * accelerated_depreciation_rate;

            accelerated_closing_balance = accelerated_opening_balance - accelerated_depreciation_amount;
            AD_Benefit = accelerated_depreciation_amount * (CORPORATE_TAX_RATE / 100);


            // tariff_value[i] ={
            //     net_generation:tariff_value[i-1].net_generation * (1-(ANNUAL_DEGREDATION/100))
            // };

            // tariff_value[i] ={
            //     o_and_m_expense:tariff_value[i-1].o_and_m_expense * (1+(O_AND_M_ESCLATION/100))
            // };

            // suminsuranceval += tariff_value[i-1].insurance_cost;          

            // tariff_value[i] ={
            //     insurance_cost:(capitalCost-(suminsuranceval)) * (O_AND_M_COST/100)
            // };

            // tariff_value[i] ={
            //     accelerated_opening_balance:tariff_value[i-1].accelerated_closing_balance
            // };

            // tariff_value[i] ={
            //     accelerated_depreciation_rate:(RATE_OF_ACCELERATED_DEPRE/100)
            // };

            // tariff_value[i] ={
            //     accelerated_depreciation_amount: tariff_value[i].accelerated_opening_balance * tariff_value[i].accelerated_depreciation_rate 
            // };

            // tariff_value[i] ={
            //     accelerated_closing_balance:tariff_value[i].accelerated_opening_balance - tariff_value[i].accelerated_depreciation_amount
            // };

            // tariff_value[i] ={
            //     AD_Benefit:tariff_value[i].accelerated_depreciation_amount * (CORPORATE_TAX_RATE/100)
            // };
            // tariff_value[i]['net_generation'] 					= tariff_value[i-1]['net_generation'] * (1-(ANNUAL_DEGREDATION/100));
            // tariff_value[i]['o_and_m_expense'] 					= tariff_value[i-1]['o_and_m_expense'] * (1+(O_AND_M_ESCLATION/100));
            //  $suminsuranceval 									+= tariff_value[i-1]['insurance_cost']; 
            //   tariff_value[i]['insurance_cost']						= (capitalCost-($suminsuranceval)) * (O_AND_M_COST/100);
            /* used this for calculate advanced tax benefit */
            //    tariff_value[i]['accelerated_opening_balance']   		= tariff_value[i-1]['accelerated_closing_balance'];
            // tariff_value[i]['accelerated_depreciation_rate']  	= (RATE_OF_ACCELERATED_DEPRE/100); 
            // tariff_value[i]['accelerated_depreciation_amount']	= tariff_value[i]['accelerated_opening_balance'] * tariff_value[i]['accelerated_depreciation_rate'];
            //   tariff_value[i]['accelerated_closing_balance'] 		= tariff_value[i]['accelerated_opening_balance'] - tariff_value[i]['accelerated_depreciation_amount'];
            //  tariff_value[i]['AD Benefit'] 						= tariff_value[i]['accelerated_depreciation_amount'] * (CORPORATE_TAX_RATE/100);
            /* used this for calculate advanced tax benefit */
        }
        var depreciationAmt = (((i <= 10) ? RATE_DEPRECATION_FOR_10 : RATE_DEPRECATION_NEXT_15) / 100) * capitalCost * 100000;
        //tariff_value[i]['depreciation'] 		= depreciationAmt/100000;
        depreciation = depreciationAmt / 100000;
        interest_on_loan = loanDataRes[i].interest_on_loan;
        return_on_equity = capitalCost * (1 - (DEBT_FRATION / 100)) * (ROE / 100);
        tax = ((i <= ALTERNATE_TAX_RATE) ? ((return_on_equity * (MIN_ALTERNATE_TAX_RATE / 100)) / (1 - (MIN_ALTERNATE_TAX_RATE / 100))) : ((return_on_equity * (CORPORATE_TAX_RATE / 100)) / (1 - (CORPORATE_TAX_RATE / 100))));

        gross_cost = o_and_m_expense + depreciation + interest_on_loan + insurance_cost + return_on_equity + tax

        discount_factor = 1 / (Math.pow((1 + (DISCOUNT_FACTOR / 100)), (i - 1)))
        tariff_value[i] = {
            net_generation: net_generation,
            o_and_m_expense: o_and_m_expense,
            insurance_cost: insurance_cost,
            accelerated_opening_balance: accelerated_opening_balance,
            accelerated_depreciation_rate: accelerated_depreciation_rate,
            accelerated_depreciation_amount: accelerated_depreciation_amount,
            accelerated_closing_balance: accelerated_closing_balance,
            AD_Benefit: AD_Benefit,
            depreciation: depreciation,
            interest_on_loan: interest_on_loan,
            return_on_equity: return_on_equity,
            tax: tax,
            gross_cost: gross_cost,
            ad_tax_benifit: ad_tax_benifit,
            net_cost: net_cost,
            gross_cost: gross_cost,
            discount_factor: discount_factor,
        };
        //     tariff_value[i] ={
        //         interest_on_loan:loanDataRes[i].interest_on_loan
        //     };
        //   //  tariff_value[i]['interest_on_loan']	= $loanDataRes[i]['interest_on_loan'];
        //   tariff_value[i] ={
        //     return_on_equity:capitalCost * (1-(DEBT_FRATION/100))*(ROE/100)
        // };
        //  // tariff_value[i]['return_on_equity']	= capitalCost * (1-(DEBT_FRATION/100))*(ROE/100);
        //  tariff_value[i] ={
        //     tax:((i<=ALTERNATE_TAX_RATE)?((tariff_value[i].return_on_equity*(MIN_ALTERNATE_TAX_RATE/100))/(1-(MIN_ALTERNATE_TAX_RATE/100))):((tariff_value[i].return_on_equity*(CORPORATE_TAX_RATE/100))/(1-(CORPORATE_TAX_RATE/100))))
        // };
        //   //  tariff_value[i]['tax']				= ((i<=ALTERNATE_TAX_RATE)?((tariff_value[i]['return_on_equity']*(MIN_ALTERNATE_TAX_RATE/100))/(1-(MIN_ALTERNATE_TAX_RATE/100))):((tariff_value[i]['return_on_equity']*(CORPORATE_TAX_RATE/100))/(1-(CORPORATE_TAX_RATE/100))));
        //   tariff_value[i] ={
        //     gross_cost: tariff_value[i].o_and_m_expense + tariff_value[i].depreciation+tariff_value[i].interest_on_loan+tariff_value[i].insurance_cost+tariff_value[i].return_on_equity+tariff_value[i].tax
        // };
        //    // tariff_value[i]['gross_cost']			= tariff_value[i]['o_and_m_expense'] + tariff_value[i]['depreciation']+tariff_value[i]['interest_on_loan']+tariff_value[i]['insurance_cost']+tariff_value[i]['return_on_equity']+tariff_value[i]['tax'];
        //    tariff_value[i] ={
        //     ad_tax_benifit: (tariff_value[i].AD_Benefit/100000)
        // };
        //   // tariff_value[i]['ad_tax_benifit']		= (tariff_value[i]['AD Benefit']/100000);
        //   tariff_value[i] ={
        //     net_cost:  tariff_value[i].gross_cost-tariff_value[i].ad_tax_benifit
        // };
        //   //  tariff_value[i]['net_cost']	= tariff_value[i]['gross_cost']-tariff_value[i]['ad_tax_benifit'];

        //    // ######################################### Discount FACTOR #########################################
        //    tariff_value[i] ={
        //     discount_factor:  1/(Math.pow((1+(DISCOUNT_FACTOR/100)),(i-1)))
        //     };
        // tariff_value[i]['discount_factor']	= 1/(pow((1+(DISCOUNT_FACTOR/100)),(i-1)));

        // ######################################### Discounted COG ###########################################
        cog_value[i] = {
            o_and_m_expense: ((curYearEnergyGenerated > 0) ? (tariff_value[i].o_and_m_expense * tariff_value[i].discount_factor * 100000) / (curYearEnergyGenerated) : 0),
            depreciation: ((curYearEnergyGenerated > 0) ? (tariff_value[i].depreciation * tariff_value[i].discount_factor * 100000) / (curYearEnergyGenerated) : 0),
            interest_on_loan: ((tariff_value[i].net_generation > 0) ? (tariff_value[i].interest_on_loan * tariff_value[i].discount_factor * 100000) / (tariff_value[i].net_generation) : 0),
            insurance_cost: ((curYearEnergyGenerated > 0) ? (tariff_value[i].insurance_cost * tariff_value[i].discount_factor * 100000) / (curYearEnergyGenerated) : 0),

            return_on_equity: ((curYearEnergyGenerated > 0) ? (tariff_value[i].return_on_equity * tariff_value[i].discount_factor * 100000) / (curYearEnergyGenerated) : 0)
            ,
            tax: ((tariff_value[i].net_generation > 0) ? (tariff_value[i].tax * tariff_value[i].discount_factor * 100000) / (tariff_value[i].net_generation) : 0)
            ,
            gross_cost: ((curYearEnergyGenerated > 0) ? (tariff_value[i].gross_cost * tariff_value[i].discount_factor * 100000) / (curYearEnergyGenerated) : 0)
            ,
            ad_tax_benifit: ((curYearEnergyGenerated > 0) ? (tariff_value[i].ad_tax_benifit * tariff_value[i].discount_factor * 100000) / (curYearEnergyGenerated) : 0)
            ,
            net_cost: ((curYearEnergyGenerated > 0) ? (tariff_value[i].net_cost * tariff_value[i].discount_factor * 100000) / (curYearEnergyGenerated) : 0)
        };

        // cog_value[i]['net_cost'] 				= ((curYearEnergyGenerated > 0)?(tariff_value[i]['net_cost'] * tariff_value[i]['discount_factor'] * 100000)/(curYearEnergyGenerated):0);

        //######################################### Levelized COG ###########################################
        cog_o_and_m_total += cog_value[i].o_and_m_expense;
        cog_depreciation_total += cog_value[i].depreciation;
        cog_insurance_cost_total += cog_value[i].insurance_cost;
        cog_return_on_equity_total += cog_value[i].return_on_equity;
        cog_tax_total += cog_value[i].tax;
        cog_gross_cost_total += cog_value[i].gross_cost;
        cog_ad_tax_benifit_total += cog_value[i].ad_tax_benifit;
        cog_net_cost_total += cog_value[i].net_cost;
        discount_factor_total += tariff_value[i].discount_factor;
    }

    levelized_cog_value = {
        o_and_m_expense: (cog_o_and_m_total) / (discount_factor_total),
        depreciation: (cog_depreciation_total) / (discount_factor_total),
        interest_on_loan: '',
        insurance_cost: (cog_insurance_cost_total) / (discount_factor_total),
        return_on_equity: (cog_return_on_equity_total) / (discount_factor_total),
        tax: (cog_tax_total) / (discount_factor_total),
        gross_cog: (cog_gross_cost_total) / (discount_factor_total),
        tax_benefit: (cog_ad_tax_benifit_total) / (discount_factor_total),
        net_cog: (cog_net_cost_total) / (discount_factor_total),

    }
    // levelized_cog_value['o_and_m_expense']			= (cog_o_and_m_total)/(discount_factor_total);
    // levelized_cog_value['depreciation']			= (cog_depreciation_total)/(discount_factor_total);
    // levelized_cog_value['interest_on_loan'] 		= '';
    // levelized_cog_value['insurance_cost'] 			= (cog_insurance_cost_total)/(discount_factor_total);
    // levelized_cog_value['return_on_equity'] 		= (cog_return_on_equity_total)/(discount_factor_total);
    // levelized_cog_value['tax'] 			= (cog_tax_total)/(discount_factor_total);
    // levelized_cog_value['gross_cog'] 				= (cog_gross_cost_total)/(discount_factor_total);
    // levelized_cog_value['tax_benefit']				= (cog_ad_tax_benifit_total)/(discount_factor_total);
    // levelized_cog_value['net_cog'] 				= (cog_net_cost_total)/(discount_factor_total);
    // result['gross_cog'] 	= levelized_cog_value['gross_cog'];
    // result['net_cog'] 		= levelized_cog_value['net_cog'];
    result = {
        gross_cog: levelized_cog_value.gross_cog,
        net_cog: levelized_cog_value.net_cog,
    }
    return result;
}
async function genrateApiChartData(fromPvSystem = [], monthChartDataArr) {
    //console.log("fromPvSystem==>",fromPvSystem);
    //console.log("monthChartDataArr==>",monthChartDataArr);

    var year = new Date().getFullYear();
    var yearChart = [];
    var monthChart = [];
    var yearArr = [];
    var monthArr = [];
    var allArr = [];
    fromPvSystem.forEach((arrChartType, index) => {
        var key = index + 1;

        if (key <= 12) {
            monthDataVal = (monthChartDataArr[key] ? Math.round(monthChartDataArr[key]) : 0);
            monthArr.push({
                x: key,
                y: monthDataVal,
            });
        }
        //$yearArr[]=	"{'x':".$year.",'y':".$arrChartType['yearlyEnergyGenerated']."}";
        yearArr.push({
            x: year,
            y: arrChartType['yearlyEnergyGenerated'],
        });
        year++;


    });
    // foreach($fromPvSystem as $key=>$arrChartType)
    // {
    // 	if($key <= 12) {
    // 		$monthDataVal 	= (isset($monthChartDataArr[$key])?round($monthChartDataArr[$key]):0);
    // 		$monthArr[]		= "{'x':".$key.",'y':".$monthDataVal."}";
    // 	}	
    // 	$yearArr[]=	"{'x':".$year.",'y':".$arrChartType['yearlyEnergyGenerated']."}";
    // 	$year++;
    // }
    //return array('yearChart'=>'['.implode(',',$yearArr).']','monthChart'=>'['.implode(',',$monthArr).']');
    //console.log("monthArr==>",monthArr);
    //console.log("yearArr==>",yearArr);

    allArr['monthChart'] = monthArr;
    allArr['yearChart'] = yearArr;
    //console.log("allArr==>",allArr);
    return allArr;
}
async function GetPaybackChartData(estimated_cost, yearly_saving) {

    var year = new Date().getFullYear();
    var yearly_payback = [];
    var total_saving = 0;
    var estimated_cost = (estimated_cost ? estimated_cost * 100000 : 0);
    for (let i = 0; i < year + 24; i++) {
        yearly_payback.push(total_saving - estimated_cost);
        total_saving = total_saving + yearly_saving;
    }
    // for($i=$year;$i<=($year+24);$i++) {
    // 	$yearly_payback[$i] = $total_saving - $estimated_cost;
    // 	$total_saving 	= $total_saving + $yearly_saving;
    // }
    return yearly_payback;
}
async function getSolarRediation(lat, long) {
    var ghidata = [];
    ghidata = await getGhiData(lat, long);
    if (ghidata.length > 0)
        return ghidata;
    else
        return await getGhiData("23.0300", "72.5800");
}
async function calculateGTI(ghi, latitude, tilt, n = 82) {
    latitude = degrees_to_radians(latitude);
    tilt = degrees_to_radians(tilt);

    /* STEP 1: Calculate delta (Declination angle)*/
    delta = 23.45 * Math.sin(degrees_to_radians((360 / 365) * (n - 81)));
    delta = degrees_to_radians(delta);
    //prd(delta); 
    //prd(Math.tan(degrees_to_radians(delta)));
    /* STEP 2: Calculate Hsr */
    Hsr = Math.acos(-Math.tan(latitude) * Math.tan(delta));


    /* STEP 3: Calculate Hsrc */
    //prd(Math.acos(-Math.tan(8) * Math.tan(delta)));
    HsrVal1 = Math.acos(-Math.tan(latitude) * Math.tan(delta));
    HsrVal2 = Math.acos(-Math.tan(latitude - tilt) * Math.tan(delta));
    Hsrc = Math.min(HsrVal1, HsrVal2);

    /* STEP 4: Calculate Io */
    //pie = Math.PI;
    pie = 3.1415926536;
    Io = (24 / pie) * 1.37 * (1 + (0.034 * Math.cos(360 * n / 365))) * ((Math.cos(latitude) * Math.cos(delta) * Math.sin(Hsr)) + (Hsr * Math.sin(latitude) * Math.sin(delta)));

    /* STEP 5: Calculate Kt */
    Kt = ghi / Io;

    /* STEP 6: Diffuse  Idh */
    Idh = ghi * (1.39 - (4.027 * Kt) + (5.531 * Math.pow(Kt, 2)) - (3.108 * Math.pow(Kt, 3)));

    /* STEP 7: Beam Calculate Ibh */
    Ibh = ghi - Idh;

    /* STEP 8: Diffuse @ Tilt, Idc */
    $Idc = Idh * (1 + Math.cos(tilt)) / 2;

    /* STEP 9: Calculate Irc */
    albedo = 0.2;  // constant generally taken as 0.2
    $Irc = albedo * ghi * (1 - Math.cos(tilt)) / 2;

    /* STEP 10: Calculate Rb */
    RbU = ((Math.cos(latitude - tilt) * Math.cos(delta) * Math.sin(Hsrc)) + (Hsrc * Math.sin(latitude - tilt) * Math.sin(delta)));
    RbL = ((Math.cos(latitude) * Math.cos(delta) * Math.sin(Hsr)) + (Hsr * Math.sin(latitude) * Math.sin(delta)));
    Rb = RbU / RbL;

    /* STEP 11: calculate Ibc  Ibh = beam, */
    Ibc = Ibh * Rb;

    /* STEP 12: Calculate GTI */
    GTI = (ghi * (1 - (Idh / ghi)) * Rb) + (Idh * (1 + Math.cos(tilt)) / 2) + (albedo * ghi * (1 - Math.cos(tilt)) / 2);

    /*$debugData = 
    [	'STEP1: delta ' => delta,
        'STEP2: Hsr ' 	=> Hsr,
        'STEP3: Hsrc ' => Hsrc,
        'STEP4: Io ' 	=> Io,
        'STEP5: Kt ' 	=> Kt,
        'STEP6: Diffuse Idh ' => Idh,
        'STEP7: Beam Ibh ' => Ibh,
        'STEP8: Diffuse @Tilt $Idc ' => $Idc,
        'STEP9: $Irc ' => $Irc,
        'STEP10: Rb ' => Rb,
        'STEP11: Ibc ' => Ibc,
        'STEP12: GTI ' => GTI,	
    ];
    prd($debugData);
    */
    return GTI;
}
async function getGhiData(lat, long) {
    var latitude = await getRoundLatLong(lat);
    var longitude = await getRoundLatLong(long);
    var latLongStr = longitude + "" + latitude;
    var gridcode = latLongStr.replace(".", "");
    gridcode = gridcode.replace(".", "");
    gridcode = gridcode.replace(" ", "");
    // var n = [0,17,47,75,106,135,166,198,228,258,288,318,344]; 
    var n = [17, 47, 75, 106, 135, 166, 198, 228, 258, 288, 318, 344];
    var allMonths = ['jan', 'feb', 'mar', "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
    var selectQuery = "SELECT * FROM `ghi_data` WHERE gridcode=:id";
    var rsltSingle = await db.query(selectQuery, {
        replacements: { id: parseInt(gridcode) },
        type: db.QueryTypes.SELECT
    });
    if (rsltSingle) {
        var rsltSingleArr = []
        if (rsltSingle.length > 0) {
            var rsltSingleData = rsltSingle[0]
            var GTIAnnual = 0;
            var GTIValNew = 0;
            allMonths.forEach(async (month, index) => {
                var keyName = "";
                keyName = month + "_glo";
                GHIVal = rsltSingleData[keyName] ? rsltSingleData[keyName] : 0;
                if (GHIVal != 0) {
                    GTIValNew = await calculateGTI(GHIVal, lat, lat, n[index]);
                    rsltSingleArr.push({
                        key: keyName,
                        val: GTIValNew
                    });
                    //rsltSingleArr[keyName] = GTIValNew;
                }
                GTIAnnual = GTIAnnual + GTIValNew;
                if (allMonths.length === index + 1) {
                    rsltSingleArr.push({
                        key: 'ann_glo',
                        val: (GTIAnnual / 12)
                    });
                    rsltSingleArr.push({
                        key: 'sqkm',
                        val: rsltSingleData['sqkm']
                    });
                    rsltSingleArr.push({
                        key: 'latitude',
                        val: latitude
                    });
                    rsltSingleArr.push({
                        key: 'longitude',
                        val: longitude
                    });
                    rsltSingleArr.push({
                        key: 'gridcode',
                        val: rsltSingleData['gridcode']
                    });
                    rsltSingleArr.push({
                        key: 'id',
                        val: rsltSingleData['id']
                    });
                }

            });
            // for(var i=1;i<=12;i++) {
            // 	keyName 		= strtolower(date('M', mktime(0, 0, 0, i, 10)))+"_glo";
            // 	GHIVal 	= rsltSingle[keyName] ? rsltSingle[keyName] : 0 ;

            // 	/* Calculate GTI from GHI, lat, lng and constant n */
            // 	if(GHIVal != 0) {
            // 		GTIValNew  = await calculateGTI(GHIVal,$lat,$lat,n[i]);
            // 		rsltSingleArr[keyName] = GTIValNew;
            // 	}
            // 	GTIAnnual = GTIAnnual + $ghiData[keyName];
            // }
            // if(GTIAnnual > 0){
            //rsltSingleArr.push({'ann_glo':(GTIAnnual/12)});
            // }
        }

        return rsltSingleArr ? rsltSingleArr : [];
        // return rsltSingle ;
    } else {
        return [];
    }

}
async function calculateGeneratorUsage(contract_load = 0, usage_hours) {
    var GENERATOR_ELECTRICITY_COST = 15;
    var cost_electricty = 0;
    usage_hours = (usage_hours ? usage_hours : 0);
    var electricity_equivalent = ((usage_hours > 0) ? usage_hours : 0) * 0.5 * contract_load;
    var cost_electricty_day = electricity_equivalent * GENERATOR_ELECTRICITY_COST;
    var cost_electricty = ((cost_electricty_day > 0) ? (cost_electricty_day * 365 / 12) : 0);
    return cost_electricty;
}
async function calculateInverterUsage(contract_load = 0, usage_hours) {
    var INVERTER_ELECTRICITY_COST = 10;

    var cost_electricty = 0;
    usage_hours = (usage_hours ? usage_hours : 0);
    var electricity_equivalent = ((usage_hours > 0) ? usage_hours : 0) * 0.5 * contract_load;
    var cost_electricty_day = electricity_equivalent * INVERTER_ELECTRICITY_COST;
    cost_electricty = ((cost_electricty_day > 0) ? (cost_electricty_day * 365 / 12) : 0);
    return cost_electricty;
}
async function getBillingChart(contractLoad, unitRate, averageEnrgyGenInYear, capitalCost, backUpType, usage_hours, cost_electricty = 0) {
    var BACKUP_TYPE_GENERATOR = 1;
    var BACKUP_TYPE_INVERTER = 2;
    var load_fectore = 30;
    var load_fectore_INCREASE = 3;

    var years = 25;
    var breakEvenPeriod = 0;
    capitalCost = (0 - (capitalCost * 100000));
    var firstMonthEnrgyGen = averageEnrgyGenInYear / 12;
    var solarChart = {};
    var conventionalScenarioArr = [];
    var fromPvSystem = [];
    var netEnergy = [];
    var cashFlows = [];
    var breakEvenAnalysis = [];
    var actualMonthlyCredit = 0;
    contractLoad = Math.round(contractLoad, 2);

    if (cost_electricty) {
        if (backUpType && backUpType == BACKUP_TYPE_GENERATOR) {
            cost_electricty = await calculateGeneratorUsage(contractLoad, usage_hours);
        } else if (backUpType && backUpType == BACKUP_TYPE_INVERTER) {
            cost_electricty = await calculateInverterUsage(contractLoad, usage_hours);
        }
    }
    for (let i = 1; i <= years; i++) {
        if (i == 1) {
            conventionalScenarioArr[i] = {
                loadFector: load_fectore
            };

            // conventionalScenarioArr[i]['loadFector']=load_fectore;
            fromPvSystem[i] = {
                monthlyEnergyGenerated: Math.round(firstMonthEnrgyGen),
                yearlyEnergyGenerated: Math.round(firstMonthEnrgyGen * 12),
            };
            // fromPvSystem[i]['monthlyEnergyGenerated']=Math.round(firstMonthEnrgyGen);
            // fromPvSystem[i]['yearlyEnergyGenerated']=Math.round(firstMonthEnrgyGen*12);
        } else {
            conventionalScenarioArr[i] = {
                loadFector: Math.round((conventionalScenarioArr[i - 1].loadFector * (1 + load_fectore_INCREASE / 100)), 2)
            };
            //  conventionalScenarioArr[i]['loadFector']=Math.round((conventionalScenarioArr[i-1].loadFector*(1+load_fectore_INCREASE/100)), 2);
            fromPvSystem[i] = {
                monthlyEnergyGenerated: Math.round(fromPvSystem[i - 1].monthlyEnergyGenerated - (fromPvSystem[i - 1].monthlyEnergyGenerated / 100))
            };
            // fromPvSystem[i] ={

            //     yearlyEnergyGenerated:Math.round(fromPvSystem[i].monthlyEnergyGenerated*12),
            // };
            // fromPvSystem[i]['monthlyEnergyGenerated']=Math.round(fromPvSystem[i-1]['monthlyEnergyGenerated']-(fromPvSystem[i-1]['monthlyEnergyGenerated']/100));

            fromPvSystem[i]['yearlyEnergyGenerated'] = Math.round(fromPvSystem[i]['monthlyEnergyGenerated'] * 12);
        }
        // conventionalScenarioArr[i] ={
        //     unitsConsumed:Math.round((((contractLoad*24*365)*conventionalScenarioArr[i].loadFector/100)/12)),
        //     totalMonthlyBill:Math.round(conventionalScenarioArr[i].unitsConsumed*unitRate+cost_electricty)
        // };
        conventionalScenarioArr[i].unitsConsumed = Math.round((((contractLoad * 24 * 365) * conventionalScenarioArr[i].loadFector / 100) / 12));
        conventionalScenarioArr[i].totalMonthlyBill = Math.round(conventionalScenarioArr[i].unitsConsumed * unitRate + cost_electricty);

        netEnergy[i] = {
            netMonthlyConsumption: Math.round(conventionalScenarioArr[i].unitsConsumed - fromPvSystem[i].monthlyEnergyGenerated),

        };
        //  netEnergy[i]={

        //     totalMonthlyBill:Math.round((netEnergy[i].netMonthlyConsumption || 1)*unitRate)
        //  };
        // netEnergy[i].netMonthlyConsumption=Math.round(conventionalScenarioArr[i].unitsConsumed-fromPvSystem[i].monthlyEnergyGenerated);
        netEnergy[i].totalMonthlyBill = Math.round((netEnergy[i].netMonthlyConsumption ?? 0) * unitRate);

        //conventionalScenarioArr[i].totalMonthlyBill=Math.round(conventionalScenarioArr[i].unitsConsumed*unitRate+cost_electricty);	
        cashFlows[i] = {
            netMonthlyCashFlow: Math.round(actualMonthlyCredit - netEnergy[i].totalMonthlyBill),

        }
        // cashFlows[i]={

        //     monthlyFinancialSaving:Math.round(conventionalScenarioArr[i].totalMonthlyBill+cashFlows[i].netMonthlyCashFlow),

        // }
        // cashFlows[i]={

        //     annualFinancialSaving:Math.round(cashFlows[i].monthlyFinancialSaving*12),
        // }
        // cashFlows[i].netMonthlyCashFlow=Math.round(actualMonthlyCredit-netEnergy[i].totalMonthlyBill);

        cashFlows[i].monthlyFinancialSaving = Math.round(conventionalScenarioArr[i].totalMonthlyBill + cashFlows[i].netMonthlyCashFlow);

        cashFlows[i].annualFinancialSaving = Math.round(cashFlows[i].monthlyFinancialSaving * 12);

        if (i == 1) {
            breakEvenAnalysis[i] = {
                cumulativeFinancialSaving: Math.round(capitalCost + cashFlows[i].annualFinancialSaving),

            }
            // breakEvenAnalysis[i]={

            //     addFraction:((capitalCost < 0 )?((breakEvenAnalysis[i].cumulativeFinancialSaving > 0 )?(breakEvenAnalysis[i].cumulativeFinancialSaving/(breakEvenAnalysis[i].cumulativeFinancialSaving-capitalCost)):0):0),
            // }
            // breakEvenAnalysis[i].cumulativeFinancialSaving=Math.round(capitalCost+cashFlows[i].annualFinancialSaving);

            breakEvenAnalysis[i].addFraction = ((capitalCost < 0) ? ((breakEvenAnalysis[i].cumulativeFinancialSaving > 0) ? (breakEvenAnalysis[i].cumulativeFinancialSaving / (breakEvenAnalysis[i].cumulativeFinancialSaving - capitalCost)) : 0) : 0);

        } else {
            breakEvenAnalysis[i] = {
                cumulativeFinancialSaving: Math.round(Number(breakEvenAnalysis[i - 1].cumulativeFinancialSaving ?? 0) + cashFlows[i].annualFinancialSaving),

            }
            // breakEvenAnalysis[i]={

            //     addFraction:((breakEvenAnalysis[i-1].cumulativeFinancialSaving < 0 )?((breakEvenAnalysis[i].cumulativeFinancialSaving > 0 )?(breakEvenAnalysis[i].cumulativeFinancialSaving/(breakEvenAnalysis[i].cumulativeFinancialSaving-breakEvenAnalysis[i-1].cumulativeFinancialSaving)):0):0),
            // }
            //    breakEvenAnalysis[i].cumulativeFinancialSaving=Math.round(breakEvenAnalysis[i-1].cumulativeFinancialSaving+cashFlows[i].annualFinancialSaving);

            breakEvenAnalysis[i].addFraction = ((breakEvenAnalysis[i - 1].cumulativeFinancialSaving < 0) ? ((breakEvenAnalysis[i].cumulativeFinancialSaving > 0) ? (breakEvenAnalysis[i].cumulativeFinancialSaving / (breakEvenAnalysis[i].cumulativeFinancialSaving - breakEvenAnalysis[i - 1].cumulativeFinancialSaving)) : 0) : 0);
        }
        // breakEvenAnalysis[i]={
        //     addYear:((breakEvenAnalysis[i].cumulativeFinancialSaving < 0 )?1:0),
        // };
        breakEvenAnalysis[i].addYear = ((breakEvenAnalysis[i].cumulativeFinancialSaving < 0) ? 1 : 0);
        breakEvenPeriod += breakEvenAnalysis[i].addYear;
        breakEvenPeriod += breakEvenAnalysis[i].addFraction;

    }
    // for($i=1;$i<=years;$i++)	
    // {
    // 	if($i==1) {
    // 		conventionalScenarioArr[$i]['loadFector']=load_fectore;
    // 		fromPvSystem[$i]['monthlyEnergyGenerated']=Math.round(firstMonthEnrgyGen);
    // 		fromPvSystem[$i]['yearlyEnergyGenerated']=Math.round(firstMonthEnrgyGen*12);
    // 	} else {
    // 		conventionalScenarioArr[$i]['loadFector']=Math.round((conventionalScenarioArr[$i-1]['loadFector']*(1+load_fectore_INCREASE/100)), 2);
    // 		fromPvSystem[$i]['monthlyEnergyGenerated']=Math.round(fromPvSystem[$i-1]['monthlyEnergyGenerated']-(fromPvSystem[$i-1]['monthlyEnergyGenerated']/100));
    // 		fromPvSystem[$i]['yearlyEnergyGenerated']=Math.round(fromPvSystem[$i]['monthlyEnergyGenerated']*12);
    // 	}
    // 	conventionalScenarioArr[$i]['unitsConsumed']=Math.round((((contractLoad*24*365)*conventionalScenarioArr[$i]['loadFector']/100)/12));	
    // 	netEnergy[$i]['netMonthlyConsumption']=Math.round(conventionalScenarioArr[$i]['unitsConsumed']-fromPvSystem[$i]['monthlyEnergyGenerated']);
    // 	netEnergy[$i]['totalMonthlyBill']=Math.round(netEnergy[$i]['netMonthlyConsumption']*unitRate);
    // 	conventionalScenarioArr[$i]['totalMonthlyBill']=Math.round(conventionalScenarioArr[$i]['unitsConsumed']*unitRate+cost_electricty);	
    // 	cashFlows[$i]['netMonthlyCashFlow']=Math.round(actualMonthlyCredit-netEnergy[$i]['totalMonthlyBill']);
    // 	cashFlows[$i]['monthlyFinancialSaving']=Math.round(conventionalScenarioArr[$i]['totalMonthlyBill']+cashFlows[$i]['netMonthlyCashFlow']);
    // 	cashFlows[$i]['annualFinancialSaving']=Math.round(cashFlows[$i]['monthlyFinancialSaving']*12);
    // 	if($i==1) {
    // 		breakEvenAnalysis[$i]['cumulativeFinancialSaving']=Math.round(capitalCost+cashFlows[$i]['annualFinancialSaving']);
    // 		breakEvenAnalysis[$i]['addFraction']=((capitalCost < 0 )?((breakEvenAnalysis[$i]['cumulativeFinancialSaving'] > 0 )?(breakEvenAnalysis[$i]['cumulativeFinancialSaving']/(breakEvenAnalysis[$i]['cumulativeFinancialSaving']-capitalCost)):0):0);
    // 	} else {
    // 		breakEvenAnalysis[$i]['cumulativeFinancialSaving']=Math.round(breakEvenAnalysis[$i-1]['cumulativeFinancialSaving']+cashFlows[$i]['annualFinancialSaving']);
    // 		breakEvenAnalysis[$i]['addFraction']=((breakEvenAnalysis[$i-1]['cumulativeFinancialSaving'] < 0 )?((breakEvenAnalysis[$i]['cumulativeFinancialSaving'] > 0 )?(breakEvenAnalysis[$i]['cumulativeFinancialSaving']/(breakEvenAnalysis[$i]['cumulativeFinancialSaving']-breakEvenAnalysis[$i-1]['cumulativeFinancialSaving'])):0):0);
    // 	}
    // 	breakEvenAnalysis[$i]['addYear']	=	((breakEvenAnalysis[$i]['cumulativeFinancialSaving'] < 0 )?1:0);
    // 	breakEvenPeriod+=breakEvenAnalysis[$i]['addYear'];
    // 	breakEvenPeriod+=breakEvenAnalysis[$i]['addFraction'];
    // }
    solarChart = {
        conventionalScenarioArr: conventionalScenarioArr,
        fromPvSystem: fromPvSystem,
        netEnergy: netEnergy,
        cashFlows: cashFlows,
        breakEvenAnalysis: breakEvenAnalysis,
        breakEvenPeriod: breakEvenPeriod
    };
    // solarChart['conventionalScenarioArr']=conventionalScenarioArr;
    // solarChart['fromPvSystem']=fromPvSystem;
    // solarChart['netEnergy']=netEnergy;
    // solarChart['cashFlows']=cashFlows;
    // solarChart['breakEvenAnalysis']=breakEvenAnalysis;
    // solarChart['breakEvenPeriod']=breakEvenPeriod;
    return solarChart;
}
async function getRoundLatLong(val) {
    var returnVal = 0;
    var firstDecimal = 0;
    var lastDecimal = 0;
    //console.log("val==>",val);
    if (val.length > 0) {

        var arrResult = parseFloat(val).toFixed(2).split(".");
        var whole = (arrResult[0]) || '0';
        var decimal = (arrResult[1]) || 0;
        if (decimal && parseInt(decimal) > 0) {
            firstDecimal = decimal.substr(0, 1);
            lastDecimal = decimal.substr(1) || 0;
        }
        // let lastDecimalStr = lastDecimal.replace(lastDecimal, 5);
        let lastDecimalStr = "5";
        returnVal = parseFloat(whole + "." + firstDecimal + lastDecimalStr);
    }
    return returnVal;
}
function daysInMonth(month, year) {
    return new Date(year, month, 0).getDate();
}
async function findActiveSchemeId() {
    var selectQuery = "SELECT id FROM `scheme_master` WHERE status=:status";
    var rsltSingle = await db.query(selectQuery, {
        replacements: { status: 1 },
        type: db.QueryTypes.SELECT
    });
    if (rsltSingle) {
        var arrSchemeIds = [];
        rsltSingle.forEach((element) => {
            arrSchemeIds.push(element.id)
        });
        if (arrSchemeIds.length === rsltSingle.length) {
            return arrSchemeIds;
        }

    } else {
        return [];
    }

}
async function findAllRates(installer_id = '', scheme_id = '', costCalculation = '') {

    var activeSchemeId = await findActiveSchemeId();
    var where = "";
    if (scheme_id && scheme_id != "") {
        where = where + " AND scheme_id=" + scheme_id;

    } else {
        where = where + " AND scheme_id IN(" + activeSchemeId + ")";
    }

    if (installer_id && installer_id != "") {
        where = where + " AND installer_id=" + installer_id;
    }

    var selectQuery = "SELECT * FROM `scheme_subsidy_master` WHERE 1=1 " + where;
    var rsltSingle = await db.query(selectQuery, {
        replacements: { installer_id: installer_id },
        type: db.QueryTypes.SELECT
    });
    if (rsltSingle) {
        var arr = [];
        rsltSingle.forEach((element, index) => {
            //  arr[index+1]=(element.benchmark_rate && element.benchmark_rate !="" && costCalculation !='') ?  element.benchmark_rate : element.capacity_rate
            arr.push((element.benchmark_rate && element.benchmark_rate != "" && costCalculation != '') ? element.benchmark_rate : element.capacity_rate)
        });
        if (arr.length === rsltSingle.length) {
            return arr;
        }

    } else {
        return [];
    }

}
async function findMinMaxSlots(scheme_id = '') {

    var activeSchemeId = await findActiveSchemeId();

    var where = "";
    if (scheme_id && scheme_id != "") {
        where = where + " AND scheme_id=" + scheme_id;

    } else {
        where = where + " AND scheme_id IN(" + activeSchemeId + ")";
    }



    var selectQuery = "SELECT * FROM `scheme_subsidy_master` WHERE 1=1 " + where;
    var rsltSingle = await db.query(selectQuery, {
        replacements: {},
        type: db.QueryTypes.SELECT
    });

    if (rsltSingle) {
        var arr = [];
        rsltSingle.forEach((element, index) => {

            // arr[index+1]={
            //     min:element.min_capacity,
            //     max:element.max_capacity,
            // }
            arr.push({
                min: element.min_capacity,
                max: element.max_capacity,
            })
            // arr[index+1]['min'] = ;
            // arr[index+1]['max'] = element.max_capacity;

        });
        if (arr.length === rsltSingle.length) {
            return arr;
        }

    } else {
        return [];
    }
    // if(!empty(scheme_id) && is_array(scheme_id)) {
    // 	$arrConditions['scheme_id in']	= scheme_id;
    // } elseif(!empty(scheme_id)) {
    // 	$arrConditions['scheme_id']		= scheme_id;
    // } else {
    // 	$arrConditions['scheme_id in']	= $activeSchemeId;
    // }

    // $arrRates 					= $this->find('all',array(
    // 								'conditions'=> $arrConditions
    // 							))->toArray();
    // $arr 						= array();
    // if(!empty($arrRates)) {
    // 	foreach($arrRates as $key=>rate) {
    // 		$arr[$key+1]['min'] = rate->min_capacity;
    // 		$arr[$key+1]['max'] = rate->max_capacity;
    // 	}
    // }
    // return $arr;
}
async function calculatecapitalcost(spvi = 0, state = '', customer_type = '', customer_id = 0, scheme_id = 0) {
    var COST_UPTO_10_KW = 0.70;
    var COST_FOR_10_TO_100_KW = 0.65;
    var COST_FOR_100_TO_500_KW = 0.60;
    var COST_FOR_500_TO_1000_KW = 0.55;
    var COST_FOR_1000_TO_10000_KW = 0.50;
    var COST_ABOVE_10000_KW = 0.45;
    if (spvi == '') return false;
    var cost = 0;
    if (state.toLowerCase() == 'gujarat' || state == '4') {
        var BAND_0 = 0.46827;
        var BAND_1 = 0.483;
        var BAND_2 = 0.48;
        var BAND_3 = 0.44;
        var BAND_4 = 0.41;




        if (spvi >= 0.1 && spvi < 1) {
            cost = (spvi * BAND_0);
        } else if (spvi >= 1 && spvi <= 6) {
            cost = (spvi * BAND_1);
        } else if (spvi > 6 && spvi <= 10) {
            cost = (spvi * BAND_2);
        } else if (spvi > 10 && spvi <= 50) {
            cost = (spvi * BAND_3);
        } else {
            cost = (spvi * BAND_4);
        }
        // $ApplyOnlines 		= TableRegistry::get('ApplyOnlines');
        // $StateSubsidy 		= TableRegistry::get('StateSubsidy');
        // $SchemeSubsidyMaster= TableRegistry::get('SchemeSubsidyMaster');
        var InstallerSlot = await findMinMaxSlots(scheme_id);//$ApplyOnlines->installer_slot_array;
        var BandArray = await findAllRates('', scheme_id, 1);
        if (customer_id == 55) {
            var arrRates = await findAllRates(customer_id, scheme_id, 1);
            BandArray = (arrRates && arrRates.length > 0) ? arrRates : BandArray;
        }
        var flagCost = 0;
        InstallerSlot.forEach((element, index) => {
            if (spvi >= element.min && spvi <= element.max) {
                flagCost = 1;
                cost = (spvi * BandArray[index]);
                //break;
            }
        });
        // foreach($InstallerSlot as $slots_key=>$slots)
        // {
        // 	if(spvi>=$slots['min'] && spvi<=$slots['max'])
        // 	{
        // 		flagCost 	= 1;
        // 		cost	=	(spvi* BandArray[$slots_key]);
        // 		break;
        // 	}
        // }
        if (flagCost == 0 && spvi >= 0.95 && spvi < 1) {
            cost = (spvi * BandArray[1]);
        }
    } else {
        if (spvi <= 10) {
            cost = (spvi * COST_UPTO_10_KW);
        } else if (spvi > 10 && spvi <= 100) {
            cost = (spvi * COST_FOR_10_TO_100_KW);
        } else if (spvi > 100 && spvi <= 500) {
            cost = (spvi * COST_FOR_100_TO_500_KW);
        } else if (spvi > 500 && spvi <= 1000) {
            cost = (spvi * COST_FOR_500_TO_1000_KW);
        } else if (spvi > 1000 && spvi <= 10000) {
            cost = (spvi * COST_FOR_1000_TO_10000_KW);
        } else {
            cost = (spvi * COST_ABOVE_10000_KW);
        }
    }
    return cost;
}
async function findAllPercentage(scheme_id = '') {

    var activeSchemeId = await findActiveSchemeId();

    var where = "";
    if (scheme_id && scheme_id != "") {
        where = where + " AND scheme_id=" + scheme_id;

    } else {
        where = where + " AND scheme_id IN(" + activeSchemeId + ")";
    }



    var selectQuery = "SELECT * FROM `scheme_subsidy_master` WHERE 1=1 " + where;
    var rsltSingle = await db.query(selectQuery, {
        replacements: {},
        type: db.QueryTypes.SELECT
    });

    if (rsltSingle) {
        var arr = [];
        rsltSingle.forEach((element, index) => {
            // arr[index+1] = element.subsidy_percentage;
            arr.push(element.subsidy_percentage);
        });
        if (arr.length === rsltSingle.length) {
            return arr;
        }

    } else {
        return [];
    }

}
async function viewApplication(applicationId) {

    var selectQuery = "SELECT ApplyOnlines.*, CONCAT(ApplyOnlines.name_of_consumer_applicant, ' ', ApplyOnlines.last_name, ' ', ApplyOnlines.third_name) AS `name_of_consumer_applicant`,  customers.name AS `customers__name`, customers.email AS `customers__email`, installer.installer_name AS `installer_name`, installer.jreda_work_order AS `jreda_work_order`, installer.jreda_nib_no AS `jreda_nib_no`, parameter_cats.para_value AS `para_value`,  apply_onlines_others.jir_unique_code AS `jir_unique_code`, apply_onlines_others.is_enhancement AS `is_enhancement`, apply_onlines_others.existing_capacity AS `existing_capacity`, apply_onlines_others.consumer_connection AS `consumer_connection`, apply_onlines_others.scheme_id AS `scheme_id`, district_master.name AS `district_name`, installer.designation AS `designation`, installer.email AS `email` FROM apply_onlines ApplyOnlines left JOIN installers installer ON installer.id = ApplyOnlines.installer_id left JOIN customers  ON customers.id = ApplyOnlines.customer_id left JOIN parameters parameter_cats ON parameter_cats.para_id = ApplyOnlines.category left JOIN apply_onlines_others apply_onlines_others ON apply_onlines_others.application_id = ApplyOnlines.id left JOIN district_master district_master ON district_master.id = ApplyOnlines.district WHERE ApplyOnlines.id = :id ";
    var rsltSingle = await db.query(selectQuery, {
        replacements: { id: applicationId },
        type: db.QueryTypes.SELECT
    });
    if (rsltSingle) {
        return rsltSingle[0];

    } else {
        return [];
    }

}
async function viewApplicationOthers(applicationId) {

    var selectQuery = "SELECT * FROM apply_onlines_others WHERE application_id = :id ";
    var rsltSingle = await db.query(selectQuery, {
        replacements: { id: applicationId },
        type: db.QueryTypes.SELECT
    });
    if (rsltSingle) {
        return rsltSingle[0];

    } else {
        return [];
    }

}
async function getRate(Capacity, installer_id, scheme_id = '') {
    var rate = 0;
    var InstallerSlot = await findMinMaxSlots(scheme_id);// 
    var BandArray = await findAllRates('', scheme_id);

    if (installer_id == 55 && scheme_id == 1) {
        var SpecialRates = await findAllRates(55, scheme_id);
        BandArray = (SpecialRates && SpecialRates.length > 0) ? SpecialRates : BandArray;
    }
    InstallerSlot.forEach((element, index) => {
        if (Capacity >= element.min && Capacity <= element.max) {
            rate = (BandArray[index + 1]) * 100000;


        }
    });

    if (rate && Capacity >= 0.95 && Capacity < 1) {
        rate = (BandArray[1]) * 100000;

    }

    return rate;
}
async function getSubcidyDataByState(region_id, customer_type = 0, actualCapacity = 0, customer_id = 0, applicationId = 0, solarleads = 0) {

    var offerData = [];

    var where = "";
    if (region_id && region_id != "") {
        where = where + " AND state='" + region_id + "'";

    }
    if (customer_type && customer_type != 0) {
        where = where + " AND customer_type=" + customer_type;

    }

    var selectQuery = "SELECT id FROM `statesubsidy` WHERE 1=1 " + where;
    var offerData = await db.query(selectQuery, {
        replacements: {},
        type: db.QueryTypes.SELECT
    });

    var subsidyData = {};

    // $ApplyOnlines   	= TableRegistry::get('ApplyOnlines');
    // $ApplyOnlinesOthers = TableRegistry::get('ApplyOnlinesOthers');
    // $SolarLeads 		= TableRegistry::get('SolarLeads');

    var InstallerSlot = await findMinMaxSlots();//$ApplyOnlines->installer_slot_array;
    var BandArray = await findAllRates();
    var subsidy_percentage_array = await findAllPercentage();
    var isEnhancement = 0;
    var totalSubsidy = 0;
    var totalSubsidy1 = 0;
    var rate = 0;
    var percentage = 0;
    var percentageCal = 0;
    if (solarleads && solarleads == 1) {

        InstallerSlot && InstallerSlot.forEach((element, index) => {
            if (actualCapacity >= element.min && actualCapacity <= element.max) {
                rate = (BandArray[index]) * 100000;
                percentage = subsidy_percentage_array[index];

            }
        });

        //Needed
        if (rate && percentage && actualCapacity >= 0.95 && actualCapacity < 1) {
            rate = (BandArray[0]) * 100000;
            percentage = subsidy_percentage_array[0];

        }
        percentageCal = subsidy_percentage_array[2];

        if (actualCapacity < 3.001) {
            totalSubsidy = (actualCapacity * rate * percentage) / 100;
        }
        else if (actualCapacity >= 10.001) {
            var addedCost = 0;
            var percentagelast = 20;//isset($this->Subsidy_percentage_array[8]) ? $this->Subsidy_percentage_array[8] : 0;
            totalSubsidy = ((3 * rate * percentageCal) / 100) + ((7 * rate * percentagelast) / 100) + addedCost;
        }
        else if (actualCapacity >= 3.001) {
            percentagelast = 20;//isset($this->Subsidy_percentage_array[8]) ? $this->Subsidy_percentage_array[8] : 0;
            totalSubsidy = ((3 * rate * percentageCal) / 100) + (((actualCapacity - 3) * rate * percentagelast) / 100);
        }

    }
    else if (applicationId && applicationId != 0) {
        var applicatonDetail = await viewApplication(applicationId);
        var appOtherDetails = await viewApplicationOthers(applicationId);


        installer_id = applicatonDetail.installer_id;

        var BandArray = await findAllRates('', appOtherDetails.scheme_id);
        var InstallerSlot = await findMinMaxSlots(appOtherDetails.scheme_id);
        if (installer_id == 55) {
            var SpecialRates = await findAllRates(55, appOtherDetails.scheme_id);
            BandArray = SpecialRates && SpecialRates.length > 0 ? SpecialRates : BandArray;
        }
        if (appOtherDetails.is_enhancement == 1) {
            if (appOtherDetails.existing_capacity && appOtherDetails.existing_capacity && appOtherDetails.existing_capacity.length > 0) {
                isEnhancement = 1;
                Existing = appOtherDetails.existing_capacity;
                Applied = actualCapacity && actualCapacity.length > 0 ? actualCapacity : applicatonDetail.pv_capacity;
                Cumulative = Existing + Applied;
                rate = await getRate(Applied, installer_id, appOtherDetails.scheme_id);

                if (Cumulative < 3) {
                    Capacity = (Cumulative - Existing);
                    percentage = (applicatonDetail.common_meter == 1) ? 20 : 40;

                    totalSubsidy = (Capacity * rate * percentage) / 100;
                }
                else if (Cumulative >= 3) {
                    if (Existing < 3) {
                        Capacity = (3 - Existing);
                        percentage = (applicatonDetail.common_meter == 1) ? 20 : 40;
                        Capacity1 = (Cumulative - 3);
                        percentage1 = 20;
                        totalSubsidy = ((Capacity * rate * percentage) / 100) + ((Capacity1 * rate * percentage1) / 100);
                    }
                    else if (Cumulative >= 10) {
                        if (applicatonDetail.common_meter == 1) {
                            Capacity = (Cumulative > 500) ? (500 - Existing) : (Cumulative - Existing);
                        }
                        else {
                            Capacity = (Existing > 10) ? 0 : (10 - Existing);
                        }
                        percentage = 20;
                        totalSubsidy = ((Capacity * rate * percentage) / 100);
                    }
                    elseif(Existing >= 3)
                    {
                        Capacity = (Cumulative - Existing);
                        percentage = 20;
                        totalSubsidy = ((Capacity * rate * percentage) / 100);
                    }
                }
            }
        }

        if (isEnhancement == 0) {
            InstallerSlot.forEach((element, index) => {
                if (actualCapacity >= element.min && actualCapacity <= element.max) {
                    rate = (BandArray[index + 1]) * 100000;
                    percentage = (applicatonDetail.common_meter == 1 && subsidy_percentage_array[index + 1]) ? 20 : subsidy_percentage_array[index + 1];

                }
            });


            if (rate && percentage && actualCapacity >= 0.95 && actualCapacity < 1) {
                rate = (BandArray[1]) * 100000;
                percentage = (applicatonDetail.common_meter == 1 && subsidy_percentage_array[1] == 40) ? 20 : subsidy_percentage_array[1];
            }
            percentageCal = (applicatonDetail.common_meter == 1 && subsidy_percentage_array[3] == 40) ? 20 : subsidy_percentage_array[3];

            if (actualCapacity < 3.001) {
                totalSubsidy = (actualCapacity * rate * percentage) / 100;
            }
            else if (actualCapacity >= 10.001) {
                var addedCost = 0;
                if (applicatonDetail.common_meter == 1) {
                    var maxCapaxity = (actualCapacity > 500) ? 500 : actualCapacity;
                    addedCost = (((maxCapaxity - 10) * rate * 20) / 100);
                }
                percentagelast = 20;
                totalSubsidy = ((3 * rate * percentageCal) / 100) + ((7 * rate * percentagelast) / 100) + addedCost;
            }
            else if (actualCapacity >= 3.001) {
                percentagelast = 20;//isset($this->Subsidy_percentage_array[8]) ? $this->Subsidy_percentage_array[8] : 0;
                totalSubsidy = ((3 * rate * percentageCal) / 100) + (((actualCapacity - 3) * rate * percentagelast) / 100);
            }
        }
    }


    //actualCapacity*;
    var subsidyData = {
        state_subsidy: 0,
        state_capacity: 0,
        state_subcidy_type: 0,
        state_capital_cost: totalSubsidy,
        state_subsidy_amount: totalSubsidy,
        state_subsidy_per_kw: 0,
        central_subsidy: 0,
        central_capacity: 0,
        central_subcidy_type: 0,
        central_capital_cost: 0,
        central_subsidy_amount: 0,
        central_subsidy_per_kw: 0,
        other_subsidy: 0,
        other_capacity: 0,
        other_subcidy_type: 0,
        other_capital_cost: 0,
        other_subsidy_amount: 0,
        other_subsidy_per_kw: 0,
    }



    return subsidyData;
}
async function calculatecapitalcostwithsubsidy(recommendedSolarPvInstall = '', capitalCost = 0, state = "", customertype = "", RArray = false, social_consumer = 0, customer_id = 0, applicationId = 0) {
    var subsidyData = {};
    var arrResult = {};
    var solarleads = 1;
    customertype = customertype && customertype == '' ? 0 : customertype;
    // $MStateSubsidy 		= TableRegistry::get('StateSubsidy');
    // $MParameter 		= TableRegistry::get('Parameters');
    if (typeof customertype === 'string') {
        //it's a number
        var selectQuery = "SELECT para_id AS keyField, para_value AS valueField  FROM parameters WHERE LOWER(para_value) = :id ";
        var rsltSingle = await db.query(selectQuery, {
            replacements: { id: customertype.toLowerCase() },
            type: db.QueryTypes.SELECT
        });
        //console.log("rsltSingle===>",rsltSingle)
        if (rsltSingle) {
            customertype = rsltSingle[0];


            // if (!empty($returnArr)) {
            //     $para_ids 		= array_keys($returnArr);
            //     $customertype 	= $para_ids[0];
            // }

        } else {
            // return [];
        }
    }
    // if (!ctype_digit($customertype)) {
    // 	$returnArr = $MParameter->GetParaIdByName($customertype);
    // 	if (!empty($returnArr)) {
    // 		$para_ids 		= array_keys($returnArr);
    // 		$customertype 	= $para_ids[0];
    // 	}
    // }
    var state = (state.toLowerCase() == "jarkhand") ? "jharkhand" : state;
    var subsidyData = await getSubcidyDataByState(state.toLowerCase(), customertype, recommendedSolarPvInstall, customer_id, applicationId, solarleads);

    capitalCost = (capitalCost * 100000);
    subsidy = 0;
    StateSubsidy = 0;
    centralsubsidy = 0;
    othersubsidy = 0;
    //if((recommendedSolarPvInstall && recommendedSolarPvInstall.length>0) || (capitalCost && capitalCost.length>0 )) return false;
    if ((recommendedSolarPvInstall === undefined) || (capitalCost === undefined)) return false;
    costwithsubsidy = 0;



    // arrResult['state_subcidy_type'] 	= $subsidyData['state_subcidy_type'];
    // arrResult['state_subsidy'] 		= $subsidyData['state_subsidy'];
    // arrResult['state_subsidy_amount'] 	= $subsidyData['state_subsidy_amount'];
    StateSubsidy = subsidyData.state_subsidy_amount;


    // arrResult['central_subcidy_type'] 		= $subsidyData['central_subcidy_type'];
    // arrResult['central_subsidy'] 			= $subsidyData['central_subsidy'];
    // arrResult['central_subsidy_amount'] 	= $subsidyData['central_subsidy_amount'];


    // arrResult['other_subcidy_type'] 		= $subsidyData['other_subcidy_type'];
    // arrResult['other_subsidy'] 			= $subsidyData['other_subsidy'];
    // arrResult['other_subsidy_amount'] 		= $subsidyData['other_subsidy_amount'];
    var arrResult = {
        state_subcidy_type: subsidyData.state_subcidy_type,
        state_subsidy: subsidyData.state_subsidy,
        state_subsidy_amount: subsidyData.state_subsidy_amount,
        central_subcidy_type: subsidyData.central_subcidy_type,
        central_subsidy: subsidyData.central_subsidy,
        central_subsidy_amount: subsidyData.central_subsidy_amount,
        other_subcidy_type: subsidyData.other_subcidy_type,
        other_subsidy: subsidyData.other_subsidy,
        other_subsidy_amount: subsidyData.other_subsidy_amount,
        total_cost: capitalCost,
        total_subsidy: (StateSubsidy + centralsubsidy + othersubsidy),
    }
    //console.log("capitalCost - (StateSubsidy + centralsubsidy + othersubsidy)==>",capitalCost,StateSubsidy,centralsubsidy,othersubsidy)
    costwithsubsidy = capitalCost - (StateSubsidy + centralsubsidy + othersubsidy);
    // arrResult['total_cost'] 				= capitalCost;
    // arrResult['total_subsidy'] 			= ($StateSubsidy + $centralsubsidy + $othersubsidy);


    recommendedSolarPvInstall = (recommendedSolarPvInstall > 500) ? 500 : recommendedSolarPvInstall;
    if (recommendedSolarPvInstall < 500 && (subsidyData && subsidyData.length > 0)) {

    } else {

    }
    //console.log("arrResult==>",arrResult);
    //console.log("costwithsubsidy==>",costwithsubsidy);

    if (!RArray) {
        return costwithsubsidy;
    } else {
        return arrResult;
    }
}
async function calculateMonthChartData(solarRediationData, solarPvInstall) {
    var allMonths = ['jan', 'feb', 'mar', "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
    var chartDataArr = [];
    if (solarRediationData && solarRediationData.length > 0) {
        allMonths.forEach(async (month, index) => {
            var keyName = "";
            keyName = month + "_glo";

            var monthGloValObj = solarRediationData.filter(solarRediation => solarRediation.key == keyName);
            var monthGloVal = monthGloValObj[0].val || 0;
            var PERFORMANCE_RATIO = 69;
            chartDataArr.push((((((solarPvInstall * monthGloVal) * PERFORMANCE_RATIO) / 100)) * daysInMonth(index + 1, new Date().getFullYear())));

        });
        // for($i=1;$i<=12;$i++) {
        //     $keyName 		= strtolower(date('M', mktime(0, 0, 0, $i, 10)))."_glo";
        //     $monthGloVal 	= (isset($solarRediationData[$keyName])?$solarRediationData[$keyName]:0);
        //     $chartDataArr[$i] = ((((($solarPvInstall*$monthGloVal)*PERFORMANCE_RATIO)/100))*cal_days_in_month(CAL_GREGORIAN, $i, date("Y")));
        // }
    }
    return chartDataArr;
}
async function getLocationByLatLong(lat, lng) {
    // var api_key='AIzaSyD2eOQS5UOkDNZQX6OY0YBcBSsfiErrjh0';
    var api_key = 'AIzaSyBmMZRSWnfJdOw6Y3ZMANFXX2ta6Z9G4pM';
    var url = "https://maps.googleapis.com/maps/api/geocode/json?&key=" + api_key + '&latlng=' + lat + ',' + lng + "&sensor=false";
    var options = {
        'method': 'GET',
        'url': url,
        'headers': {
        }
    };
    var locationObj = {};
    var address_components = [];
    let json = await axios.get(url);
    ////console.log('after the call to service');
    ////console.log("json==>",json.data);
    address_components = json?.data?.results[0]?.address_components;
    var landmark = json?.data?.results[0]?.formatted_address || "";
    var address = "";
    var postal_code = "";
    var city = "";
    var state = "";
    var state_short_name = "";
    var country = "";

    address_components && address_components.forEach(async (addressItem) => {
        if (addressItem.types.indexOf("premise") != -1) {
            address += addressItem?.long_name
        }
        if (addressItem.types.indexOf("street_number") != -1) {
            address += addressItem?.long_name
        }
        if (addressItem.types.indexOf("route") != -1) {
            address += addressItem?.long_name
        }
        if (addressItem.types.indexOf("sublocality_level_1") != -1) {
            address += addressItem?.long_name
        }
        if (addressItem.types.indexOf("postal_code") != -1) {
            postal_code = addressItem?.long_name
        }
        if (addressItem.types.indexOf("locality") != -1) {
            city = addressItem?.long_name
        }
        if (addressItem.types.indexOf("administrative_area_level_1") != -1) {
            state = addressItem?.long_name
            state_short_name = addressItem?.short_name
        }
        if (addressItem.types.indexOf("country") != -1) {
            country = addressItem?.long_name
        }
    });

    locationObj = {
        landmark: landmark,
        address: address,
        postal_code: postal_code,
        city: city,
        state: state,
        state_short_name: state_short_name,
        country: country,
    }
    return locationObj;
    var result = await request(options);
    //console.log("result==>",result);
    return result;
    //   request(options, async function (error, response) {
    //     if (error) throw new Error(error);

    //            // //console.log(response.body);
    //             var data = JSON.parse(response?.body);
    //             ////console.log("data==>",data);

    //             address_components = data?.results[0]?.address_components  ;
    //             var landmark = data?.results[0]?.formatted_address || "" ;
    //             var address =  "" ;
    //             var postal_code =  "" ;
    //             var city =  "" ;
    //             var state =  "" ;
    //             var state_short_name =  "" ;
    //             var country =  "" ;



    //             address_components && address_components.forEach(async (addressItem) => {
    //                 if(addressItem.types.indexOf("premise") != -1){  
    //                     address+=addressItem?.long_name
    //                 }
    //                 if(addressItem.types.indexOf("street_number") != -1){  
    //                     address+=addressItem?.long_name
    //                 }
    //                 if(addressItem.types.indexOf("route") != -1){  
    //                     address+=addressItem?.long_name
    //                 }
    //                 if(addressItem.types.indexOf("sublocality_level_1") != -1){  
    //                     address+=addressItem?.long_name
    //                 }
    //                 if(addressItem.types.indexOf("postal_code") != -1){  
    //                     postal_code=addressItem?.long_name
    //                 }
    //                 if(addressItem.types.indexOf("locality") != -1){  
    //                     city=addressItem?.long_name
    //                 }
    //                 if(addressItem.types.indexOf("administrative_area_level_1") != -1){  
    //                     state=addressItem?.long_name
    //                     state_short_name=addressItem?.short_name
    //                 }
    //                 if(addressItem.types.indexOf("country") != -1){  
    //                     country=addressItem?.long_name
    //                 }
    //               }); 

    //                 locationObj={
    //                 landmark:landmark,
    //                 address:address,
    //                 postal_code:postal_code,
    //                 city:city,
    //                 state:state,
    //                 state_short_name:state_short_name,
    //                 country:country,
    //             }
    //             //console.log("locationObj==>",locationObj);
    //             return locationObj;

    //   });
    //   //console.log("address_components==>",address_components);

    //   if(address_components.length>0){
    //             //console.log("locationObj==>",locationObj);

    //     return locationObj;
    // }


}
async function getApplicationById(req) {

    // var selectQuery="SELECT ApplyOnlines.* FROM apply_onlines ApplyOnlines    WHERE ApplyOnlines.id = (:id)";
    var selectQuery = "SELECT ApplyOnlines.*,  CONCAT(ApplyOnlines.name_of_consumer_applicant, ' ', ApplyOnlines.last_name, ' ', ApplyOnlines.third_name) AS `name_of_consumer_applicant`,  customers.name AS `customers_name`, customers.email AS `customers_email`, installer.installer_name AS `installer_name`, installer.jreda_work_order AS `jreda_work_order`, installer.jreda_nib_no AS `jreda_nib_no`, parameter_cats.para_value AS `para_value`,  apply_onlines_others.jir_unique_code AS `jir_unique_code`, apply_onlines_others.is_enhancement AS `is_enhancement`, apply_onlines_others.existing_capacity AS `existing_capacity`, apply_onlines_others.consumer_connection AS `consumer_connection`, apply_onlines_others.scheme_id AS `scheme_id`, district_master.name AS `district_name`, installer.designation AS `designation`, installer.email AS `installer_email` FROM apply_onlines ApplyOnlines left JOIN installers installer ON installer.id = ApplyOnlines.installer_id left JOIN customers  ON customers.id = ApplyOnlines.customer_id left JOIN parameters parameter_cats ON parameter_cats.para_id = ApplyOnlines.category left JOIN apply_onlines_others apply_onlines_others ON apply_onlines_others.application_id = ApplyOnlines.id left JOIN district_master district_master ON district_master.id = ApplyOnlines.district WHERE ApplyOnlines.id = :id";
    var rsltSingle = await db.query(selectQuery, {
        replacements: { id: projectDetails.applicationId },
        type: db.QueryTypes.SELECT
    });
    if (rsltSingle) {
        return rsltSingle;
    } else {
        return [];
    }



}
function getUploadFile(attachmentsBase64, docType) {
    //console.log("attachmentsBase64",attachmentsBase64);
    var timeStr = new Date().getTime();

    var bin = Base64.atob(attachmentsBase64);
    // Your code to handle binary data
    fs.writeFile('result_binary.pdf', bin, 'binary', error => {
        if (error) {
            throw error;
        } else {
            //console.log('binary saved!');
        }
    });
    // let result = attachmentsBase64.replace("data:application/pdf;base64,", "");

    // const data = Buffer.alloc(result.length, result, 'utf-8');
    // fs.writeFileSync(config.uploadPath+docType+"_"+timeStr+".pdf", result);
    // var bitmap = new Buffer(attachmentsBase64, 'base64');
    // // write buffer to file
    // fs.writeFileSync(file, bitmap);
    // let decodedBase64 = base64.base64Decode(attachmentsBase64,config.uploadPath+docType+"_"+timeStr+".pdf");
    // //console.log("decodedBase64==>",decodedBase64);
    // let result = attachmentsBase64.replace("data:application/pdf;base64,", "");
    // fs.writeFileSync(config.uploadPath+"sample.pdf", attachmentsBase64, 'base64', function(err) {
    //     //console.log(err);
    //   });

    //   //console.log("PDF Saved Successfully.");
    //module.exports = function(req, res, next) {

    // var storage = multer.diskStorage({
    //     destination: destinationFunction,
    //     filename: fileNameFunction
    // });

    // multer({storage: storage}).single('file')(req, res, function(err) {

    //     if(err) {

    //         return responder.handleInternalError(res, err, next);
    //     }

    //     if(!req.file) {
    //         return responder.bad(res, {
    //             errors: [{
    //                 msg: translation.translate(req, 'common.validation.file_required'),
    //                 code: 'common.validation.file_required',
    //                 param: 'file'
    //             }]
    //         });
    //     }
    //     return req.file.filename;
    // var promiseSmall = sharp(req.file.path).resize(config.logoSizes.small.w, config.logoSizes.small.h).max().toFile(path.join(req.file.destination, req.file.filenameSmall));
    // var promiseMedium = sharp(req.file.path).resize(config.logoSizes.medium.w, config.logoSizes.medium.h).max().toFile(path.join(req.file.destination, req.file.filenameMedium));
    // var promiseLarge = sharp(req.file.path).resize(config.logoSizes.large.w, config.logoSizes.large.h).max().toFile(path.join(req.file.destination, req.file.filenameLarge));

    // Promise.all([promiseSmall, promiseMedium, promiseLarge]).then(function() {

    //     return responder.success(res, {
    //         item: {
    //             logo: {
    //                 default: req.file.filename,
    //                 small: req.file.filenameSmall,
    //                 medium: req.file.filenameMedium,
    //                 large: req.file.filenameLarge
    //             }
    //         }
    //     });
    // });
    //});
};

function destinationFunction(req, file, cb) {
    // var uploadPath = utility.getUploadPath(req);
    var uploadPath = config.uploadPath;
    if (uploadPath) {

        cb(null, path.join(uploadPath, ''))
    } else {

        cb(new Error('This server is not configured for photo upload yet.'));
    }
}

function fileNameFunction(req, file, cb) {
    var parts = file.originalname.split('.');
    var ext = 'png';
    if (parts.length > 1) {
        ext = parts.slice(parts.length - 1)
    }

    var originalname = parts.slice(0, parts.length - 1).join('.');
    var baseName = [originalname, req.user._id, Date.now()].join('_');
    file.filenameSmall = [[baseName, 'small'].join('_'), ext].join('.');
    file.filenameMedium = [[baseName, 'medium'].join('_'), ext].join('.');
    file.filenameLarge = [[baseName, 'large'].join('_'), ext].join('.');

    cb(null, [baseName, ext].join('.'));
}


// solar calculator update capacity calculatiobn logic

async function updateSolarCalcCapacity(details, pv_capacity, totalSubsidy, state_subsidy, central_subsidy) {
    const consumer_no = details.consumer_no ? details.consumer_no : "";
    const area = details.area ? details.area : "";
    const discom_id = details.discom_id ? details.discom_id : "";
    const billing_cycle = details.billing_cycle ? details.billing_cycle : "";
    const avg_monthly_bill = details.avg_monthly_bill ? details.avg_monthly_bill : "";
    const avg_consumption = details.avg_consumption ? details.avg_consumption : "";
    const mobile = details.mobile ? details.mobile : "";
    const email = details.email ? details.email : "";
    var pv_capacity = pv_capacity;

    // const t_no=req.body.t_no ? req.body.t_no : 0;
    // const lead_id=req.body.lead_id ? req.body.lead_id :0;


    // ==================================main calculation logic for the solar calculator====================================

    // variables for the calculation
    var solarPenalArea = 0;

    ////console.log("solarPenalArea==>",solarPenalArea);
    var load_fectore = 30;
    var applicationId = ""
    var longitude = 72;
    var latitude = 23;
    var PERFORMANCE_RATIO = 69;
    var area_type = 2001;
    //Dats used for the calculations are here :-
    var solarRediationData = await getSolarRediation(
        latitude,
        longitude,
    );

    const solarRediationItem = solarRediationData.filter(
        (solarRediation) => solarRediation.key == "ann_glo"
    );

    var solar_radiation = solarRediationItem[0]?.val * 365;
    var annualTotalRad = solarRediationItem[0]?.val * 365;

    //console.log(solarRediationItem)

    //For solarPvInstall

    if (area_type == 2001) {
        solarPenalArea = await calculatePvInFoot(area);
    } else if (area_type == 2002) {
        solarPenalArea = await calculatePvInMeter(area);
    }


    var solarPvInstall = Math.ceil(solarPenalArea / 12);

    //For contractLoad
    var contractLoad = Math.round((Number(avg_consumption) * 12) / ((24 * 365 * load_fectore) / 100));


    //FOR var capacityAcualEnrgyCon
    var capacityAcualEnrgyCon = Math.round((Number(avg_consumption) * 12) / solar_radiation);

    //This function will calculate recommended solarPVInstall
    // var recommendedSolarPvInstall = Math.min(
    //     solarPvInstall,
    //     contractLoad,
    //     capacityAcualEnrgyCon
    // );

    var recommendedSolarPvInstall = pv_capacity

    // Calculate averageEnrgyGenInYear based on mergedResponse values
    const averageEnrgyGenInYear = Math.round(
        (recommendedSolarPvInstall * annualTotalRad * PERFORMANCE_RATIO) / 100);
    var avg_generate = averageEnrgyGenInYear;

    // ===================================estimated_cost=================================
    //get state
    var locationdata = await getLocationByLatLong(
        latitude,
        longitude
    );
    var state = locationdata?.state || "Gujarat";
    // var customer_type = 3001;// Static Residential selected as per application logic
    // var customer_id = 0;
    // var scheme_id = 1;
    // estimated_cost = capitalCost;

    // get capital cost
    // var capitalCost = await calculatecapitalcost(
    //     recommendedSolarPvInstall,
    //     state,
    //     customer_type,
    //     customer_id,
    //     scheme_id
    // );
    // var estimated_cost = capitalCost;

    // var calculate_subsidy = capitalCost;


    var estimated_cost = totalSubsidy;

    var calculate_subsidy = totalSubsidy;

    // ===================================payback================================
    var unitRate = 0;
    if (avg_monthly_bill && Number(avg_consumption)) {
        unitRate = avg_monthly_bill / Number(avg_consumption) - 0.5;
    }
    var maximum_capacity = Math.max(
        solarPvInstall,
        contractLoad,
        capacityAcualEnrgyCon
    );

    // var capitalCostsubsidy = await calculatecapitalcostwithsubsidy(
    //     recommendedSolarPvInstall,
    //     calculate_subsidy,
    //     state,
    //     customer_type,
    //     false,
    //     0,
    //     customer_id,
    //     applicationId
    // );
    ////console.log("capitalCostsubsidy==>",capitalCostsubsidy);


    // var estimated_cost_subsidy = capitalCostsubsidy;  //True
    var backup_type = 0;
    var usage_hours = 0;
    var cost_electricty = 0;


    var solarChart = await getBillingChart(
        contractLoad,
        unitRate,
        averageEnrgyGenInYear,
        totalSubsidy / 100000,
        backup_type,
        usage_hours
    );
    // //console.log("solarChart==>", solarChart);
    var payBack = solarChart.breakEvenPeriod ? solarChart.breakEvenPeriod : 0;  //This is coming undefined!


    // //console.log("averageEnrgyGenInYear==>", averageEnrgyGenInYear);

    const mergedResponse = {
        id: details.id,
        payback: payBack,
        estimated_cost_subsidy: totalSubsidy,
        avg_gen: avg_generate,
        estimated_cost: estimated_cost,
        cost: estimated_cost, //This will be same as estimated_cost
        pv_capacity: pv_capacity,
        maximum_capacity: maximum_capacity,
        min_capacity: 1,
        state_subsidy,
        central_subsidy,
        totalSubsidy
    };
    return [mergedResponse]; // Return as an array containing a single object
}

// create function for the reduce capacity calculation 
async function updateDataAfterReduceCapacity(projectDetails, userId) {
    try {
        //console.log(projectDetails)
        var name = projectDetails.name || "";
        var energy_con = parseFloat(projectDetails.energy_consumed) || 0;
        var area_type = projectDetails.area_type || 0;
        var area = projectDetails.area || 0;
        var latitude = parseFloat(projectDetails.latitude) || 0;
        var longitude = parseFloat(projectDetails.longitude) || 0;
        var avg_monthly_bill = parseFloat(projectDetails.avg_monthly_bill) || 0;
        var backup_type = projectDetails.backup_type || 0;
        var usage_hours = projectDetails.usage_hours || 0;
        var project_type = projectDetails.project_type || 0;
        var landmark = projectDetails.landmark || "";
        var project_social_consumer = projectDetails.project_social_consumer || "0";
        var project_common_meter = projectDetails.project_common_meter || "0";
        var project_disclaimer_subsidy =
            projectDetails.project_disclaimer_subsidy || "0";
        var project_renewable_attr = projectDetails.project_renewable_attr
            ? projectDetails.project_renewable_attr === "0" ||
                projectDetails.project_renewable_attr === "1"
                ? projectDetails.project_renewable_attr
                : "NULL"
            : "Null";
        var project_renewable_rec = projectDetails.project_renewable_rec
            ? projectDetails.project_renewable_attr === "1"
                ? "NULL"
                : projectDetails.project_renewable_rec === "0"
                    ? projectDetails.project_renewable_rec
                    : "NULL"
            : "NULL";

        var is_member = projectDetails.is_member || false;
        var customer_id = userId || false;

        var solarPenalArea = 0;
        var monthly_saving = 0;
        if (area_type == 2001) {
            solarPenalArea = await calculatePvInFoot(area);
        } else if (area_type == 2002) {
            solarPenalArea = await calculatePvInMeter(area);
        }
        ////console.log("solarPenalArea==>",solarPenalArea);
        var state = "Gujarat"; //(isset($requestData['Projects']['state'])?$requestData['Projects']['state']:"");
        var userlat = projectDetails.latitude || 0;
        var userlong = projectDetails.longitude || 0;
        var state = projectDetails.state;
        var customer_type = projectDetails.customer_type;
        /** get location information */
        if (
            projectDetails.address ||
            projectDetails.address === undefined ||
            projectDetails.address === ""
        ) {
            var locationdata = await getLocationByLatLong(
                latitude,
                longitude
            );
            ////console.log("locationdata==>",locationdata);
            var loc = locationdata;
            var address = locationdata?.address || "";
            var city = locationdata?.city || "";
            var state = locationdata?.state || "Gujarat";
            var state_short_name = locationdata?.state_short_name || "GJ";
            var country = locationdata?.country || "";
            var pincode = locationdata?.postal_code || "0";
            var landmark = locationdata?.landmark || "";
        }
        var solarPvInstall = Math.ceil(solarPenalArea / 12);
        var solarRediationData = await getSolarRediation(
            projectDetails.latitude,
            projectDetails.longitude
        );
        //	//console.log("solarRediationData==>",solarRediationData);
        const solarRediationItem = solarRediationData.filter(
            (solarRediation) => solarRediation.key == "ann_glo"
        );
        //	//console.log("solarRediationItem==>",solarRediationItem);

        var solar_radiation = solarRediationItem[0]?.val * 365;
        var annualTotalRad = solarRediationItem[0]?.val * 365;

        var load_fectore = 30;
        var contractLoad = Math.round(
            (energy_con * 12) / ((24 * 365 * load_fectore) / 100)
        );
        var capacityAcualEnrgyCon = Math.round(
            (energy_con * 12) / solar_radiation
        );
        // var recommendedSolarPvInstall = Math.min(
        //     solarPvInstall,
        //     contractLoad,
        //     capacityAcualEnrgyCon
        // );
        var maximum_capacity = Math.max(
            solarPvInstall,
            contractLoad,
            capacityAcualEnrgyCon
        );
        var recommended_capacity = projectDetails.capacity_kw; // continue to here
        var capacity_kw = projectDetails.capacity_kw;
        var original_capacity = projectDetails.capacity_kw;
        var PERFORMANCE_RATIO = 69;
        var averageEnrgyGenInDay =
            (capacity_kw *
                solarRediationItem[0]?.val *
                PERFORMANCE_RATIO) /
            100;
        var monthChartDataArr = await calculateMonthChartData(
            solarRediationData,
            capacity_kw
        );

        var applicationId = "";
        var scheme_id = "";
        ////console.log("capacity_kw==>",capacity_kw);
        var capitalCost = await calculatecapitalcost(
            capacity_kw,
            state,
            customer_type,
            customer_id,
            scheme_id
        );
        var estimated_cost = capitalCost;
        var calculate_subsidy = capitalCost;

        var capitalCostsubsidy = await calculatecapitalcostwithsubsidy(
            capacity_kw,
            calculate_subsidy,
            state,
            customer_type,
            false,
            0,
            customer_id,
            applicationId
        );
        ////console.log("capitalCostsubsidy==>",capitalCostsubsidy);

        var estimated_cost_subsidy = capitalCostsubsidy;
        //	//console.log("estimated_cost_subsidy==>",estimated_cost_subsidy);
        var highRecommendedSolarPvInstall = Math.max(
            solarPvInstall,
            contractLoad,
            capacityAcualEnrgyCon
        );
        var averageEnrgyGenInYear = Math.round(
            (capacity_kw * annualTotalRad * PERFORMANCE_RATIO) / 100
        );
        // //console.log("averageEnrgyGenInYear==>", averageEnrgyGenInYear);

        /* Calculate saving */
        var montly_pv_generation = averageEnrgyGenInDay * 30;
        var monthly_saving = 0;
        if (energy_con && avg_monthly_bill && avg_monthly_bill.length) {
            monthly_saving =
                avg_monthly_bill -
                (energy_con - montly_pv_generation) *
                (avg_month_bill / energy_con - 0.5);
        }

        /* Calculate saving */
        var cost_solar = 0.0;
        var unitRate = 0;
        if (avg_monthly_bill && energy_con) {
            unitRate = avg_monthly_bill / energy_con - 0.5;
        }

        var solarChart = await getBillingChart(
            contractLoad,
            unitRate,
            averageEnrgyGenInYear,
            capitalCostsubsidy / 100000,
            backup_type,
            usage_hours
        );
        //	//console.log("solarChart==>",solarChart);
        var payBack = solarChart.breakEvenPeriod ? solarChart.breakEvenPeriod : 0;
        //$requestData['Projects']['payback'] = $payBack;
        var fromPvSystem = solarChart.fromPvSystem ? solarChart.fromPvSystem : [];
        var gross_solar_cost = await getTarifCalculation(
            25,
            fromPvSystem[1].yearlyEnergyGenerated,
            avg_monthly_bill,
            capitalCost
        );

        //	//console.log("gross_solar_cost==>",gross_solar_cost);

        cost_solar = gross_solar_cost["net_cog"];

        estimated_cost = capitalCost;

        //cost_solar		= cost_solar;
        var avg_generate = averageEnrgyGenInYear;
        //	//console.log("averageEnrgyGenInYear==>",averageEnrgyGenInYear);
        //	//console.log("avg_generate==>",avg_generate);
        var estimated_kwh_year = energy_con;
        ////console.log("estimated_kwh_year==>",estimated_kwh_year);

        ////console.log("fromPvSystem==>",fromPvSystem);
        //	//console.log("monthChartDataArr==>",monthChartDataArr);

        var chart = await genrateApiChartData(
            fromPvSystem,
            monthChartDataArr
        );
        ////console.log("chart==>",chart);

        var averageEnrgyGenInMonth = averageEnrgyGenInYear / 12;
        var payBackGraphData = await GetPaybackChartData(
            Math.round(capitalCostsubsidy / 100000, 2),
            monthly_saving * 12
        );

        //	//console.log("payBackGraphData==>",payBackGraphData);
        var solar_ratio =
            energy_con > 0 ? (averageEnrgyGenInMonth / energy_con) * 100 : 0;
        //$savingChartArr2		= array();
        var savingChartArr = [];
        var paybackStr = "";
        if (payBackGraphData && payBackGraphData.length > 0) {
            payBackGraphData.forEach((element, index) => {
                var key = index + 1;
                savingChartArr.push({
                    x: key,
                    y: Math.round(element),
                });
            });
            paybackStr = JSON.stringify(savingChartArr);
            // paybackStr="";
            // foreach ($payBackGraphData as $key => $value) {
            // 	$savingChartArr[] 		= "{'x':".$key.",'y':".round($value)."}";
            // }
        }
        ////console.log("payBackGraphData11==>",payBackGraphData);

        const data = {
            payback: payBack,
            solar_radiation: solar_radiation,
            estimated_cost: estimated_cost,
            estimated_cost_subsidy: estimated_cost_subsidy,
            estimated_kwh_year: estimated_kwh_year,
            maximum_capacity: maximum_capacity,
            avg_generate: avg_generate,
            cost_solar: cost_solar,
            solar_ratio: solar_ratio,
        }
        return data;
    }
    catch (error) {
        throw error;
    }
}

async function extractRegistrationCode(str) {
    const match = str.match(/\/(Reg-\d+)\/\d{4}/);
    return match ? match[1] : null;
}

// Lead ID generated common function
async function GenerateLeadIDNo() {
    var StateCode = await GetStateCode("", "");
    //var   = "RES";

    var financialyear = await GetGenerateFinancialYear();
    var lead_id = 0;
    var selectQuery = "SELECT id FROM solar_leads ORDER BY id DESC LIMIT 1";
    var rsltSingle = await db.query(selectQuery, {
        replacements: {},
        type: db.QueryTypes.SELECT
    });
    if (rsltSingle && rsltSingle.length > 0) {
        lead_id = rsltSingle[0].id + 1;
    } else {
        lead_id = 1;
    }
    var lead_source = 'SC'
    var lead_id_str = await generateApplicationString(lead_id + "", 7);
    var id = StateCode + "/" + lead_source + "/" + financialyear + "/1" + lead_id_str;
    return id;
}


// get application from the third party API's and other functions
async function createApplication3rd(data1) {
    const procedureForApplicationCreate = "CreateApplication";
    try {
        const rsltProjectSingle = await db.query(
            `CALL ${procedureForApplicationCreate}(
                '${data1.customer_name || ''}',
                ${parseFloat(data1.latitude) || 0},
                ${parseFloat(data1.longitude) || 0},
                ${parseFloat(data1.area) || 0.0},
                ${parseInt(data1.area_type) || 0},
                ${parseInt(data1.backup_type) || 0},
                ${parseFloat(data1.avg_monthly_bill) || 0.0},
                ${parseFloat(data1.backup_usage_hours) || 0.0},
                ${parseInt(data1.customer_type) || 0},
                '${data1.landmark || ''}',
                '${data1.project_social_consumer || ''}',
                '${data1.project_common_meter || ''}',
                '${data1.project_disclaimer_subsidy || ''}',
                '${data1.address || ''}',
                '${data1.city || ''}',
                '${data1.state || ''}',
                '${data1.state_short_name || ''}',
                '${data1.country || ''}',
                ${parseInt(data1.pincode || 0)},
                '${data1.solar_radiation || ''}',
                ${parseFloat(data1.maximum_capacity || 0)},
                ${parseFloat(data1.recommended_capacity || 0)},
                ${parseFloat(data1.capacity_kw || 0)},
                ${parseFloat(data1.original_capacity || 0)},
                ${parseFloat(data1.estimated_cost || 0)},
                ${data1.estimated_cost_subsidy || 0},
                '${data1.paybackStr || ''}',
                ${parseFloat(data1.cost_solar || 0)},
                ${parseFloat(data1.avg_generate || 0)},
                ${parseFloat(data1.estimated_kwh_year || 0)},
                ${data1.customer_id || 0},
                '${data1.application_no || ''}',
                '${data1.project_type || ''}'
            )`,
            {
                type: db.QueryTypes.RAW,
            }
        );
        console.log("Result from CreateApplication:", rsltProjectSingle);
        return rsltProjectSingle;
    } catch (error) {
        console.error("Error in CreateApplication:", error);
        throw error;
    }
}


// Update application from the third party API's and other functions
async function updateApplication3rd(data2) {
    const procedureForUpdateApplication = 'UpdateApplication';
    try {
        const response = await db.query(
            `CALL ${procedureForUpdateApplication}(
                ${data2.applicationID},
                '${data2.customer_type}',
                '${data2.division}',
                '${data2.area}',
                '${data2.circle}',
                '${data2.section}',
                '${data2.disclaimer}',
                '${data2.customer_name_prefixed}',
                '${data2.name_of_consumer_applicant}',
                '${data2.last_name}',
                '${data2.third_name}',
                '${data2.customer_name}',
                '${data2.con_address}',
                '${data2.address2}',
                '${data2.district}',
                '${data2.con_city}',
                '${data2.con_state}',
                '${data2.mobile}',
                '${data2.whatsapp}',
                '${data2.email}',
                '${data2.discom_name}',
                '${data2.discom}',
                '${data2.consumer_no}',
                '${data2.aadhar_no_or_pan_card_no}',
                '${data2.attach_photo_scan_of_aadhar}',
                '${data2.pan_card_no}',
                '${data2.attach_pan_card_scan}',
                '${data2.apply_state}',
                '${data2.attach_detail_project_report}',
                '${data2.sanction_load_contract_demand}',
                '${data2.category}',
                '${data2.attach_recent_bill}',
                '${data2.house_tax_holding_no}',
                '${data2.attach_latest_receipt}',
                '${data2.acknowledgement_tax_pay}',
                '${data2.pv_capacity}',
                '${data2.original_capacity}',
                '${data2.energy_con}',
                '${data2.bill}',
                '${data2.latitude}',
                '${data2.longitude}',
                '${data2.roof_of_proposed}',
                '${data2.tod_billing_system}',
                '${data2.avail_accelerated_depreciation_benefits}',
                '${data2.bank_ac_no}',
                '${data2.bank_name}',
                '${data2.ifsc_code}',
                '${data2.ac_holder_name}',
                '${data2.payment_gateway}',
                '${data2.disCom_application_fee}',
                '${data2.jreda_processing_fee}',
                '${data2.member_assign_id}',
                '${data2.application_status}',
                '${data2.payment_status}',
                '${data2.payumoney_id}',
                '${data2.project_id}',
                '${data2.social_consumer}',
                '${data2.common_meter}',
                '${data2.govt_agency}',
                '${data2.payment_mode}',
                '${data2.con_email}',
                '${data2.con_mobile}',
                '${data2.installer_email}',
                '${data2.installer_mobile}',
                '${data2.transmission_line}',
                '${data2.tod_billing}',
                '${data2.application_no}',
                '${data2.otp}',
                '${data2.otp_created_date}',
                '${data2.geda_application_no}',
                '${data2.tno}',
                '${data2.gstno}',
                '${data2.net_meter}',
                '${data2.net_meter_type}',
                '${data2.capexmode}',
                '${data2.disclaimer_subsidy}',
                '${data2.same_as_consumer_no}',
                '${data2.documentsXML}',
                '${data2.subsidy}',
                '${data2.consumerNumberXML}',
                '${data2.userID}',
                '${data2.con_fullname}',
                '${data2.con_pincode}',
                '${data2.undertaking}',
                '${data2.undertaking_details}',
                '${data2.types_of_project}',
                '${data2.types_solar}',
                '${data2.project_mode}',
                '${data2.sub_division}',
                '${data2.supplier_phase}',
                '${data2.con_meter_no}',
                '${data2.lead_reference}',
                '${data2.existing_capacity}',
                '${data2.is_enhancement}'
            )`,
            {
                type: db.QueryTypes.RAW,
            }
        );

        // const response = await db.query(
        //     `CALL ${procedureForUpdateApplication}(:applicationID, :customer_type, :division, :area, :circle, :section, :disclaimer, :customer_name_prefixed, :name_of_consumer_applicant, :last_name, :third_name, :customer_name, :con_address, :address2, :district, :con_city, :con_state, :mobile, :whatsapp, :email, :discom_name, :discom, :consumer_no, :aadhar_no_or_pan_card_no, :attach_photo_scan_of_aadhar, :pan_card_no, :attach_pan_card_scan, :apply_state, :attach_detail_project_report, :sanction_load_contract_demand, :category, :attach_recent_bill, :house_tax_holding_no, :attach_latest_receipt, :acknowledgement_tax_pay, :pv_capacity, :original_capacity, :energy_con, :bill, :lattitue, :longitude, :roof_of_proposed, :tod_billing_system, :avail_accelerated_depreciation_benefits, :bank_ac_no, :bank_name, :ifsc_code, :ac_holder_name, :payment_gateway, :disCom_application_fee, :jreda_processing_fee, :member_assign_id, :application_status, :payment_status, :payumoney_id, :project_id, :social_consumer, :common_meter, :govt_agency, :payment_mode, :con_email, :con_mobile, :installer_email, :installer_mobile, :transmission_line, :tod_billing, :application_no, :otp, :otp_created_date, :geda_application_no, :tno, :gstno, :net_meter, :net_meter_type, :capexmode, :disclaimer_subsidy, :same_as_consumer_no, :documentsXML,:subsidy,:consumerNumberXML, :userID,:con_fullname,:con_pincode, :undertaking, :undertaking_details, :types_of_project, :types_solar, :project_mode, :sub_division,:supplier_phase)`,
        //     {
        //         replacements: {
        //             applicationID:data2.applicationID,
        //             customer_type:data2.customer_type,
        //             division:data2.division,
        //             area:data2.area,
        //             circle:data2.circle,
        //             section:data2.section,
        //             disclaimer:data2.disclaimer,
        //             customer_name_prefixed:data2.customer_name_prefixed,
        //             name_of_consumer_applicant:data2.name_of_consumer_applicant,
        //             last_name:data2.last_name,
        //             third_name:data2.third_name,
        //             customer_name:data2.customer_name,
        //             con_address:data2.con_address,
        //             address2:data2.address2,
        //             district:data2.district,
        //             con_city:data2.con_city,
        //             con_state:data2.con_state,
        //             mobile:data2.mobile,
        //             whatsapp:data2.whatsapp,
        //             email:data2.email,
        //             discom_name:data2.discom_name,
        //             discom:data2.discom,
        //             consumer_no:data2.consumer_no,
        //             aadhar_no_or_pan_card_no:data2.aadhar_no_or_pan_card_no,
        //             attach_photo_scan_of_aadhar:data2.attach_photo_scan_of_aadhar,
        //             pan_card_no:data2.pan_card_no,
        //             attach_pan_card_scan:data2.attach_pan_card_scan,
        //             apply_state:data2.apply_state,
        //             attach_detail_project_report:data2.attach_detail_project_report,
        //             sanction_load_contract_demand:data2.sanction_load_contract_demand,
        //             category:data2.category,
        //             attach_recent_bill:data2.attach_recent_bill,
        //             house_tax_holding_no:data2.house_tax_holding_no,
        //             attach_latest_receipt:data2.attach_latest_receipt,
        //             acknowledgement_tax_pay:data2.acknowledgement_tax_pay,
        //             pv_capacity:data2.pv_capacity,
        //             original_capacity:data2.original_capacity,
        //             energy_con:data2.energy_con,
        //             bill:data2.bill,
        //             lattitue:data2.latitude,
        //             longitude:data2.longitude,
        //             roof_of_proposed:data2.roof_of_proposed,
        //             tod_billing_system:data2.tod_billing_system,
        //             avail_accelerated_depreciation_benefits:data2.avail_accelerated_depreciation_benefits,
        //             bank_ac_no:data2.bank_ac_no,
        //             bank_name:data2.bank_name,
        //             ifsc_code:data2.ifsc_code,
        //             ac_holder_name:data2.ac_holder_name,
        //             payment_gateway:data2.payment_gateway,
        //             disCom_application_fee:data2.disCom_application_fee,
        //             jreda_processing_fee:data2.jreda_processing_fee,
        //             member_assign_id:data2.member_assign_id,
        //             application_status:data2.application_status,
        //             payment_status:data2.payment_status,
        //             payumoney_id:data2.payumoney_id,
        //             project_id:data2.project_id,
        //             social_consumer:data2.social_consumer,
        //             common_meter:data2.common_meter,
        //             govt_agency:data2.govt_agency,
        //             payment_mode:data2.payment_mode,
        //             con_email:data2.con_email,
        //             con_mobile:data2.con_mobile,
        //             installer_email:data2.installer_email,
        //             installer_mobile:data2.installer_mobile,
        //             transmission_line:data2.transmission_line,
        //             tod_billing:data2.tod_billing,
        //             application_no:data2.application_no,
        //             otp:data2.otp,
        //             otp_created_date:data2.otp_created_date,
        //             geda_application_no:data2.geda_application_no,
        //             tno:data2.tno,
        //             gstno:data2.gstno,
        //             net_meter:data2.net_meter,
        //             net_meter_type:data2.net_meter_type,
        //             capexmode:data2.capexmode,
        //             disclaimer_subsidy:data2.disclaimer_subsidy,
        //             same_as_consumer_no:data2.same_as_consumer_no,
        //             documentsXML:data2.documentsXML,
        //             subsidy:data2.subsidy,
        //             consumerNumberXML:data2.consumerNumberXML,
        //             userID:data2.userID,
        //             con_fullname:data2.con_fullname,
        //             con_pincode:data2.con_pincode,
        //             undertaking:data2.undertaking,
        //             undertaking_details:data2.undertaking_details,
        //             types_of_project:data2.types_of_project,
        //             types_solar:data2.types_solar,
        //             project_mode:data2.project_mode,
        //             sub_division:data2.sub_division,
        //             supplier_phase:data2.supplier_phase
        //         },
        //         type: db.QueryTypes.RAW,
        //     }
        // );
        console.log("Result from UpdateApplication:", response);
        return response;
    } catch (error) {
        console.error("Error in UpdateApplication:", error);
        throw error;
    }
}
// Function to convert date format
function convertDateFormat(dateString) {
    // Split the date and time parts
    const [datePart, timePart] = dateString.split(' ');

    // Split the date part into day, month, and year
    const [day, month, year] = datePart.split('-');

    // Reformat to 'YYYY-MM-DD' and append the time part
    const formattedDate = `${year}-${month}-${day} ${timePart}`;

    return formattedDate;
}


// masking data common function for the mobile number and email
// Function to mask sensitive data
async function maskSensitiveData(data) {
    const maskedData = { ...data };

    // Mask telephone number
    if (maskedData.Tel1_Number) {
        maskedData.Tel1_Number = maskTelephoneNumber(maskedData.Tel1_Number);
    }
    // Mask email address (if exists in the data)
    if (maskedData.E_Mail) {
        maskedData.E_Mail = maskEmailAddress(maskedData.E_Mail);
    }
    if(maskedData.searchType=="solar"){

    
    if (maskedData.House_Number) {
        maskedData.House_Number = maskAddress(maskedData.House_Number);
    }
    if (maskedData.Street) {
        maskedData.Street = maskAddress(maskedData.Street);
    }
    if (maskedData.Street2) {
        maskedData.Street2 = maskAddress(maskedData.Street2);
    }
    if (maskedData.Street3) {
        maskedData.Street3 = maskAddress(maskedData.Street3);
    }
    if (maskedData.Street4) {
        maskedData.Street4 = maskAddress(maskedData.Street4);
    }
    if (maskedData.WERT1) {
        maskedData.WERT1 = maskSanction(maskedData.WERT1);
    }
}
    return maskedData;
}



function maskAddress(str) {
    if (str && str.length > 2) {
        return '*'.repeat(str.length - 2) + str.slice(-2);
    } else if (str) {
        return str; // if the string is 2 characters or less, return it as is
    } else {
        return '';
    }
}


function maskSanction(str) {
    if (str && str.length > 0) {
        return '*'.repeat(4);
    } else if (str) {
        return str; 
    } else {
        return '';
    }
}


// Helper function to mask telephone number
function maskTelephoneNumber(number) {
    if (number.length > 4) {
        return number.slice(0, -4).replace(/\d/g, '*') + number.slice(-4);
    }
    return number.replace(/\d/g, '*');
}

// Helper function to mask email address
function maskEmailAddress(email) {
    const [localPart, domain] = email.split('@');
    const maskedLocalPart = localPart.length > 2
        ? localPart.slice(0, 2) + '*'.repeat(localPart.length - 2)
        : '*'.repeat(localPart.length);
    return maskedLocalPart + '@' + domain;
}

// captcha common functions

async function generateCaptcha() {
	const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	let captcha = '';
	for (let i = 0; i < 6; i++) {
		captcha += chars.charAt(Math.floor(Math.random() * chars.length));
	}
	return captcha;
}

// Function to convert text to image URL
//async function textToDataURL(text) {

//	//const canvas = document.createElement('canvas');
//	 const canvas = createCanvas(200,40);
//	const ctx = canvas.getContext('2d');
//	canvas.width = 200; // Adjust width as per your requirement
//	canvas.height = 40; // Adjust height as per your requirement

//	// Draw random dots for background
//	const dotCount = 100; // Adjust number of dots
//	for (let i = 0; i < dotCount; i++) {
//		const x = Math.random() * canvas.width;
//		const y = Math.random() * canvas.height;
//		const radius = Math.random() * 2; // Adjust dot size
//		ctx.beginPath();
//		ctx.arc(x, y, radius, 0, Math.PI * 2);
//		ctx.fillStyle = 'rgba(0, 0, 0, 0.3)'; // Adjust dot color and opacity
//		ctx.fill();
//	}

//	// Draw text
//	ctx.font = 'bold 24px Arial'; // Adjust font size and family
//	ctx.fillStyle = 'black'; // Adjust text color
//	ctx.textAlign = 'center';
//	ctx.textBaseline = 'middle';
//	ctx.fillText(text, canvas.width / 2, canvas.height / 2);

//	// Draw a random line
//	const lineCount = 4; // Adjust number of dots
//	for (let i = 0; i < lineCount; i++) {
//		ctx.beginPath();
//		ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
//		ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
//		ctx.strokeStyle = 'black'; // Adjust line color
//		ctx.stroke();
//	}

//	return canvas.toDataURL('image/png');
//}
async function textToDataURL(text) {
//	const browser = await puppeteer.launch();
const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
	const page = await browser.newPage();
  
	// Define HTML content with CSS to style the text and background
	const htmlContent = `
	  <html>
	  <body style="margin: 0; display: flex; justify-content: center; align-items: center; width: 200px; height: 40px; background: white;">
		<canvas id="canvas" width="200" height="40"></canvas>
		<script>
		  const canvas = document.getElementById('canvas');
		  const ctx = canvas.getContext('2d');
  
		  // Draw random dots for background
		  const dotCount = 100;
		  for (let i = 0; i < dotCount; i++) {
			const x = Math.random() * canvas.width;
			const y = Math.random() * canvas.height;
			const radius = Math.random() * 2;
			ctx.beginPath();
			ctx.arc(x, y, radius, 0, Math.PI * 2);
			ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
			ctx.fill();
		  }
  
		  // Draw text
		  ctx.font = 'bold 24px Arial';
		  ctx.fillStyle = 'black';
		  ctx.textAlign = 'center';
		  ctx.textBaseline = 'middle';
		  ctx.fillText('${text}', canvas.width / 2, canvas.height / 2);
  
		  // Draw random lines
		  const lineCount = 4;
		  for (let i = 0; i < lineCount; i++) {
			ctx.beginPath();
			ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
			ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
			ctx.strokeStyle = 'black';
			ctx.stroke();
		  }
		</script>
	  </body>
	  </html>
	`;
  
	// Set the content of the page
	await page.setContent(htmlContent);
  
	// Capture the screenshot of the canvas element
	const element = await page.$('#canvas');
	const screenshotBuffer = await element.screenshot({ encoding: 'base64' });
  
	await browser.close();
  
	// Return the Data URL
	return `data:image/png;base64,${screenshotBuffer}`;
  }
