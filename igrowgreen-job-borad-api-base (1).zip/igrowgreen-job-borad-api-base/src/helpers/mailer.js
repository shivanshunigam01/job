/**
* File this containts comment logic for send mail.
*/

const nodemailer = require("nodemailer");

// create reusable transporter object using the default SMTP transport
let transporter = nodemailer.createTransport({
	host: process.env.EMAIL_SMTP_HOST,
	port: process.env.EMAIL_SMTP_PORT,
	secure: process.env.EMAIL_SMTP_SECURE, // lack of ssl commented this. You can uncomment it.
	requiredTLS: true,
	auth: {
		user: process.env.EMAIL_SMTP_USERNAME,
		pass: process.env.EMAIL_SMTP_PASSWORD
	}
});  

exports.send = async (from, to, cc, subject, html) => {
    try {
        const info = await transporter.sendMail({
            from,
            to,
            cc,
            subject,
            html
        });
        return info;
    } catch (error) {
        console.error("Error sending email:", error);
        throw error;
    }
};

