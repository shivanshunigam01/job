const Formatter = require("./formatter");
//const ApiClient = require("./api-client"); // Any API Client implementation. Can be axios
const Parser = require("./parser");
const axios = require('axios');
const url = `https://bsesapp1.bsesdelhi.com/DelhiV2/ISUService.asmx`;
// const url = `http://10.8.61.235/DelhiWsv2/ISUService.asmx`;
//http://10.8.61.235/DelhiWsv2/ISUService.asmx?op=ZBI_WEBBILL_HIST
module.exports = class Remote {
  static async multipleTwoOperands(operandA,operandB) {
    try {
      let payload = {
        ZBI_WEBBILL_HIST : {
          CA_NUMBER: operandA

        },
      };

      const headers = {
        headers: {
          "Content-Type": "text/xml; charset=utf-8",
          SOAPAction: "http://tempuri.org/ZBI_WEBBILL_HIST",
        },
       
      };

    // Convert JSON payload to SOAP request format
    let soapRequest = Formatter.convertJsonToSoapRequest(payload);
    console.log("soapRequest",soapRequest)

    // Make the HTTP POST request to the SOAP service
      let response = await axios.post(url, soapRequest, headers);

     // Log the raw SOAP response
     console.log("SOAP Response:", response.data);

    // console.log("remoteResponse==>",remoteResponse.data);
     // Convert the SOAP response XML to JSON
     let jsonResponse = await Parser.convertXMLToJSON(response.data);
    console.log("jsonResponse==>",jsonResponse);

      console.log("remoteResponse1==>",jsonResponse['soap:Body'].ZBI_WEBBILL_HISTResponse.ZBI_WEBBILL_HISTResult['diffgr:diffgram'].BAPI_RESULT.webBillHistoryTable[0]);
    } catch (err) {
        console.log(      
        `Oops something went wrong. Please try again later ${JSON.stringify(
          err
        )}`
      );
    }
  }
};