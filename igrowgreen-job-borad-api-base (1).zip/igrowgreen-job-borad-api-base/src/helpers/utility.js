
const xml2js = require('xml2js');
/**
* File this containts all comment functions.
*/

const mv = require('mv');
const crypto = require('crypto');
const CryptoJS = require('crypto-js');
const fs = require("fs");
const path = require("path");
const ejs = require("ejs");
const mailer = require("../helpers/mailer");
const { emailConst } = require("../helpers/constants");


const config = process.env;


exports.removePrefixes = function (fullname) {
    return fullname.replace(/^(Mr\.|M\/s\.|M\/S|m\/S)\s*/, '');
}

exports.removeExtraQuotes = function (input) {
    return input.replace(/['"]/g, '');
}

/**
 * Function for generate rendom number.
 * @param {number}      length
 * @returns {number}
 */
exports.randomNumber = function (length) {
    var text = "";
    var possible = "123456789";
    for (var i = 0; i < length; i++) {
        var sup = Math.floor(Math.random() * possible.length);
        text += i > 0 && sup == i ? "0" : possible.charAt(sup);
    }
    return Number(text);
};

/**
 * Function for generate token.
 * 
 * @returns {String}
 */
exports.generatePasswordToken = function () {
    var length = 10,
        charset = "@#$&*0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$&*0123456789abcdefghijklmnopqrstuvwxyz",
        password = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
        password += charset.charAt(Math.floor(Math.random() * n));
    }
    return String(password);
}

/**
 * Function for Move file.
 * 
 * @returns {String}
 */
exports.moveFile = function (sourcePath, destinationPath) {
    mv(sourcePath, destinationPath, function (err) {
        if (err) {
            return err;
        }
        else {
            return "";
        }
    });
}

/**
 * Function for get project category name.
 * 
 * @returns {String}
 */
exports.getProjectCategoryName = function (categoryID) {
    let result;
    switch (categoryID) {
        case 1:
            result = "Residential";
            break;
        case 2:
            result = "Industrial";
            break;
        case 3:
            result = "Commercial";
            break;
        case 4:
            result = "Government";
            break;
        case 5:
            result = "OpenSpace";
            break;
        default:
            result = "Residential";
            break;
    }
    return result;
}

/**
 * Function for get project type name.
 * 
 * @returns {String}
 */
exports.getProjectTypeName = function (typeID) {
    let result;
    switch (typeID) {
        case 1:
            result = "FlatRCC";
            break;
        case 2:
            result = "TiltRoof";
            break;
        case 3:
            result = "SheetMetal";
            break;
        case 4:
            result = "Other";
            break;
        default:
            result = "FlatRCC";
            break;
    }
    return result;
}

/**
 * Function for get pagination object.
 * 
 * @returns {Object}
 */
exports.getPagingData = (data, page, limit) => {
    const { count: totalItems, rows: records } = data;
    const currentPage = page ? +page : 0;
    const totalPages = Math.ceil(totalItems / limit);
    return { totalItems, records, totalPages, currentPage };
};

/**
 * Function for get pagination.
 * 
 * @returns {Object}
 */
exports.getPagination = (totalRecords, pageSize, page) => {
    var pageCount = 0;
    var start = 0, currentPage = 1;
    pageCount = Math.ceil(totalRecords / pageSize);
    if (typeof page !== 'undefined') {
        currentPage = page;
    }
    if (currentPage > 1) {
        start = (currentPage - 1) * pageSize;
    }
    return { totalRecords, currentPage, pageSize, pageCount, start };
}

// Function to generate a random encryption key (32 bytes for AES-256)
exports.generateRandomKey = () => {
    return crypto.randomBytes(32);
}

// Function to encrypt JWT token data
// exports.encryptData = (data) => {
// 	// Code goes here
// var keySize = 256;
// var ivSize = 128;
// var iterations = 100;
// 	// const iv = crypto.randomBytes(16);
// 	// const cipher = crypto.createCipher('aes-256-cbc', config.JWT_SECRET, iv);
// 	// let encryptedData = cipher.update(data, 'utf-8', 'hex');
// 	// encryptedData += cipher.final('hex');
// 	// //console.log(encryptedData)
// 	// return encryptedData;
// // 	console("jwt==data===>",data);
// // 	var encrypted = CryptoJS.SHA1(data);
// // //	var encrypted = CryptoJS.AES.encrypt(JSON.stringify(data), config.JWT_SECRET).toString();
// // 	return encrypted;
// var salt = CryptoJS.lib.WordArray.random(128/8);

//   var key = CryptoJS.PBKDF2(pass, salt, {
//       keySize: keySize/32,
//       iterations: iterations
//     });

//   var iv = CryptoJS.lib.WordArray.random(128/8);

//   var encrypted = CryptoJS.AES.encrypt(msg, key, { 
//     iv: iv, 
//     padding: CryptoJS.pad.Pkcs7,
//     mode: CryptoJS.mode.CBC

//   });

//   // salt, iv will be hex 32 in length
//   // append them to the ciphertext for use  in decryption
//   var transitmessage = salt.toString()+ iv.toString() + encrypted.toString();
//   return transitmessage;

// }

// Function to decrypt jwt token data
// exports.decryptData = (encryptedData) => {
// 	var keySize = 256;
// var ivSize = 128;
// var iterations = 100;
// 	// const iv = crypto.randomBytes(16);
// 	// const decipher = crypto.createDecipher('aes-256-cbc', config.JWT_SECRET, iv);
// 	// let decryptedData = decipher.update(encryptedData, 'hex', 'utf-8');
// 	// decryptedData += decipher.final('utf-8');

// 	// return decryptedData;

// 	// var decrypted = CryptoJS.AES.decrypt(encryptedData, config.JWT_SECRET);
// 	// return decrypted;
// 	var salt = CryptoJS.enc.Hex.parse(transitmessage.substr(0, 32));
// 	var iv = CryptoJS.enc.Hex.parse(transitmessage.substr(32, 32))
// 	var encrypted = transitmessage.substring(64);

// 	var key = CryptoJS.PBKDF2(pass, salt, {
// 		keySize: keySize/32,
// 		iterations: iterations
// 	  });

// 	var decrypted = CryptoJS.AES.decrypt(encrypted, key, { 
// 	  iv: iv, 
// 	  padding: CryptoJS.pad.Pkcs7,
// 	  mode: CryptoJS.mode.CBC

// 	})
// 	return decrypted;
// }

// Function to log errors to a file
// exports.logError = (errorMsg) => {
// 	fs.appendFile('error.log', errorMsg + '\n', (err) => {
// 		if (err) {
// 			console.error('Error writing to error log file: ' + err);
// 		}
// 	});
// }

// Function to encrypt JWT token data
exports.encryptData = (data) => {
    const encData = CryptoJS.AES.encrypt(JSON.stringify(data), config.JWT_SECRET).toString();
    return encData;
};

// Function to decrypt jwt token data
exports.decryptData = (encryptedData) => {
    const bytes = CryptoJS.AES.decrypt(encryptedData, config.JWT_SECRET);
    const data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    return data;
};

exports.encryptID = (data) => {
    const encData = btoa(CryptoJS.AES.encrypt(JSON.stringify(data), config.JWT_SECRET).toString());
    return encData;
};

exports.createOtp = () => {
    const otp = Math.floor(10000 + Math.random() * 90000).toString();
    return "12345";
}

// Function to decrypt jwt token data
exports.decryptID = (encryptedData) => {
    const encData = atob(encryptedData);
    const bytes = CryptoJS.AES.decrypt(encData, config.JWT_SECRET);
    const data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    return data;
};
// Function to decrypt password in the login data
exports.decryptPasswordData = async(encryptedData) => {
    const bytes = CryptoJS.AES.decrypt(encryptedData, config.JWT_SECRET);
    const data = bytes.toString(CryptoJS.enc.Utf8);
    return data;
};

/**
 * Function to convert array of objects to XML.
 *
 * @returns {XML String}
 */
exports.convertToXML = (data) => {

    const xmlBuilder = new xml2js.Builder();
    const xmlData = xmlBuilder.buildObject({ data });

    return xmlData;
};



//Function use to encrypt Discom Request data  - Original
exports.aesEncrypt128 = async (toEncrypt, key) => {

    const plaintext = JSON.stringify(toEncrypt);
    const method = 'aes-128-cbc';
    const iv = Buffer.from(key.slice(0, 16));

    const keynew = Buffer.from(key, 'utf8'); // Assuming $key is a string
    const cipher = crypto.createCipheriv(method, key, iv);
    let encrypted = cipher.update(plaintext, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
};

//Function use to decrypt Discom Response data  - Original
exports.aesDecrypt128 = async (str_data, keyPass) => {
    const method = 'aes-128-cbc';
    const key = Buffer.from(keyPass, 'utf8'); // Assuming $key is a string
    const encryptedData = Buffer.from(str_data, 'base64');
    const iv = Buffer.from(keyPass.slice(0, 16));
    const decipher = crypto.createDecipheriv(method, keyPass, iv);

    let decryptedData = decipher.update(encryptedData, 'binary', 'utf8');
    decryptedData += decipher.final('utf8');
    return decryptedData;
};

exports.applicationEmail=async(req) =>{
    try {
        const fileName = req.fileName || '';
        const subject = req.subject || '';
        const data2 = req.data || {};
        const cc = req.cc || '';

        // Ensure that `fileName` is not empty
        if (!fileName) {
            throw new Error("File name is required to send the email.");
        }

        const email = "vandu.rnjn@gmail.com";

        if (fileName === 'ApplicationSubmitted.ejs') {
            console.log("mail sent");
        } else {
            console.log("mail not sent");
        }

        if (fileName === 'WorkExecution.ejs') {
            console.log("mail sent");
        } else {
            console.log("mail not sent");
        }

        const ejsFilePath = path.join(process.cwd(), "src", "Template", fileName);
        const ejsContent = fs.readFileSync(ejsFilePath, "utf8");
        const html = ejs.render(ejsContent, data2);

        const mailsend = await mailer.send(
            emailConst.confirmEmails.from,  // Ensure `emailConst` is defined and valid
            email,
            cc,
            subject,
            html
        );

        if (mailsend) {
            console.log("Mail Successfully Sent!");
        } else {
            console.log("Error while sending mail");
        }

        return mailsend;
    } catch (error) {
        console.error("Error in applicationEmail:", error);
        throw error;
    }
}


