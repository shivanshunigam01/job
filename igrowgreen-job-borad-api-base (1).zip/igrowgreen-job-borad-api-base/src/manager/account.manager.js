const UserModel = require("../models/response/outUserViewModel.js");
const AccountData = require("../dataLayer/account.data.js");
//const bcrypt = require("bcryptjs");
var crypto = require('crypto');
const jwt = require("jsonwebtoken");
const mailer = require("../helpers/mailer");
const utility = require("../helpers/utility");
const { emailConst } = require("../helpers/constants");
const securePassword = require("../utils/securePassword");
const CommonManager = require("./common.manager.js");
const logger = require("../helpers/logger.js");
const models = require('../../models')

const accountData = new AccountData();
const commonManager = new CommonManager();
/**
 * Account Manager.
 */
class AccountManager {

    /**
     * User Login.
     * @param {model} login.validators
     * @returns {Object}
     */
    async userProfile(req) {
        try {
            let userModel = {};
            const userRes = await accountData.userProfile(req);
    
            if (userRes && userRes.length > 0) {
                const userData = userRes[0];
    
                if (userData.user_type ==1) {
                    // If role is present, return the full user details in company_details
                    userModel = {
                        id: userData.id,
                        name: userData.name,
                        email: userData.email,
                        mobile: userData.mobile,
                        work_status: userData.work_status,
                        status: userData.status,
                        companyPhoto:userData.company_photo,
                        companyPhoto:userData.company_photo,
                        companyPhoto:userData.company_photo,
                        user_type: userData.user_type,
                        created_at: userData.created_at,
                        created_by: userData.created_by,
                        modified_at: userData.modified_at,
                        modified_by: userData.modified_by,
                        company_details: {
                            role: userData.role,
                            reporting_manager: userData.reporting_manager,
                            company_type: userData.company_type,
                            industry_type: userData.industry_type,
                            contact_person: userData.contact_person,
                            company_mobile_2:userData.company_mobile_2,
                            company_email:userData.company_email,
                            contact_person_designation: userData.contact_person_designation,
                            website: userData.website,
                            hotVancanciesProfile: userData.hotVancanciesProfile,
                            classifiedProfile: userData.classifiedProfile,
                            phone_number_1: userData.phone_number_1,
                            phone_number_2: userData.phone_number_2,
                            fax_number: userData.fax_number,
                            tan_number: userData.tan_number,
                            KYC_Status: userData.KYC_Status,
                            PAN_number: userData.PAN_number,
                            PAN_name: userData.PAN_name,
                            address_label: userData.address_label,
                            address: userData.address,
                            country: userData.country,
                            state: userData.state,
                            city: userData.city,
                            pincode: userData.pincode,
                            gst_in: userData.gst_in
                        }
                    };
                } else {
                    userModel = {
                        id: userData.id,
                        name: userData.name,
                        email: userData.email,
                        mobile: userData.mobile,
                        work_status: userData.work_status,
                        status: userData.status,
                        userPhoto:userData.company_photo,
                        join_availability :userData.join_availability,
                        location :userData.location,
                        year_experience :userData.year_experience,
                        month_experience :userData.month_experience,
                        user_type: userData.user_type,
                        created_at: userData.created_at,
                        created_by: userData.created_by,
                        modified_at: userData.modified_at,
                        modified_by: userData.modified_by
                    };
                }
            }

    
            // Log the API call with the user model
            commonManager.generateAPILog(req, userModel, "", 0);
            return userModel;
        } catch (error) {
            let errorLog = error.name + ': ' + error.message;
            // utility.logError(errorLog);
            commonManager.generateAPILog(req, "", errorLog, 1);
        }
    }
    
    
    
}



module.exports = AccountManager;
