const UserModel = require('../models/response/outUserViewModel.js')
const ApplicationData = require('../dataLayer/application.data.js')
//const bcrypt = require("bcryptjs");
var crypto = require('crypto')
const jwt = require('jsonwebtoken')
const mailer = require('../helpers/mailer')
const utility = require('../helpers/utility')
const { emailConst } = require('../helpers/constants')
const securePassword = require('../utils/securePassword')
const CommonManager = require('./common.manager.js')
const logger = require('../helpers/logger.js')
const models = require('../../models')
const fs = require('fs')
const path = require('path')
const ejs = require('ejs')
require('dotenv').config()
const uploadFileMiddleware = require('../middlewares/upload.js')
const { application } = require('express')
const { convertToXML } = require('../helpers/utility.js')
const verifyApplication = require('../middlewares/verifyApplication.js')

const applicationData = new ApplicationData()
const commonManager = new CommonManager()
/**
 * Application Manager.
 */
class ApplicationManager {
  /**
   * User Login.
   * @param {model} login.validators
   * @returns {Object}
   */

  async categorieslist (req) {
    try {
      var model = {}
      const result = await applicationData.categorieslist(req)
      if (result.length > 0) {
        model = result
      }
      return model
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getCategoryAndJobCountFromJob (req, res) {
    try {
      const result = await applicationData.getCategoryAndJobCountFromJob(req)

      // Wrap the total job count in an array
      const totalJobCount = [result[0][0]] // First result set (total job count) wrapped in an array
      const categoryCounts = Object.values(result[1]) // Second result set (category counts)

      // Construct the desired JSON response
      const response = {
        total_job_count: totalJobCount,
        total_category_count: categoryCounts
      }

      return response
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async locationslist (req) {
    try {
      var model = {}
      const result = await applicationData.locationslist(req)
      if (result.length > 0) {
        model = result
      }
      return model
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async departmentlist (req) {
    try {
      var model = {}
      const result = await applicationData.departmentlist(req)
      if (result.length > 0) {
        model = result
      }
      return model
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async educationslist (req) {
    try {
      var model = {}
      const result = await applicationData.educationslist(req)
      if (result.length > 0) {
        model = result
      }
      return model
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async industryTypeslist (req) {
    try {
      var model = {}
      const result = await applicationData.industryTypeslist(req)
      if (result.length > 0) {
        model = result
      }
      return model
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async skillslist (req) {
    try {
      var model = {}
      const result = await applicationData.skillslist(req)
      if (result.length > 0) {
        model = result
      }
      return model
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  // Get paramaters Details
  async getParameters (req) {
    try {
      let userModel = {}
      const userRes = await applicationData.getParameters(req)

      if (userRes) {
        const userData = userRes

        userModel = { item: userData }
      }
      //commonManager.generateAPILog(req, userModel, "", 0);
      return userRes
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      //utility.logError(errorLog);
      //logger.error(errorLog);
      commonManager.generateAPILog(req, '', errorLog, 1)
    }
  }

  async createJobList (req, res) {
    try {
      const skill_XML = convertToXML(req.body?.skills)
      const result = await applicationData.createJobList(req, skill_XML)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async createUserSkill (req, res) {
    try {
      // const skill_XML = convertToXML(req.body?.job_skills);
      const skill_XML = convertToXML(req.body?.skills)
      const result = await applicationData.createUserSkill(req, skill_XML)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getUserSkill (req, res) {
    try {
      const result = await applicationData.getUserSkill(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getUserEmployement (req, res) {
    try {
      const result = await applicationData.getUserEmployement(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getResumeHeadline (req, res) {
    try {
      const result = await applicationData.getResumeHeadline(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async createUserEmployement (req, res) {
    try {
      // const skill_XML = convertToXML(req.body?.job_skills);
      const skill_XML = convertToXML(req.body?.skills)
      const result = await applicationData.createUserEmployement(req, skill_XML)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async createUserEducation (req, res) {
    try {
      const result = await applicationData.createUserEducation(req)
      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getUserEducation (req, res) {
    try {
      const result = await applicationData.getUserEducation(req)
      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getJobListData (req, res) {
    try {
      const result = await applicationData.getJobListData(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async ResumeUpload (req, res) {
    try {
      await uploadFileMiddleware(req, res)
      const result = await applicationData.ResumeUpload(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async ResumeHeadline (req, res) {
    try {
      const result = await applicationData.ResumeHeadline(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getJobListCount (req, res) {
    try {
      const result = await applicationData.getJobListCount(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getJobList (req, res) {
    try {
      const result = await applicationData.getJobList(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async ResumeUpload (req, res) {
    try {
      await uploadFileMiddleware(req, res)
      const result = await applicationData.ResumeUpload(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async jobApply (req, res) {
    try {
      const result = await applicationData.jobApply(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getJobDatabyID (req, res) {
    try {
      const result = await applicationData.getJobDatabyID(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  //API to get common status data
  async getCommonStatus (req, res) {
    try {
      const result = await applicationData.getCommonStatus(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  //API to get common status data
  async getJobMatches (req, res) {
    try {
      const result = await applicationData.getJobMatches(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getJobPostListCount (req, res) {
    try {
      const result = await applicationData.getJobPostListCount(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getJobPostListData (req, res) {
    try {
      const result = await applicationData.getJobPostListData(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async updateJobStatus (req, res) {
    try {
      const result = await applicationData.updateJobStatus(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getJobAppliedUserListCount (req, res) {
    try {
      const result = await applicationData.getJobAppliedUserListCount(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getJobAppliedUserListData (req, res) {
    try {
      const result = await applicationData.getJobAppliedUserListData(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getJobSeekersJobAppliedListCount (req, res) {
    try {
      const result = await applicationData.getJobSeekersJobAppliedListCount(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
}

    async getJobSeekersJobAppliedListData(req, res) {
        try {
            const result = await applicationData.getJobSeekersJobAppliedListData(req);


            return result;
        } catch (error) {
            let errorLog = error.name + ": " + error.message;
            logger.error(errorLog);
            commonManager.generateAPILog(req, result, errorLog, 1);
        }
    }


  async saveUnsaveJob (req, res) {
    try {
      const result = await applicationData.saveUnsaveJob(req)

      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

    async savedUnsavedJobList(req, res) {
        try {
            const result = await applicationData.savedUnsavedJobList(req);

            return result;
        } catch (error) {
            let errorLog = error.name + ": " + error.message;
            logger.error(errorLog);
            commonManager.generateAPILog(req, result, errorLog, 1);
        }
    }
  

  // Update User IT Skills
  async updateUserITSkills (req, res) {
    try {
      const result = await applicationData.updateUserITSkills(req)
      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async deleteUserITSkills (req, res) {
    try {
      const result = await applicationData.deleteUserITSkills(req)
      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  async getUserITSkillsList (req) {
    try {
      var model = {}
      const result = await applicationData.getUserITSkillsList(req)
      if (result.length > 0) {
        model = result
      }
      return model
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  // Create or Update User Profile Summary
  async createProfileSummary (req, res) {
    try {
      const result = await applicationData.createProfileSummary(req)
      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  // Fetch User Profile Summary
  async getProfileSummary (req) {
    try {
      var model = {}
      const result = await applicationData.getProfileSummary(req)
      if (result.length > 0) {
        model = result
      }
      return model
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

  // Delete User Profile Summary
  async deleteUserProfileSummary (req, res) {
    try {
      const result = await applicationData.deleteUserProfileSummary(req)
      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      commonManager.generateAPILog(req, result, errorLog, 1)
    }
  }

    // Update User Personal Details
    async updateUserPersonalDetails(req, res) {
        try {
            const result = await applicationData.updateUserPersonalDetails(req)
            return result
        } catch (error) {
            let errorLog = error.name + ': ' + error.message
            logger.error(errorLog)
            commonManager.generateAPILog(req, result, errorLog, 1)
        }
    }

    // Fetch User Profile Summary
    async getPersonalDetails(req) {
        try {
            var model = {}
            const result = await applicationData.getPersonalDetails(req)
            if (result.length > 0) {
                model = result
            }
            return model
        } catch (error) {
            let errorLog = error.name + ': ' + error.message
            logger.error(errorLog)
            commonManager.generateAPILog(req, result, errorLog, 1)
        }
    }
  

    async createCareerProfile(req, res) {
        try {
            // const skill_XML = convertToXML(req.body?.job_skills);
            const user_preferredLocation_XML = convertToXML(req.body?.locations);
            const result = await applicationData.createCareerProfile(req, user_preferredLocation_XML);

            return result;
        } catch (error) {
            let errorLog = error.name + ": " + error.message;
            logger.error(errorLog);
            commonManager.generateAPILog(req, result, errorLog, 1);
        }
    }

    async getCareerProfile(req, res) {
        try {
            
            const result = await applicationData.getCareerProfile(req);

            return result;
        } catch (error) {
            let errorLog = error.name + ": " + error.message;
            logger.error(errorLog);
            commonManager.generateAPILog(req, result, errorLog, 1);
        }
    }

    async updateCompanyInfo(req, res) {
        try {
            await uploadFileMiddleware(req, res);
            const result = await applicationData.updateCompanyInfo(req);

            return result;
        } catch (error) {
            let errorLog = error.name + ": " + error.message;
            logger.error(errorLog);
            commonManager.generateAPILog(req, result, errorLog, 1);
        }
    }

    async updateUserDetails(req, res) {
        try {
            await uploadFileMiddleware(req, res);
            const result = await applicationData.updateUserDetails(req);

            return result;
        } catch (error) {
            let errorLog = error.name + ": " + error.message;
            logger.error(errorLog);
            commonManager.generateAPILog(req, result, errorLog, 1);
        }
    }

    async updateCompanyDetails(req, res) {
        try {
            const result = await applicationData.updateCompanyDetails(req);

            return result;
        } catch (error) {
            let errorLog = error.name + ": " + error.message;
            logger.error(errorLog);
            commonManager.generateAPILog(req, result, errorLog, 1);
        }
    }

}

module.exports = ApplicationManager
