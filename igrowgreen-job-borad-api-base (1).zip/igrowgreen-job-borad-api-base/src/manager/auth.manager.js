const UserModel = require('../models/response/outUserViewModel.js')
const AuthData = require('../dataLayer/auth.data.js')
//const bcrypt = require("bcryptjs");
var crypto = require('crypto')
const jwt = require('jsonwebtoken')
const mailer = require('../helpers/mailer')
const utility = require('../helpers/utility')
const { emailConst } = require('../helpers/constants')
const securePassword = require('../utils/securePassword')
const CommonManager = require('./common.manager.js')
const logger = require('../helpers/logger.js')
const models = require('../../models')

const authData = new AuthData()
const commonManager = new CommonManager()
/**
 * Auth Manager.
 */
class AuthManager {
  /**
   * User Login.
   * @param {model} login.validators
   * @returns {Object}
   */
  async userLogin (req) {
    try {
      let userModel = {}
      const userRes = await authData.userLogin(req)
      if (userRes && userRes.length > 0) {
        const userData = userRes[0]
        if (userData && userData.password) {
          const decodedPassword = (
            await utility.decryptPasswordData(req.body.password)
          ).toString()
          if (models.user.authenticate(decodedPassword, userData.password)) {
            let data = {
              userID: userData.id,
              type: req.body.user_type
            }
            const jwtPayload = data
            const jwtData = {
              expiresIn: process.env.JWT_TIMEOUT_DURATION
            }
            const secret = process.env.JWT_SECRET
            //Generated JWT token with Payload and secret.
            userData.token = utility.encryptData(
              jwt.sign(jwtPayload, secret, jwtData)
            )
            //userData.type = utility.encryptData("installer");
            //userData.token = jwt.sign(jwtPayload, secret, jwtData);

            userModel = userData
          }
          // const same = await bcrypt.compare(req.body.password, userData.password);

          // if (same) {
          // 	let data = {
          // 		userID: userData.userID,
          // 	}
          // 	const jwtPayload = data;
          // 	const jwtData = {
          // 		expiresIn: process.env.JWT_TIMEOUT_DURATION,
          // 	};
          // 	const secret = process.env.JWT_SECRET;
          // 	//Generated JWT token with Payload and secret.
          // 	userData.token = utility.encryptData((jwt.sign(jwtPayload, secret, jwtData)));
          // 	userModel = userData;
          // }
        }
      }
      commonManager.generateAPILog(req, userModel, '', 0)
      return userModel
      //	return userRes;
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      //utility.logError(errorLog);
      //logger.error(errorLog);
      commonManager.generateAPILog(req, '', errorLog, 1)
    }
  }

  /**
   * User Registration.
   * @param {model} user.validators
   * @returns {Object}
   */
  async userRegistration (req) {
    try {
      var userModel = new UserModel()
      const userRes = await authData.validateUser(req)
      if (userRes.length == 0) {
        const hashedPassword = await securePassword(req.body.password)
        // let otp = utility.randomNumber(4);

        let html =
          '<p>Please Confirm your Account. OTP is valid till 10 minutes.</p>'
        await mailer
          .send(
            emailConst.confirmEmails.from,
            req.body.email,
            'Confirm Account',
            html
          )
          .then(async function (result) {
            const user = await authData.registerUser(req, hashedPassword)
            userModel = user[0]
          })

        //const user = await authData.registerUser(req, hashedPassword, otp);
        //userModel = user[0];
      } else {
        userModel = userRes[0]
      }
      commonManager.generateAPILog(req, userModel, '', 0)
      return userModel
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      //utility.logError(errorLog);
      logger.error(errorLog)
      commonManager.generateAPILog(req, '', errorLog, 1)
    }
  }

  async forgotPassword (req) {
    try {
      const email = req.body.email
      const user = await authData.findUserByEmail(email)

      if (user) {
        // Generate a 5-digit OTP
        const otp = Math.floor(10000 + Math.random() * 90000).toString() // Generates a 5-digit OTP

        let html = `<p>Hi ${user.name},</p>`
        html += `<p>You requested to reset your password.</p>`
        html += `<p>Your OTP for password reset is: <b>${otp}</b>.OTP is valid till 10 minutes.</p>`
        html += `<p>Please, enter this OTP on the password reset page to proceed.</p>`

        // Send email with OTP
        await mailer.send(
          emailConst.confirmEmails.from,
          user.email,
          null,
          'Password Reset Request',
          html
        )

        // Store the OTP in the database (you can also store a hashed version for security)
        const userReq = {
          resetPasswordToken: otp, // You can hash it if needed
          otpExpiry: new Date(Date.now() + 10 * 60 * 1000) // OTP expiry set to 10 minutes
        }
        const result = await authData.updateForgotPasswordToken(
          user.id,
          userReq
        )
        return result // Return the result if needed
      }

      return null
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      logManager.generateAPILog(req, '', errorLog, 1)
    }
  }

  // Reset Password
  async otpVerifyResetPassword (req) {
    try {
      const result = await authData.otpVerifyResetPassword(req)
      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      logManager.generateAPILog(req, '', errorLog, 1)
    }
  }

  // Change Password
  async changePassword (req) {
    try {
      const result = await authData.changePassword(req)
      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      logManager.generateAPILog(req, '', errorLog, 1)
    }
  }
}

module.exports = AuthManager
