const { Model } = require("sequelize");
const CommonData = require("../dataLayer/common.data");
const logger = require("../helpers/logger.js");
// const logManager=require("../helpers/")
const commonData = new CommonData();




/**
 * Common Manager.
 */
class CommonManager {


	async generateAPILog(req, res, message, hasError) {
		try {
			const response = await commonData.generateLog(req, res, message, hasError);
			let result;
			if (response && response.length > 0) {
				result = response[0];
			}
			return result;
		} catch (error) {
			throw error;
		}
	}

	async getDetails(req) {
		try {
			var model = {};
			const result = await commonData.getDetails(req);
			if (result.length > 0) {
				model = result;

			}
			return model;
		} catch (error) {
			let errorLog = error.name + ": " + error.message;
			logger.error(errorLog);
			this.generateAPILog(req, "", errorLog, 1);
		}

	}

    async applyFilter(req) {
		try {
			var model = {};
			const result = await commonData.applyFilter(req);
			if (result.length > 0) {
				model = result;

			}
			return model;
		} catch (error) {
			let errorLog = error.name + ": " + error.message;
			logger.error(errorLog);
			this.generateAPILog(req, "", errorLog, 1);
		}

	}


    async mainFilter(req) {
		try {
			var model = {};
			const result = await commonData.mainFilter(req);
			if (result.length > 0) {
				model = result;

			}
			return model;
		} catch (error) {
			let errorLog = error.name + ": " + error.message;
			logger.error(errorLog);
			this.generateAPILog(req, "", errorLog, 1);
		}

	}
}



module.exports = CommonManager;
