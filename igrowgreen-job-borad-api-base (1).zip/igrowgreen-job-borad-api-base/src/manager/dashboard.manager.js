const { Model } = require("sequelize");
const DashboardData = require("../dataLayer/dashboard.data");

const dashboardData = new DashboardData();

/**
 * Dashboard Manager.
 */
class DashboardManager {


    async getDashboardList(req) {
        try {
            const result = await dashboardData.getDashboardList(req);
            return result; 
        } catch (error) {
            let errorLog = error.name + ": " + error.message;
            logger.error(errorLog);
            logManager.generateAPILog(req, "", errorLog, 1);
            throw error; 
        }
    }

    }



module.exports = DashboardManager;
