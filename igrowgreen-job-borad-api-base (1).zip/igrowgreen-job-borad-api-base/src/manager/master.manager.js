const UserModel = require("../models/response/outUserViewModel.js");
const MasterData = require("../dataLayer/master.data.js");
//const bcrypt = require("bcryptjs");
var crypto = require('crypto');
const jwt = require("jsonwebtoken");
const mailer = require("../helpers/mailer");
const utility = require("../helpers/utility");
const { emailConst } = require("../helpers/constants");
const securePassword = require("../utils/securePassword");
const CommonManager = require("./common.manager.js");
const logger = require("../helpers/logger.js");
const models = require('../../models')

const masterData = new MasterData();
const commonManager = new CommonManager();
/**
 * Master Manager.
 */
class MasterManager {

	/**
	 * User Login.
	 * @param {model} login.validators
	 * @returns {Object}
	 */

	async getStateList(req) {
		try {
			let userModel = {};
			const userRes = await masterData.getStateList(req);

			if (userRes) {
				const userData = userRes;

				userModel = userData;
			}
			commonManager.generateAPILog(req, userModel, "", 0);
			return userRes;
		} catch (error) {
			let errorLog = error.name + ': ' + error.message;
			//utility.logError(errorLog);
			//logger.error(errorLog);
			commonManager.generateAPILog(req, "", errorLog, 1);
		}
	}

	async createCategories(req) {
		try {
			const result = await masterData.addCategories(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getCategoriesData(req) {
		try {
			const result = await masterData.getCategoriesData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getCategoriesCount(req) {
		try {
			const result = await masterData.getCategoriesCount(req)

			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteCategories(req) {
		try {
			const result = await masterData.deleteCategories(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createDepartments(req) {
		try {
			const result = await masterData.addDepartments(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getDepartmentsData(req) {
		try {
			const result = await masterData.getDepartmentsData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getDepartmentsCount(req) {
		try {
			const result = await masterData.getDepartmentsCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteDepartments(req) {
		try {
			const result = await masterData.deleteDepartments(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createModules(req) {
		try {
			const result = await masterData.addModules(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getModulesData(req) {
		try {
			const result = await masterData.getModulesData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getModulesCount(req) {
		try {
			const result = await masterData.getModulesCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteModules(req) {
		try {
			const result = await masterData.deleteModules(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createLocations(req) {
		try {
			const result = await masterData.addLocations(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getLocationsData(req, res) {
		try {
			const result = await masterData.getLocationsData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getlocationsCount(req) {
		try {
			const result = await masterData.getlocationsCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteLocations(req) {
		try {
			const result = await masterData.deleteLocations(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}

	async createEducations(req) {
		try {
			const result = await masterData.addEducations(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getEducationsData(req) {
		try {
			const result = await masterData.getEducationsData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getEducationsCount(req) {
		try {
			const result = await masterData.getEducationsCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteEducations(req) {
		try {
			const result = await masterData.deleteEducations(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createIndustryTypes(req) {
		try {
			const result = await masterData.addIndustryTypes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getIndustryTypesData(req) {
		try {
			const result = await masterData.getIndustryTypesData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getIndustryTypesCount(req) {
		try {
			const result = await masterData.getIndustryTypesCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteIndustryTypes(req) {
		try {
			const result = await masterData.deleteIndustryTypes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createSkills(req) {
		try {
			const result = await masterData.addSkills(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getSkillsData(req) {
		try {
			const result = await masterData.getSkillsData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getSkillsCount(req) {
		try {
			const result = await masterData.getSkillsCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteSkills(req) {
		try {
			const result = await masterData.deleteSkills(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createJobTypes(req) {
		try {
			const result = await masterData.addJobTypes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getJobTypesData(req) {
		try {
			const result = await masterData.getJobTypesData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getJobTypesCount(req) {
		try {
			const result = await masterData.getJobTypesCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteJobTypes(req) {
		try {
			const result = await masterData.deleteJobTypes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createWorkModes(req) {
		try {
			const result = await masterData.addWorkModes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getWorkModesData(req) {
		try {
			const result = await masterData.getWorkModesData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getWorkModesCount(req) {
		try {
			const result = await masterData.getWorkModesCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteWorkModes(req) {
		try {
			const result = await masterData.deleteWorkModes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createSalaryTypes(req) {
		try {
			const result = await masterData.addSalaryTypes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getSalaryTypesData(req) {
		try {
			const result = await masterData.getSalaryTypesData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getSalaryTypesCount(req) {
		try {
			const result = await masterData.getSalaryTypesCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteSalaryTypes(req) {
		try {
			const result = await masterData.deleteSalaryTypes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createShiftTimes(req) {
		try {
			const result = await masterData.addShiftTimes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getShiftTimesData(req) {
		try {
			const result = await masterData.getShiftTimesData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getShiftTimesCount(req) {
		try {
			const result = await masterData.getShiftTimesCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteShiftTimes(req) {
		try {
			const result = await masterData.deleteShiftTimes(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createTotalExperiences(req) {
		try {
			const result = await masterData.addTotalExperiences(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getTotalExperiencesData(req) {
		try {
			let result = await masterData.getTotalExperiencesData(req)
			if (result?.length) {
				result = result.map(element => ({
					...element,
					total_experience: `${element?.min_year}-${element?.max_year} yrs`
				}));
			}
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getTotalExperiencesCount(req) {
		try {
			const result = await masterData.getTotalExperiencesCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteTotalExperiences(req) {
		try {
			const result = await masterData.deleteTotalExperiences(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async createSalaries(req) {
		try {
			const result = await masterData.addSalaries(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getSalariesData(req) {
		try {
			let result = await masterData.getSalariesData(req)
			if (result?.length) {
				result = result.map(element => ({
					...element,
					total_salary: `${element?.min_salary}-${element?.max_salary} lakhs`
				}));
			}
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getSalariesCount(req) {
		try {
			const result = await masterData.getSalariesCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async deleteSalaries(req) {
		try {
			const result = await masterData.deleteSalaries(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getCompaniesData(req) {
		try {
			let result = await masterData.getCompaniesData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getCompaniesCount(req) {
		try {
			let result = await masterData.getCompaniesCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getCompaniesJobPostListData(req) {
		try {
			let result = await masterData.getCompaniesJobPostListData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getCompaniesJobPostListCount(req) {
		try {
			let result = await masterData.getCompaniesJobPostListCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getCompaniesJobAppliedUserListData (req){
		try {
			let result = await masterData.getCompaniesJobAppliedUserListData(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async getCompaniesJobAppliedUserListCount (req){
		try {
			let result = await masterData.getCompaniesJobAppliedUserListCount(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async updateStatus (req){
		try {
			let result = await masterData.updateStatus(req)
			return result
		} catch (error) {
			let errorLog = error.name + ': ' + error.message
			logger.error(errorLog)
			commonManager.generateAPILog(req, result, errorLog, 1)
		}
	}
	async forgotPassword (req) {
		try {
		  const email = req.body.email
		  const user = await masterData.findUserByEmail(email)
	
		  if (user) {
			// Generate a 5-digit OTP
			const otp = Math.floor(10000 + Math.random() * 90000).toString() // Generates a 5-digit OTP
	
			let html = `<p>Hi ${user.name},</p>`
			html += `<p>You requested to reset your password.</p>`
			html += `<p>Your OTP for password reset is: <b>${otp}</b>.OTP is valid till 10 minutes.</p>`
			html += `<p>Please, enter this OTP on the password reset page to proceed.</p>`
	
			// Send email with OTP
			await mailer.send(
			  emailConst.confirmEmails.from,
			  user.email,
			  null,
			  'Password Reset Request',
			  html
			)
	
			// Store the OTP in the database (you can also store a hashed version for security)
			const userReq = {
			  resetPasswordToken: otp, // You can hash it if needed
			  otpExpiry: new Date(Date.now() + 10 * 60 * 1000) // OTP expiry set to 10 minutes
			}
			const result = await  masterData.updateForgotPasswordToken(
			  user.id,
			  userReq
			)
			return result // Return the result if needed
		  }
	
		  return null
		} catch (error) {
		  let errorLog = error.name + ': ' + error.message
		  logger.error(errorLog)
		  logManager.generateAPILog(req, '', errorLog, 1)
		}
	  }


  // Reset Password
  async otpVerifyResetPassword (req) {
    try {
      const result = await masterData.otpVerifyResetPassword(req)
      return result
    } catch (error) {
      let errorLog = error.name + ': ' + error.message
      logger.error(errorLog)
      logManager.generateAPILog(req, '', errorLog, 1)
    }
  }

    // Change Password
	async changePassword (req) {
		try {
		  const result = await masterData.changePassword(req)
		  return result
		} catch (error) {
		  let errorLog = error.name + ': ' + error.message
		  logger.error(errorLog)
		  logManager.generateAPILog(req, '', errorLog, 1)
		}
	  }
}

module.exports = MasterManager;
