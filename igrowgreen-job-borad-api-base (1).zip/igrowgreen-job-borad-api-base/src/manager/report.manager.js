const UserModel = require("../models/response/outUserViewModel.js");
const ReportData = require("../dataLayer/report.data.js");
//const bcrypt = require("bcryptjs");
var crypto = require('crypto');
const jwt = require("jsonwebtoken");
const mailer = require("../helpers/mailer");
const utility = require("../helpers/utility");
const { emailConst } = require("../helpers/constants");
const securePassword = require("../utils/securePassword");
const CommonManager = require("./common.manager.js");
const logger = require("../helpers/logger.js");
const models = require('../../models')
const uploadFileMiddleware = require("../middlewares/upload.js");
const { convertToXML } = require("../helpers/utility.js");
const reportData = new ReportData();
const commonManager = new CommonManager();
const xmlbuilder = require('xmlbuilder');
/**
 * Report Manager.
 */
class ReportManager {

    /**
     * User Login.
     * @param {model} login.validators
     * @returns {Object}
     */


    
    async SendLeadotp(req, res) {
        try {
         
            await uploadFileMiddleware(req, res);
            const result = await reportData.SendLeadotp(req);
     
            return result;
        } catch (error) {
            let errorLog = error.name + ": " + error.message;
            logger.error(errorLog);
            commonManager.generateAPILog(req, "", errorLog, 1);
        }
    }

  

}

module.exports = ReportManager;
