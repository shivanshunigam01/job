const UserModel = require("../models/response/outUserViewModel.js");
const TicketData = require("../dataLayer/ticket.data.js");
//const bcrypt = require("bcryptjs");
var crypto = require('crypto');
const jwt = require("jsonwebtoken");
const mailer = require("../helpers/mailer");
const utility = require("../helpers/utility");
const { emailConst } = require("../helpers/constants");
const securePassword = require("../utils/securePassword");
const CommonManager = require("./common.manager.js");
const logger = require("../helpers/logger.js");
const models = require('../../models')
const uploadFileMiddleware = require("../middlewares/upload.js");
const ticketData = new TicketData();
const commonManager = new CommonManager();
/**
 * Ticket Manager.
 */
class TicketManager {

	/**
	 * User Login.
	 * @param {model} login.validators
	 * @returns {Object}
	 */
	async ticketCount(req) {
		try {
			let userModel = {};
			const userRes = await ticketData.ticketCount(req);
		
			if (userRes) {
				const userData = userRes;
			
				userModel ={count:userData} ;
			}
			//commonManager.generateAPILog(req, userModel, "", 0);
			return userRes;
		} catch (error) {
			let errorLog = error.name + ': ' + error.message;
			//utility.logError(errorLog);
			//logger.error(errorLog);
			commonManager.generateAPILog(req, "", errorLog, 1);
		}
	}
	async ticketList(req) {
		try {
			let userModel = {};
			const userRes = await ticketData.ticketList(req);
		
			if (userRes) {
				const userData = userRes;
			
				userModel =userData;
			}
			commonManager.generateAPILog(req, userModel, "", 0);
			return userRes;
		} catch (error) {
			let errorLog = error.name + ': ' + error.message;
			//utility.logError(errorLog);
			//logger.error(errorLog);
			commonManager.generateAPILog(req, "", errorLog, 1);
		}
	}


    async getTicketSubcategoryList(req) {
		try {
			let userModel = {};
			const userRes = await ticketData.getTicketSubcategoryList(req);
		
			if (userRes) {
				const userData = userRes;
			
				userModel =userData;
			}
			// commonManager.generateAPILog(req, userModel, "");
			return userRes;
		} catch (error) {
			let errorLog = error.name + ': ' + error.message;
			//utility.logError(errorLog);
			//logger.error(errorLog);
			commonManager.generateAPILog(req, "", errorLog, 1);
		}
	}


    async getTicketList(req) {
		try {
			let userModel = {};
			const userRes = await ticketData.getTicketList(req);
		
			if (userRes) {
				const userData = userRes;
			
				userModel =userData;
			}
			// commonManager.generateAPILog(req, userModel, "");
			return userRes;
		} catch (error) {
			let errorLog = error.name + ': ' + error.message;
			//utility.logError(errorLog);
			//logger.error(errorLog);
			commonManager.generateAPILog(req, "", errorLog, 1);
		}
	}


	async ticketCreate(req,res) {
		try {
            await uploadFileMiddleware(req, res);
            let fileName = req.files[0]?.filename?req.files[0].filename:'';

			let userModel = {};
			const userRes = await ticketData.ticketCreate(req,fileName);
           
			if (userRes) {
				const userData = userRes;
			
				userModel =userData;
			}
			commonManager.generateAPILog(req, userModel, "", 0);
			return userRes;
		} catch (error) {
			let errorLog = error.name + ': ' + error.message;
			//utility.logError(errorLog);
			//logger.error(errorLog);
			commonManager.generateAPILog(req, "", errorLog, 1);
		}
	}

    async updateTask(req, res) {
        try {
            const result = await ticketData.updateTask(req);

          return result;
        } catch (error) {
          let errorLog = error.name + ": " + error.message;
          logger.error(errorLog);
          logManager.generateAPILog(req, "", errorLog, 1);
        }
      }
    
      async getTaskDetails(req, res) {
        try {
            const result = await ticketData.getTaskDetails(req);
   
          return result;
        } catch (error) {
          let errorLog = error.name + ": " + error.message;
          logger.error(errorLog);
          logManager.generateAPILog(req, "", errorLog, 1);
        }
      }

 
}

module.exports = TicketManager;
