const jwt = require("jsonwebtoken");
const cacheUtil = require('../utils/cache');
const apiResponse = require("../helpers/apiResponse");
const commonFunction = require("../helpers/utility.js");
const config = process.env;

const verifyTokenIfApplicable = async (req, res, next) => {
    console.log(req.headers);
    let token =  req.headers["authorization"];
    req.body.deviceType = req.headers["device-type"];
    console.log("token==>",token);
    if (token && token.startsWith('Bearer ')) {
        token = token.slice(7, token.length).trim();
    }
    console.log("token1==>",token);

    if (!token) {
		req.user = {userID: 0}
        return next();
    }else{
		try {
			/* ---------------------- Check For Blacklisted Tokens ---------------------- */
			const isBlackListed = await cacheUtil.get(token);
			if (isBlackListed) {
				return apiResponse.unauthorizedResponse(res, "Unauthorized.");
			}
			const decoded = jwt.verify(commonFunction.decryptData(token), config.JWT_SECRET);
			req.user = decoded;
			//console.log(req.user);
		} catch (err) {
			return apiResponse.unauthorizedResponse(res, "Invalid Token.");
		}
		return next();
	}
};

module.exports = verifyTokenIfApplicable;