const apiResponse = require("../helpers/apiResponse");
const { userType } = require("../helpers/constants")


const isAdmin = async (req, res, next) => {
	if (req.user?.type !== userType?.Admin) {
		return apiResponse.forbiddenRequest(res, "User cannot access requested resource");
	}
	next()
}

module.exports = isAdmin