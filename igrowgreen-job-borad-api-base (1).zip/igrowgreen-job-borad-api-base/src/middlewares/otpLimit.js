const NodeCache = require('node-cache');
const myCache = new NodeCache();
const apiResponse = require("../helpers/apiResponse");
const utility = require("../helpers/utility");


const otpLimit = (req, res, next) => {
 

    let applicationID='';
    let mobileNo='';
    let consumer_no='';
    let key;


    // const userId = req.user.userID; // or req.user.id if you have user authentication
    if(req.body?.applicationId || req.body?.application_id || req?.body.applicationID){
        applicationID = utility.decryptID(req.body?.applicationId || req.body?.application_id || req?.body.applicationID || '');
    }


 
    if(applicationID!==''){
        key = `otp_limit_${applicationID}`;
    }
    else if(req.originalUrl=="/api/common/storeTrackApplicationOtp" || req.originalUrl=='/api/common/resendTrackApplicationOTP'){
        key = `otp_limit_${req?.body.mobile ||''}`;
    }
    else if(req.originalUrl=='/api/common/resendOtpSolarCalculator' || req.originalUrl=='/api/common/getCalculationDetails'){
        key = `otp_limit_${req.body?.consumer_no || ''}`;
    }else{
        key = `otp_limit_${req.body.email}`;
    }
     
    
    
   
    

    const currentTime = Date.now();
    const windowTime = 30 * 60 * 1000; // 30 minutes in milliseconds
    const requestLimit = 5;
   
    
    const record = myCache.get(key);

    if (!record) {
        const newRecord = {
            count: 1,
            startTime: currentTime
        };
        myCache.set(key, newRecord, windowTime / 1000);
        next();
    } else {
        if (currentTime - record.startTime < windowTime) {
            if (record.count < requestLimit) {
                record.count++;
                myCache.set(key, record, windowTime / 1000);
                next();
            } else {
                return apiResponse.tooManyRequests(res, 'Too many requests, please try again after 30 minutes.');
            }
        } else {
            const newRecord = {
                count: 1,
                startTime: currentTime
            };
            myCache.set(key, newRecord, windowTime / 1000);
            next();
        }
    }
};

module.exports = otpLimit;
