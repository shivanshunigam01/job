/**
* Common file upload middlewre.
*/

const util = require("util");
const multer = require("multer");
const maxSize = 5 * 1024 * 1024;
var fs = require('fs');
require('dotenv').config();
var crypto = require('crypto');
const utility = require("../helpers/utility");
// const tempFileLocation = process.env.FILE_LOCATION + process.env.TEMP_FILE_LOCATION;
//const mv = require('mv');

let storage = multer.diskStorage({
  destination: (req, file, cb) => {
	var dir;
	if(req.body.fileStore == 'installer'){
		dir = __basedir + process.env.INSTALLER_FILE_LOCATION;
	}else{
		dir = __basedir + process.env.FILE_LOCATION + '/'+ (req.user.userID);
	}
    //console.log(dir);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    cb(null, dir);
  },
  filename: (req, file, cb) => {
	let extension = "pdf"
	const myArray = file.originalname.split(".");
	extension = myArray[myArray.length-1];
	let fileName = crypto.randomUUID() + '.' + extension
	
    //console.log(file.originalname);
    //console.log(__basedir);
    cb(null, fileName);
    //cb(null, file.originalname);
  },
});

// File filter to allow only PDFs
// File filter to allow only PDFs and image files
const fileFilter = (req, file, cb) => {
	const allowedMimeTypes = [
	  'application/pdf',
	  'image/jpeg',
	  'image/jpg',
	  'image/png'
	];
	if (allowedMimeTypes.includes(file.mimetype.toLowerCase())) {
	  cb(null, true);
	} else {
	  cb(new Error('File type are not allowed!'), false);
	}
};

let uploadFile = multer({
  storage: storage,
  limits: { fileSize: maxSize },
  fileFilter: fileFilter,
}).any("files");
 
let uploadFileMiddleware = util.promisify(uploadFile);
module.exports = uploadFileMiddleware;  