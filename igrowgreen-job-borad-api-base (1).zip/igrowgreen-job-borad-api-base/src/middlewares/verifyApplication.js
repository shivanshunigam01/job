
const apiResponse = require("../helpers/apiResponse");
const utility = require("../helpers/utility");
const db = require("../../config/database.js");

const verifyApplication = async (req, res,next) => {


    try {
        req.body.deviceType = req.headers["device-type"];
        
        if (req.user.type != 'member' || req.user.type != 'consumer') {

            if (req.user.type == 'installer') {

                const applicationID = utility.decryptID(req.body.applicationId || req.body.application_id || req.body.applicationID);
                const userId = req.user.userID;
                const procedureName = "VerifyApplication";

                const applicationResponse = await db.query(
                    `CALL ${procedureName}(:applicationID,:userId )`,
                    {
                        replacements: { applicationID,userId },
                        type: db.QueryTypes.RAW,
                    }
                );

                if(applicationResponse[0].FLAG==0){
                    return apiResponse.notAcceptableRequest(res, "Invalid User Access.");
                }

            }
        }
    } catch (err) {
        return apiResponse.unauthorizedResponse(res, "Invalid User Access.");
    }
    return next();
};

module.exports = verifyApplication;