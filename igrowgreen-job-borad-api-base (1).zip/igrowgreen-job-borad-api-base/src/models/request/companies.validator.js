const joi = require("joi");
const apiResponse = require("../../helpers/apiResponse");


const validation = (validationObject) => {
	const validation = joi.object(validationObject);
	return validation
}


const getCompaniesValidation = async (req, res, next) => {
	const payload = {
		page: req.body?.page,
		size: req.body?.size,
		search: req.body?.search,
		location: req.body?.location,
	}
	const validationObject = {
		page: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		size: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		search: joi.string().messages({
			'string.base': `{#key} must be a string`
		}),
		location: joi.string().messages({
			'string.base': `{#key} must be a string`,
		}),

	}

	const { error } = validation(validationObject).validate(payload)
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}

const getCompaniesJobPostListValidation = async (req, res, next) => {
	const payload = {
		page: req.body?.page,
		size: req.body?.size,
		search: req.body?.search,
		on_location_job: req.body?.on_location_job,
		total_experience: req.body?.total_experience,
		job_category: req.body?.job_category,
		userID: req.body?.userID,
	}
	const validationObject = {
		page: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		size: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		search: joi.string().messages({
			'string.base': `{#key} must be a string`
		}),
		on_location_job: joi.string().messages({
			'string.base': `{#key} must be a string`,
		}),
		total_experience: joi.string().messages({
			'string.base': `{#key} must be a string`,
		}),
		job_category: joi.string().messages({
			'string.base': `{#key} must be a string`,
		}),
		userID: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),

	}

	const { error } = validation(validationObject).validate(payload)
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}

const getCompaniesJobAppliedUserListValidation = async (req, res, next) => {
	const payload = {
		page: req.body?.page,
		size: req.body?.size,
		search: req.body?.search,
		job_id: req.body?.job_id,
	}
	const validationObject = {
		job_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		search: joi.string().messages({
			'string.base': `{#key} must be a string`
		}),
		page: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		size: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		})
	}

	const { error } = validation(validationObject).validate(payload)
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}


const updateStatusListValidation = async (req, res, next) => {
	const payload = {
		category_id: req.body?.category_id,
		department_id: req.body?.department_id,
		education_id: req.body?.education_id,
		industry_type_id: req.body?.industry_type_id,
		job_types_id: req.body?.job_types_id,
		location_id: req.body?.location_id,
		module_id: req.body?.module_id,
		salary_id: req.body?.salary_id,
		salary_types_id: req.body?.salary_types_id,
		shift_times_id: req.body?.shift_times_id,
		total_experiences_id: req.body?.total_experiences_id,
		work_modes_id: req.body?.work_modes_id,
		skill_id: req.body?.skill_id,

	}
	const validationObject = {
		category_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		department_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		education_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		industry_type_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		location_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		module_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		salary_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		salary_types_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		shift_times_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		total_experiences_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		work_modes_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		skill_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
		job_types_id: joi.number().strict().integer().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
		}),
	}

	const { error } = validation(validationObject).validate(payload)
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}

module.exports = { getCompaniesValidation, getCompaniesJobPostListValidation, getCompaniesJobAppliedUserListValidation, updateStatusListValidation }
