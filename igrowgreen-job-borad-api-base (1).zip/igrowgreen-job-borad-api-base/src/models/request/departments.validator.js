const joi = require("joi");
const apiResponse = require("../../helpers/apiResponse");


const validation = (validationObject) => {
	const validation = joi.object(validationObject);
	return validation
}


const createOrUpdateDepartmentsValidation = async (req, res, next) => {
	const payload = {
		department_name: req.body?.department_name,
		description: req.body?.description,
		status: req.body?.status,
	}
	const validationObject = {
		department_name: joi.string().required().messages({
			'string.base': `{#key} must be a string`,
			'any.required': `{#key} is a required field`
		}),
		description: joi.string().messages({
			'string.base': `{#key} must be a string`
		}),
		status: joi.number().integer().valid(0, 1).messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
			'any.only': `{#key} must be either 0 or 1`
		})
	}

	const { error } = validation(validationObject).validate(payload)
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}

const deleteDeaprtmentsValidation = async (req, res, next) => {
	const payload = {
		department_id: req.body?.department_id,
	}
	const validationObject = {
		department_id: joi.number().integer().strict().required().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
			'any.required': `{#key} is a required field`
		})

	}
	const { error } = validation(validationObject).validate(payload);
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}

module.exports = { createOrUpdateDepartmentsValidation, deleteDeaprtmentsValidation }