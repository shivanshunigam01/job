const joi = require("joi");
const apiResponse = require("../../helpers/apiResponse");


const validation = (validationObject) => {
	const validation = joi.object(validationObject);
	return validation
}


const createOrUpdateJobTypesValidation = async (req, res, next) => {
	const payload = {
		job_types_name: req.body?.job_types_name,
		description: req.body?.description,
		status: req.body?.status,
	}
	const validationObject = {
		job_types_name: joi.string().required().messages({
			'string.base': `{#key} must be a string`,
			'any.required': `{#key} is a required field`
		}),
		description: joi.string().messages({
			'string.base': `{#key} must be a string`
		}),
		status: joi.number().integer().valid(0, 1).messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
			'any.only': `{#key} must be either 0 or 1`
		})
	}

	const { error } = validation(validationObject).validate(payload)
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}

const deleteJobTypesValidation = async (req, res, next) => {
	const payload = {
		job_types_id: req.body?.job_types_id,
	}
	const validationObject = {
		job_types_id: joi.number().integer().strict().required().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
			'any.required': `{#key} is a required field`
		})

	}
	const { error } = validation(validationObject).validate(payload);
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}

module.exports = { createOrUpdateJobTypesValidation, deleteJobTypesValidation }
