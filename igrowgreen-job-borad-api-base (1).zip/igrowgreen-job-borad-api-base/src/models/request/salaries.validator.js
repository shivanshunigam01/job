const joi = require("joi");
const apiResponse = require("../../helpers/apiResponse");


const validation = (validationObject) => {
	const validation = joi.object(validationObject);
	return validation
}


const addOrUpdatesalariesValidation = async (req, res, next) => {
	const payload = {
		min_salary: req.body?.min_salary,
		max_salary: req.body?.max_salary,
		description: req.body?.description,
		status: req.body?.status,
	};
	const validationObject = {
		min_salary: joi.number()
			.integer()
			.min(0)
			.max(99)
			.required()
			.messages({
				'number.base': `{#key} must be a number`,
				'number.min': `{#key} must be at least {#limit}`,
				'number.max': `{#key} cannot be greater than {#limit}`,
				'any.required': `{#key} is a required field`
			}),
		max_salary: joi.number()
			.integer()
			.min(0)
			.max(99)
			.required()
			.greater(joi.ref('min_salary'))
			.messages({
				'number.base': `{#key} must be a number`,
				'number.min': `{#key} must be at least {#limit}`,
				'number.max': `{#key} cannot be greater than {#limit}`,
				'number.greater': `{#key} must be greater than min_salary`,
				'any.required': `{#key} is a required field`
			}),
		description: joi.string().messages({
			'string.base': `{#key} must be a string`
		}),
		status: joi.number().integer().valid(0, 1).messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
			'any.only': `{#key} must be either 0 or 1`
		})
	}
	const { error } = validation(validationObject).validate(payload);
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
};



const deleteSalaryValidation = async (req, res, next) => {
	const payload = {
		salary_id: req.body?.salary_id,
	}
	const validationObject = {
		salary_id: joi.number().integer().required().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
			'any.required': `{#key} is a required field`
		})

	}
	const { error } = validation(validationObject).validate(payload);
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}


module.exports = { addOrUpdatesalariesValidation, deleteSalaryValidation }