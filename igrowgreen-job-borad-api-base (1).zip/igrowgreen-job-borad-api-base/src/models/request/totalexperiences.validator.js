const joi = require("joi");
const apiResponse = require("../../helpers/apiResponse");


const validation = (validationObject) => {
	const validation = joi.object(validationObject);
	return validation
}



const createOrUpdateExperienceValidation = async (req, res, next) => {
	const payload = {
		min_year: req.body?.min_year,
		max_year: req.body?.max_year,
		description: req.body?.description,
		status: req.body?.status,
	};

	const validationObject = {
		min_year: joi.number()
			.integer()
			.min(0)
			.max(99)
			.required()
			.messages({
				'number.base': `{#key} must be a number`,
				'number.min': `{#key} must be at least {#limit}`,
				'number.max': `{#key} cannot be greater than {#limit}`,
				'any.required': `{#key} is a required field`
			}),
		max_year: joi.number()
			.integer()
			.min(0)
			.max(99)
			.required()
			.greater(joi.ref('min_year'))
			.messages({
				'number.base': `{#key} must be a number`,
				'number.min': `{#key} must be at least {#limit}`,
				'number.max': `{#key} cannot be greater than {#limit}`,
				'number.greater': `{#key} must be greater than min_year`,
				'any.required': `{#key} is a required field`
			}),
		description: joi.string().messages({
			'string.base': `{#key} must be a string`
		}),
		status: joi.number().integer().valid(0, 1).messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
			'any.only': `{#key} must be either 0 or 1`
		})

	}

	const { error } = validation(validationObject).validate(payload)
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
};


const deleteExperienceValidation = async (req, res, next) => {
	const payload = {
		total_experiences_id: req.body?.total_experiences_id,
	}
	const validationObject = {
		total_experiences_id: joi.number().integer().required().messages({
			'number.base': `{#key} must be a number`,
			'number.integer': `{#key} must be an integer`,
			'any.required': `{#key} is a required field`
		})

	}
	const { error } = validation(validationObject).validate(payload);
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
}



module.exports = { createOrUpdateExperienceValidation, deleteExperienceValidation }


