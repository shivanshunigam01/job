/**
* file which containts all routes of the Auth controllers.
*/

const express = require("express");
const loginValidation = require("../models/request/login.validator");
const userValidation = require("../models/request/user.validator");
const { AccountController } = require("../controllers/account.controller");
const verifyToken = require("../middlewares/auth.js");

const accountController = new AccountController(); 
const router = express.Router();

router.post("/profile",verifyToken, accountController.userProfile);

module.exports = router;