/**
* file which containts all the controllers routes.
*/

var express = require("express");
const authRoutes = require("./auth.routes.js");
const accountRoutes = require("./account.routes.js");
const commonRoutes = require("./commonRoutes.js");
const applicationRoutes = require("./application.routes.js");
const ticketRoutes = require("./ticket.routes.js");
const reportRoutes = require("./report.routes.js");
//const pvInspectionRoutes = require("./pvInspection.routes.js");
const masterRoutes = require("./master.routes.js");
const dashboardRoutes = require("./dashboard.routes.js");
const jobApplicationRoutes = require("./dashboard.routes.js");



var app = express();

app.use("/auth/", authRoutes);
app.use("/application/", applicationRoutes);
app.use("/dashboard/", dashboardRoutes);
app.use("/account/", accountRoutes);
app.use("/common/", commonRoutes);

app.use("/ticket/", ticketRoutes);

app.use("/master/", masterRoutes);



module.exports = app;