/**
* file which containts all routes of the Auth controllers.
*/

const express = require("express");
const loginValidation = require("../models/request/login.validator");
const userValidation = require("../models/request/user.validator");
const { ApplicationController } = require("../controllers/application.controller");
const otpLimiter = require("../middlewares/otpLimit.js")
const verifyToken = require("../middlewares/auth.js");
const verifyApplication = require("../middlewares/verifyApplication.js");
const verifyTokenIfApplicable = require("../middlewares/authApplicableOrNot.js");

const applicationController = new ApplicationController();
const router = express.Router();
//SOME COMMON LISTING API'S
router.post("/categorieslist", applicationController.categorieslist);
router.post("/locationslist", applicationController.locationslist);
router.post("/departmentlist", applicationController.departmentlist);
router.post("/educationslist", applicationController.educationslist);
router.post("/industryTypeslist", applicationController.industryTypeslist);
router.post("/skillslist", applicationController.skillslist);
router.post("/parameters", applicationController.getParameters);
//

//PROFILE API'S
router.post("/ResumeUpload", verifyToken, applicationController.ResumeUpload);
router.post("/ResumeHeadline",verifyToken, applicationController.ResumeHeadline);
router.post("/createUserSkill", verifyToken, applicationController.createUserSkill);
router.post("/getUserSkill", verifyToken, applicationController.getUserSkill);
router.post("/getUserEmployement", verifyToken, applicationController.getUserEmployement);
router.post("/getResumeHeadline", verifyToken, applicationController.getResumeHeadline);
router.post("/createUserEmployement", verifyToken, applicationController.createUserEmployement);
router.post("/createUserEducation", verifyToken, applicationController.createUserEducation);
router.post("/getUserEducation", verifyToken, applicationController.getUserEducation);
router.post("/updateUserITSkills",verifyToken,applicationController.updateUserITSkills);
router.post("/deleteUserITSkills",verifyToken,applicationController.deleteUserITSkills);
router.post("/getUserITSkillsList",verifyToken,applicationController.getUserITSkillsList);
router.post("/createProfileSummary", verifyToken, applicationController.createProfileSummary);
router.post("/getProfileSummary", verifyToken, applicationController.getProfileSummary);
router.post("/deleteUserProfileSummary", verifyToken, applicationController.deleteUserProfileSummary);
router.post("/createCareerProfile", verifyToken, applicationController.createCareerProfile);
router.post("/getCareerProfile", verifyToken, applicationController.getCareerProfile);
router.post("/getCommonStatus", verifyToken, applicationController.getCommonStatus);
//

router.post("/getCategoryAndJobCountFromJob", applicationController.getCategoryAndJobCountFromJob)
router.post("/createJobList", verifyToken, applicationController.createJobList);

// Without login (verifyToken not required) 
router.post("/getJobList",verifyTokenIfApplicable, applicationController.getJobList);

// After login
router.post("/getJobPostList",verifyToken, applicationController.getJobPostList)


router.post("/jobApply", verifyToken,applicationController.jobApply);
router.post("/getJobDatabyID", verifyTokenIfApplicable, applicationController.getJobDatabyID);
router.post("/getJobMatches", applicationController.getJobMatches);

router.post("/updateJobStatus",verifyToken, applicationController.updateJobStatus);

// get applied user list for perticular job
router.post("/getJobAppliedUserList",verifyToken, applicationController.getJobAppliedUserList);
router.post("/saveUnsaveJob",verifyToken, applicationController.saveUnsaveJob);
router.post("/savedUnsavedJobList",verifyToken, applicationController.savedUnsavedJobList);


//get my applied job list for different different jobs for jobseekers
router.post("/getJobSeekersJobAppliedList",verifyToken, applicationController.getJobSeekersJobAppliedList);

//personal details api
router.post("/updateUserPersonalDetails",verifyToken, applicationController.updateUserPersonalDetails);
router.post("/getPersonalDetails",verifyToken, applicationController.getPersonalDetails);
router.post("/updateUserDetails",verifyToken, applicationController.updateUserDetails);

//update compnay details
router.post("/updateCompanyInfo",verifyToken, applicationController.updateCompanyInfo);
router.post("/updateCompanyDetails",verifyToken, applicationController.updateCompanyDetails);



module.exports = router;