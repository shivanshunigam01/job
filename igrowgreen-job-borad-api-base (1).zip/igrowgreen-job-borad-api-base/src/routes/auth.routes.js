/**
* file which containts all routes of the Auth controllers.
*/

const express = require("express");
const loginValidation = require("../models/request/login.validator");
const userValidation = require("../models/request/user.validator");
const forgotPasswordValidation = require("../models/request/forgotpassword.validator.js");
const resetPasswordValidation = require("../models/request/resetpassword.validator.js");
const { AuthController } = require("../controllers/auth.controller.js");
const otpLimiter=require("../middlewares/otpLimit.js")
const verifyToken = require("../middlewares/auth.js");

const authController = new AuthController(); 
const router = express.Router();

router.post("/login", loginValidation, authController.userLogin);
router.post("/register", authController.userRegistration);
router.post("/forgotPassword", forgotPasswordValidation, authController.forgotPassword);
router.post("/otpVerifyResetPassword", resetPasswordValidation, authController.otpVerifyResetPassword);
router.post("/changePassword",verifyToken, authController.changePassword);

module.exports = router;