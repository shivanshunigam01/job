/**
* file which containts all routes of the Common controllers.
*/
const express = require("express");
const parameterValidation = require("../models/request/parameter.validator");
const {getDetails,applyFilter,mainFilter } = require("../controllers/common.controller");
const verifyToken = require("../middlewares/auth.js");
const router = express.Router();

router.post("/getDetails",verifyToken, getDetails)
router.post("/applyFilter", applyFilter)
router.post("/mainFilter", mainFilter)

module.exports = router;