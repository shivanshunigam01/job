const express = require("express");
const { DashboardController } = require("../controllers/dashboard.controller");
const verifyToken = require("../middlewares/auth.js");

const dashboardController = new DashboardController();
const router = express.Router();

router.post("/getDashboardList", verifyToken , (req, res) => {
  dashboardController.getDashboardList(req, res);
});


module.exports = router;
