/**
* file which containts all routes of the Auth controllers.
*/

const express = require("express");
const { createOrUpdateExperienceValidation, deleteExperienceValidation } = require("../models/request/totalexperiences.validator.js");
const { createOrUpdateCategoriesValidation, deleteCatgoriesValidation } = require("../models/request/categories.validator.js")
const { createOrUpdateDepartmentsValidation, deleteDeaprtmentsValidation } = require("../models/request/departments.validator.js")
const { createOrUpdateModulesValidation, deleteModulesValidation } = require("../models/request/modules.validator.js")
const { createOrUpdateLocationsValidation, deleteLocationsValidation } = require("../models/request/locations.validator.js")
const { createOrUpdateEducationsValidation, deleteEducationsValidation } = require("../models/request/educations.validator.js")
const { createOrUpdateIndustryTypesValidation, deleteIndustryTypesValidation } = require("../models/request/industryTypes.validator.js")
const { createOrUpdateSkillsValidation, deleteSkillsValidation } = require("../models/request/skills.validator.js")
const { createOrUpdateJobTypesValidation, deleteJobTypesValidation } = require("../models/request/jobtypes.validator.js")
const { createOrUpdateWorkModesValidation, deleteWorkModesValidation } = require("../models/request/workmodes.validator.js")
const { createOrUpdateSalaryTypesValidation, deleteSalaryTypesValidation } = require("../models/request/salarytypes.validator.js")

const { createOrUpdateShiftTimesValidation, deleteShiftTimesValidation } = require("../models/request/shifttimes.validator.js")



const { addOrUpdatesalariesValidation, deleteSalaryValidation } = require("../models/request/salaries.validator.js");
const { getCompaniesValidation, getCompaniesJobPostListValidation, getCompaniesJobAppliedUserListValidation, updateStatusListValidation } = require("../models/request/companies.validator.js")

const forgotPasswordValidation = require("../models/request/forgotpassword.validator.js");
const resetPasswordValidation = require("../models/request/resetpassword.validator.js");


const { MasterController } = require("../controllers/master.controller");
const verifyToken = require("../middlewares/auth.js");
const isAdmin = require("../middlewares/isAdmin.js")

const masterController = new MasterController();
const router = express.Router();


router.use(verifyToken)
router.use(isAdmin)
router.post("/state-list", masterController.getStateList);

// categorires APIS
router.post('/createCategories', createOrUpdateCategoriesValidation, masterController.addCategories)
router.post("/getCategories", masterController.getCategories)
router.post("/deleteCategories", deleteCatgoriesValidation, masterController.deleteCategories)

//Departments APIS
router.post('/createDepartments', createOrUpdateDepartmentsValidation, masterController.addDepartments)
router.post("/getDepartments", masterController.getDepartments)
router.post("/deleteDepartments", deleteDeaprtmentsValidation, masterController.deleteDepartments)


//Modules APIS
router.post('/createModules', createOrUpdateModulesValidation, masterController.addModules)
router.post("/getModules", masterController.getModules)
router.post("/deleteModules", deleteModulesValidation, masterController.deleteModules)


//Locations APIS
router.post('/createLocations', createOrUpdateLocationsValidation, masterController.addLocations)
router.post("/getLocations", masterController.getLocations)
router.post("/deleteLocations", deleteLocationsValidation, masterController.deleteLocations)


//Educations APIS
router.post('/createEducations', createOrUpdateEducationsValidation, masterController.addEducations)
router.post("/getEducations", masterController.getEducations)
router.post("/deleteEducations", deleteEducationsValidation, masterController.deleteEducations)


//Industry types APIS
router.post('/createIndustryTypes', createOrUpdateIndustryTypesValidation, masterController.addIndustryTypes)
router.post("/getIndustryTypes", masterController.getIndustryTypes)
router.post("/deleteIndustryTypes", deleteIndustryTypesValidation, masterController.deleteIndustryTypes)

//Skills APIS
router.post('/createSkills', createOrUpdateSkillsValidation, masterController.addSkills)
router.post("/getSkills", masterController.getSkills)
router.post("/deleteSkills", deleteSkillsValidation, masterController.deleteSkills)

//JobTypes APIS
router.post('/createJobTypes', createOrUpdateJobTypesValidation, masterController.addJobTypes)
router.post("/getJobTypes", masterController.getJobTypes)
router.post("/deleteJobTypes", deleteJobTypesValidation, masterController.deleteJobTypes)

//WorkModes APIS
router.post('/createWorkModes', createOrUpdateWorkModesValidation, masterController.addWorkModes)
router.post("/getWorkModes", masterController.getWorkModes)
router.post("/deleteWorkModes", deleteWorkModesValidation, masterController.deleteWorkModes)

//SalaryTypes APIS
router.post('/createSalaryTypes', createOrUpdateSalaryTypesValidation, masterController.addSalaryTypes)
router.post("/getSalaryTypes", masterController.getSalaryTypes)
router.post("/deleteSalaryTypes", deleteSalaryTypesValidation, masterController.deleteSalaryTypes)

//ShiftTimes APIS
router.post('/createShiftTimes', createOrUpdateShiftTimesValidation, masterController.addShiftTimes)
router.post("/getShiftTimes", masterController.getShiftTimes)
router.post("/deleteShiftTimes", deleteShiftTimesValidation, masterController.deleteShiftTimes)


//TotalExperiences APIS
router.post('/createTotalExperiences', createOrUpdateExperienceValidation, masterController.addTotalExperiences)
router.post("/getTotalExperiences", masterController.getTotalExperiences)
router.post("/deleteTotalExperiences", deleteExperienceValidation, masterController.deleteTotalExperiences)

//Salaries APIS
router.post('/createSalaries', addOrUpdatesalariesValidation, masterController.addSalaries)
router.post("/getSalaries", masterController.getSalaries)
router.post("/deleteSalaries", deleteSalaryValidation, masterController.deleteSalaries)


//getCompaniesDetails 
router.post("/getCompanies", getCompaniesValidation, masterController.getCompanies)
router.post("/getCompaniesJobPostList", getCompaniesJobPostListValidation, masterController.getCompaniesJobPostList)
router.post("/getCompaniesJobAppliedUserList", getCompaniesJobAppliedUserListValidation, masterController.getCompaniesJobAppliedUserList)
router.post("/updateStatus", updateStatusListValidation, masterController.updateStatus)


//Auth

router.post("/forgotPassword", forgotPasswordValidation, masterController.forgotPassword)
router.post("/otpVerifyResetPassword", resetPasswordValidation, masterController.otpVerifyResetPassword)
router.post("/changePassword", masterController.changePassword)










module.exports = router;