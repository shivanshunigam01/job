/**
* file which containts all routes of the Auth controllers.
*/

const express = require("express");
const loginValidation = require("../models/request/login.validator");
const userValidation = require("../models/request/user.validator");
const otpLimiter = require("../middlewares/otpLimit.js")
const { ReportController } = require("../controllers/report.controller");
const verifyToken = require("../middlewares/auth.js");

const reportController = new ReportController(); 
const router = express.Router();

router.post("/SendLeadotp",otpLimiter, reportController.SendLeadotp)





module.exports = router;