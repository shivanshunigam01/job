/**
* file which containts all routes of the Auth controllers.
*/

const express = require("express");
const loginValidation = require("../models/request/login.validator");
const userValidation = require("../models/request/user.validator");
const { TicketController } = require("../controllers/ticket.controller");
const verifyToken = require("../middlewares/auth.js");

const ticketController = new TicketController(); 
const router = express.Router();
router.post("/list", verifyToken, ticketController.ticketList);
router.post("/create", verifyToken, ticketController.ticketCreate);
router.post("/getTicketSubcategory", ticketController.getTicketSubcategoryList);
router.post("/getTicketList", verifyToken,ticketController.getTicketList);

// Task API routes
router.post("/updateTask", verifyToken, ticketController.updateTask);
router.post("/getTaskDetails", verifyToken, ticketController.getTaskDetails)

module.exports = router;