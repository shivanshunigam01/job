exports.documentType = {
    panCard: 1,
    trainingCredentials: 2,
    serviceProviderDeclaration: 3,
    bankGuarantee: 4
}

exports.documentTypeReference = {
	vendorDocuments: 5
};