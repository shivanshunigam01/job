const joi = require("joi");
const apiResponse = require("../helpers/apiResponse");

const validation = joi.object({
	projectID: joi.string().empty().required().messages({
		'string.empty': `{#key} cannot be an empty field`,
		'any.required': `{#key} is a required field`,
	}),
	//measurementID: joi.string().allow(null, ''),
	measurmentObjectCount:joi.string().allow(null, ''),
    distanceMObsInfo: joi.string().allow(null, ''),
	// measurmentObjectName: joi.string().empty().required().messages({
	// 	'string.empty': `{#key} cannot be an empty field`,
	// 	'any.required': `{#key} is a required field`,
	// }),
	
	// measurmentObjectLat: joi.number().empty().required().messages({
	// 	'any.required': `{#key} is a required field`,
	// }),
	// measurmentObjectLng: joi.number().empty().required().messages({
	// 	'any.required': `{#key} is a required field`,
	// }),
	// rootLineRenderObj: joi.string().allow(null, ''),
	// dotController: joi.string().allow(null, ''),
	
});

const distanceMeasurementValidation = async (req, res, next) => {
	const payload = {
		projectID: req.body.projectID,
		//measurementID: req.body.measurementID,
		measurmentObjectCount: req.body.measurmentObjectCount,
        distanceMObsInfo: req.body.distanceMObsInfo
		// measurmentObjectName: req.body.measurmentObjectName,
		// measurmentObjectLat: req.body.measurmentObjectLat,
		// measurmentObjectLng: req.body.measurmentObjectLng,
		// rootLineRenderObj: req.body.rootLineRenderObj,
		// dotController: req.body.dotController,
	};

	const { error } = validation.validate(payload);
	if (error) {
		return apiResponse.notAcceptableRequest(res, `${error.message}`);
	} else {
		next();
	}
};

module.exports = distanceMeasurementValidation;